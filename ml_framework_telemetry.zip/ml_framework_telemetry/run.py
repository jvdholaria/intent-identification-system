"""
run.py — Run the ml_framework on long-format telemetry data.

Expected CSV schema
-------------------
  ts           : timestamp column (any pandas-parseable format)
  asset_id     : identifier for the asset / machine / device
  telemetry_1  : numeric sensor reading
  telemetry_2  : numeric sensor reading
  ...
  telemetry_N  : numeric sensor reading

Example rows
------------
  ts,                   asset_id, telemetry_1, telemetry_2, telemetry_3
  2026-01-01 00:00:00,  asset_A,  42.1,        81.5,        0.93
  2026-01-01 00:00:00,  asset_B,  39.8,        79.2,        0.88
  2026-01-01 00:01:00,  asset_A,  42.3,        81.7,        0.91

Pipeline overview
-----------------
  1. Load CSV  →  long-format DataFrame
  2. Pivot     →  wide-format  (one column per asset × telemetry combination)
                  e.g. telemetry_1__asset_A, telemetry_2__asset_B, …
  3. Resample + interpolate on common time grid
  4. Lag / rolling feature engineering
  5. Train LightGBM (tree mode, direct multi-output)
  6. Inference on holdout set
  7. Anomaly detection on holdout
  8. Save predictions, plots, and checkpoint

Outputs (written to ./outputs/)
--------------------------------
  predictions.csv          — timestamp + predicted values for holdout rows
  actual_vs_predicted.png  — time-series overlay for each target
  anomalies.csv            — per-row anomaly scores and severity labels
  checkpoint/              — serialised pipeline (reload with pipeline.load())
"""

from __future__ import annotations

import io
import logging
import os
import sys
import warnings
from pathlib import Path
from typing import List, Optional

import matplotlib
matplotlib.use("Agg")          # non-interactive — works without a display
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# Fix Windows terminal encoding so non-ASCII chars print without crashing
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
else:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

warnings.filterwarnings("ignore")

from ml_framework.core.config import (
    AnomalyConfig,
    DataSourceConfig,
    ExplainabilityConfig,
    FrameworkConfig,
    PreprocessingConfig,
    TemporalConfig,
    TreeModelConfig,
    TrainingConfig,
)
from ml_framework.pipeline import MLPipeline

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("run")


# ---------------------------------------------------------------------------
# Configuration — edit these to match your dataset
# ---------------------------------------------------------------------------

CSV_PATH       = "your_telemetry.csv"   # path to your long-format CSV
TS_COL         = "ts"                   # name of the timestamp column
ASSET_ID_COL   = "asset_id"            # name of the asset identifier column
TELEMETRY_PREFIX = "telemetry_"        # prefix shared by all telemetry columns
OUTPUT_DIR     = "./outputs"

# Which asset + telemetry channel(s) to predict.
# These are post-pivot column names: f"{telemetry_col}__{asset_id}"
# Leave empty to auto-detect and predict the first telemetry column of
# every asset (see _auto_detect_targets below).
TARGET_COLUMNS: List[str] = []         # e.g. ["telemetry_1__asset_A"]

# Number of most-recent rows to use for inference / evaluation
HOLDOUT_ROWS = 2000

# Fraction of the dataset to hold back from training entirely
TEST_FRACTION = 0.10
VAL_FRACTION  = 0.10


# ---------------------------------------------------------------------------
# Step 1 — Load and validate the raw CSV
# ---------------------------------------------------------------------------

def load_raw(path: str) -> pd.DataFrame:
    """
    Load a long-format telemetry CSV and return it with a DatetimeIndex
    set to the timestamp column.

    Raises FileNotFoundError with a clear message if the file is missing.
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(
            f"Dataset not found at '{path}'.\n"
            f"Set CSV_PATH at the top of run.py to your file location."
        )

    df = pd.read_csv(p, parse_dates=[TS_COL])
    df = df.set_index(TS_COL)
    df.index.name = TS_COL
    df = df.sort_index()

    # Basic validation
    if ASSET_ID_COL not in df.columns:
        raise ValueError(
            f"Column '{ASSET_ID_COL}' not found. "
            f"Available columns: {df.columns.tolist()}"
        )

    telemetry_cols = [c for c in df.columns if c.startswith(TELEMETRY_PREFIX)]
    if not telemetry_cols:
        raise ValueError(
            f"No columns starting with '{TELEMETRY_PREFIX}' found. "
            f"Check TELEMETRY_PREFIX in run.py."
        )

    logger.info(
        "Loaded raw data: %d rows × %d columns | assets: %s | telemetry cols: %s",
        len(df), df.shape[1],
        sorted(df[ASSET_ID_COL].unique()),
        telemetry_cols,
    )
    return df


# ---------------------------------------------------------------------------
# Step 2 — Pivot long → wide
# ---------------------------------------------------------------------------

def pivot_to_wide(df: pd.DataFrame) -> pd.DataFrame:
    """
    Pivot a long-format telemetry DataFrame to wide format.

    Input shape:
        index=ts, columns=[asset_id, telemetry_1, telemetry_2, ...]

    Output shape:
        index=ts, columns=[telemetry_1__asset_A, telemetry_1__asset_B,
                            telemetry_2__asset_A, telemetry_2__asset_B, ...]

    Duplicate (ts, asset_id) pairs are resolved with the mean so the
    pivot never fails on duplicates.
    """
    telemetry_cols = [c for c in df.columns if c.startswith(TELEMETRY_PREFIX)]

    wide = df.pivot_table(
        index=df.index,
        columns=ASSET_ID_COL,
        values=telemetry_cols,
        aggfunc="mean",
    )

    # Flatten the MultiIndex columns: (telemetry_1, asset_A) → telemetry_1__asset_A
    wide.columns = [f"{tele}__{asset}" for tele, asset in wide.columns]
    wide = wide.sort_index()

    logger.info(
        "Pivoted to wide format: %d rows × %d feature columns",
        len(wide), wide.shape[1],
    )
    logger.info("Wide columns: %s", wide.columns.tolist())
    return wide


# ---------------------------------------------------------------------------
# Step 3 — Auto-detect prediction targets (when TARGET_COLUMNS is empty)
# ---------------------------------------------------------------------------

def _auto_detect_targets(wide_df: pd.DataFrame) -> List[str]:
    """
    Return the first telemetry channel for every asset as default targets.

    Example: if assets are [asset_A, asset_B] and telemetry columns are
    [telemetry_1, telemetry_2], returns:
        ["telemetry_1__asset_A", "telemetry_1__asset_B"]
    """
    all_cols = wide_df.columns.tolist()
    # Group by asset: pick the first (alphabetically sorted) telemetry col per asset
    asset_map: dict[str, str] = {}
    for col in sorted(all_cols):
        parts = col.split("__", 1)
        if len(parts) == 2:
            tele, asset = parts
            if asset not in asset_map:
                asset_map[asset] = col

    targets = list(asset_map.values())
    logger.info(
        "Auto-detected targets (first telemetry col per asset): %s", targets
    )
    return targets


# ---------------------------------------------------------------------------
# Step 4 — Build FrameworkConfig
# ---------------------------------------------------------------------------

def build_config(targets: List[str]) -> FrameworkConfig:
    return FrameworkConfig(
        project_name    = "asset_telemetry",
        output_dir      = OUTPUT_DIR,
        targets         = targets,
        mode            = "tree",
        prediction_type = "static",

        temporal = TemporalConfig(
            timestamp_col        = TS_COL,
            resample_freq        = "1min",
            aggregation_method   = "mean",
            interpolation_method = "linear",
            max_gap_fill_periods = 10,
        ),

        preprocessing = PreprocessingConfig(
            scaler                   = "robust",
            encoder                  = "ordinal",
            imputer                  = "median",
            dim_reduction            = "none",
            auto_feature_engineering = True,
            lag_periods              = [1, 5, 10, 30],
            rolling_windows          = [15, 60],
            add_time_features        = True,
        ),

        tree_model = TreeModelConfig(
            model_type             = "lgbm",
            n_estimators           = 300,
            learning_rate          = 0.05,
            early_stopping_rounds  = 20,
            multi_output_strategy  = "direct",
            subsample              = 0.8,
            colsample_bytree       = 0.8,
        ),

        training = TrainingConfig(
            test_fraction = TEST_FRACTION,
            val_fraction  = VAL_FRACTION,
            n_cv_folds    = 3,
            metrics       = ["mae", "rmse", "r2"],
        ),

        explainability = ExplainabilityConfig(
            enabled              = True,
            backend              = "shap",
            n_background_samples = 100,
            n_explain_samples    = 50,
            plot_top_k_features  = 15,
        ),

        anomaly = AnomalyConfig(
            enabled               = True,
            use_isolation_forest  = True,
            use_lof               = True,
            use_statistical       = True,
            use_residual_detection= True,
            contamination         = 0.05,
            weights = {
                "isolation_forest": 1.0,
                "lof":              1.0,
                "statistical":      1.5,
            },
        ),
    )


# ---------------------------------------------------------------------------
# Plotting helper
# ---------------------------------------------------------------------------

def plot_predictions(
    actual_df: pd.DataFrame,
    pred_df: pd.DataFrame,
    targets: List[str],
    save_path: str,
    n_points: int = 500,
) -> None:
    """
    Plot actual vs predicted values for every target on separate sub-plots.
    """
    if "timestamp" in pred_df.columns:
        pred_df = pred_df.set_index("timestamp")

    actual = actual_df[targets].tail(n_points).copy()
    pred   = pred_df[[t for t in targets if t in pred_df.columns]].tail(n_points).copy()

    n_targets = len(targets)
    fig, axes = plt.subplots(
        n_targets, 1,
        figsize=(16, 4 * n_targets),
        sharex=True,
        facecolor="#0f1117",
    )
    if n_targets == 1:
        axes = [axes]

    colors = {"actual": "#4fc3f7", "pred": "#ff7043"}

    for ax, target in zip(axes, targets):
        if target not in actual.columns:
            continue
        ax.set_facecolor("#1a1d27")
        ax.plot(
            actual.index, actual[target],
            color=colors["actual"], linewidth=1.0, alpha=0.85, label="Actual",
        )
        if target in pred.columns:
            common_idx = actual.index.intersection(pred.index)
            if len(common_idx) > 0:
                ax.plot(
                    common_idx, pred.loc[common_idx, target],
                    color=colors["pred"], linewidth=1.2,
                    linestyle="--", alpha=0.90, label="Predicted",
                )

        # Readable y-axis label: telemetry_1__asset_A → telemetry 1 / asset A
        label = target.replace("__", " / ").replace("_", " ")
        ax.set_ylabel(label, color="white", fontsize=10)
        ax.tick_params(colors="white", labelsize=8)
        for spine in ax.spines.values():
            spine.set_edgecolor("#444")
        ax.grid(axis="y", color="#333", linestyle=":", linewidth=0.7)
        ax.legend(
            framealpha=0.3, facecolor="#0f1117", edgecolor="#555",
            labelcolor="white", fontsize=9,
        )

    axes[-1].xaxis.set_major_formatter(mdates.DateFormatter("%d-%b %H:%M"))
    fig.autofmt_xdate(rotation=30, ha="right")
    axes[-1].tick_params(axis="x", colors="white", labelsize=8)

    fig.suptitle(
        "Asset Telemetry — Actual vs Predicted",
        color="white", fontsize=14, fontweight="bold", y=1.01,
    )
    fig.tight_layout()

    os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)
    fig.savefig(save_path, dpi=150, bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close(fig)
    logger.info("Plot saved → %s", save_path)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def run() -> None:
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # ── 1. Load raw long-format CSV ────────────────────────────────────────
    print("\n[1/7] Loading dataset...")
    raw_df = load_raw(CSV_PATH)
    print(f"      Raw shape : {raw_df.shape[0]:,} rows × {raw_df.shape[1]} columns")
    print(f"      Date range: {raw_df.index.min()}  →  {raw_df.index.max()}")
    print(f"      Assets    : {sorted(raw_df[ASSET_ID_COL].unique())}")

    # ── 2. Pivot long → wide ───────────────────────────────────────────────
    print("\n[2/7] Pivoting long → wide format...")
    wide_df = pivot_to_wide(raw_df)
    print(f"      Wide shape: {wide_df.shape[0]:,} rows × {wide_df.shape[1]} columns")

    # ── 3. Resolve prediction targets ─────────────────────────────────────
    targets = TARGET_COLUMNS if TARGET_COLUMNS else _auto_detect_targets(wide_df)
    # Validate targets exist in wide_df
    missing = [t for t in targets if t not in wide_df.columns]
    if missing:
        raise ValueError(
            f"Target column(s) not found after pivot: {missing}\n"
            f"Available columns: {wide_df.columns.tolist()}"
        )
    print(f"\n      Predicting: {targets}")

    # ── 4. Build config and pipeline ──────────────────────────────────────
    print("\n[3/7] Building pipeline config...")
    cfg      = build_config(targets)
    pipeline = MLPipeline(cfg)

    # ── 5. Fit on the full wide DataFrame ─────────────────────────────────
    print("\n[4/7] Fitting pipeline (preprocessing + training + SHAP)...")
    pipeline.fit(merged_df=wide_df)

    # ── 6. Inference on holdout ────────────────────────────────────────────
    holdout_n = min(HOLDOUT_ROWS, len(wide_df))
    print(f"\n[5/7] Running inference on last {holdout_n:,} rows...")
    holdout_input  = wide_df.iloc[-holdout_n:].drop(columns=targets, errors="ignore")
    actual_holdout = wide_df.iloc[-holdout_n:].copy()

    result  = pipeline.predict(holdout_input)
    pred_df = result.to_dataframe()   # DataFrame with 'timestamp' + target cols

    pred_path = os.path.join(OUTPUT_DIR, "predictions.csv")
    pred_df.to_csv(pred_path, index=False)
    print(f"      Predictions saved → {pred_path}")
    print(f"      Shape: {pred_df.shape[0]:,} rows × {pred_df.shape[1]} columns")

    print("\n      Sample predictions (first 5 rows):")
    print(pred_df.head(5).to_string(index=False))
    print("\n      Actual values (same rows):")
    print(actual_holdout[targets].head(5).to_string())

    # ── 7. Plot actual vs predicted ────────────────────────────────────────
    print("\n[6/7] Generating actual vs predicted plot...")
    plot_predictions(
        actual_df = actual_holdout,
        pred_df   = pred_df,
        targets   = targets,
        save_path = os.path.join(OUTPUT_DIR, "actual_vs_predicted.png"),
        n_points  = holdout_n,
    )

    # ── 8. Anomaly detection ───────────────────────────────────────────────
    print("\n[7/7] Running anomaly detection on holdout...")
    ad_result   = pipeline.detect_anomalies(actual_holdout, include_residuals=True)
    print("\n" + ad_result.summary())

    anomaly_path = os.path.join(OUTPUT_DIR, "anomalies.csv")
    ad_result.to_dataframe().to_csv(anomaly_path, index=False)
    print(f"      Anomaly results saved → {anomaly_path}")

    # ── 9. Save checkpoint ─────────────────────────────────────────────────
    checkpoint_dir = os.path.join(OUTPUT_DIR, "checkpoint")
    pipeline.save(checkpoint_dir)
    print(f"\n      Checkpoint saved → {checkpoint_dir}/")

    # ── Summary ────────────────────────────────────────────────────────────
    print("\n" + "═" * 56)
    print("  All done — outputs written to:", OUTPUT_DIR)
    print("  ├── predictions.csv          (holdout predictions)")
    print("  ├── actual_vs_predicted.png  (time-series overlay)")
    print("  ├── anomalies.csv            (anomaly scores + severity)")
    print("  └── checkpoint/              (reload with pipeline.load())")
    print("═" * 56)


# ---------------------------------------------------------------------------
# Reload helper — run inference on new data without retraining
# ---------------------------------------------------------------------------

def predict_new(
    new_csv_path: str,
    checkpoint_dir: str = f"{OUTPUT_DIR}/checkpoint",
) -> pd.DataFrame:
    """
    Load a saved checkpoint and predict on a new long-format CSV.

    Parameters
    ----------
    new_csv_path    : path to new telemetry CSV (same schema as training data)
    checkpoint_dir  : path to the saved checkpoint directory

    Returns
    -------
    DataFrame with timestamp and predicted target columns.
    """
    from ml_framework.core.config import FrameworkConfig

    print(f"Loading checkpoint from {checkpoint_dir}...")
    cfg      = build_config(TARGET_COLUMNS or [])  # targets not needed for inference
    pipeline = MLPipeline(cfg)
    pipeline.load(checkpoint_dir)

    raw_df  = load_raw(new_csv_path)
    wide_df = pivot_to_wide(raw_df)

    # Drop target cols if present (they won't be at inference time)
    target_cols = [c for c in pipeline.targets if c in wide_df.columns]
    input_df    = wide_df.drop(columns=target_cols, errors="ignore")

    result = pipeline.predict(input_df)
    return result.to_dataframe()


# ---------------------------------------------------------------------------

if __name__ == "__main__":
    run()
