"""
Enterprise Temporal AI Platform — Forecast Inference Engine

Orchestrates model selection, ensemble weighting, probabilistic output,
and quantile estimation for multi-step forecasting.

Threading strategy
------------------
- All PyTorch `.predict()` calls run in the **GPU executor** (1-thread pool).
  This serialises CUDA operations so they never race each other.
- Ensemble models are submitted as concurrent futures and awaited together —
  maximum wall-clock parallelism while keeping CUDA safe.
- asyncio.gather() is still used to overlap async work (caching, feature
  fetching) with inference submission.
"""

from __future__ import annotations

import asyncio
from concurrent.futures import as_completed
from typing import Any, Dict, List, Optional

import numpy as np

from shared.config.settings import Settings
from shared.logging.logger import get_logger
from shared.schemas.schemas import ModelType
from shared.utilities.thread_pool import cpu_executor, gpu_executor

log = get_logger("forecast.engine")


class ForecastEngine:
    """
    Central inference engine.
    Each `.predict()` call is submitted to the GPU thread-pool so CUDA
    never races, while multiple models execute concurrently via futures.
    """

    def __init__(self, settings: Settings):
        self.settings = settings
        self._model_cache: Dict[str, Any] = {}

    async def run(
        self,
        series: List[float],
        horizon: int,
        model: ModelType,
        quantiles: List[float],
        tenant_id: str,
    ) -> Dict[str, Any]:
        log.info("engine.run", model=model.value, horizon=horizon, tenant=tenant_id)

        window = self.settings.FORECAST_WINDOW_SIZE
        x = np.array(series, dtype=np.float32)
        if len(x) < window:
            x = np.pad(x, (window - len(x), 0), mode="edge")
        x = x[-window:]

        if model == ModelType.ensemble:
            forecast_arr = await self._run_ensemble(x, horizon, tenant_id)
        else:
            forecast_arr = await self._run_single(model, x, horizon, tenant_id)

        # Guarantee exact horizon length
        forecast_arr = _trim_or_pad(forecast_arr, horizon)

        std = float(np.std(x[-24:])) if len(x) >= 24 else 1.0
        uncertainty  = [round(std * (1 + 0.02 * i), 4) for i in range(horizon)]
        lower_bound  = [round(f - 1.96 * u, 4) for f, u in zip(forecast_arr, uncertainty)]
        upper_bound  = [round(f + 1.96 * u, 4) for f, u in zip(forecast_arr, uncertainty)]
        p10 = [round(f - 1.28 * u, 4) for f, u in zip(forecast_arr, uncertainty)]
        p50 = [round(f, 4) for f in forecast_arr]
        p90 = [round(f + 1.28 * u, 4) for f, u in zip(forecast_arr, uncertainty)]

        log.info("engine.complete", tenant=tenant_id, horizon=horizon)
        return dict(
            forecast=p50, lower_bound=lower_bound, upper_bound=upper_bound,
            uncertainty=uncertainty, p10=p10, p50=p50, p90=p90,
        )

    # ── Parallel ensemble ─────────────────────────────────────────────────────

    async def _run_ensemble(
        self,
        x: np.ndarray,
        horizon: int,
        tenant_id: str,
    ) -> List[float]:
        """
        Submit all 5 models to the GPU executor concurrently.
        asyncio.gather() waits for all futures without blocking the event loop.

        Before (sequential):  ~5 × inference_time
        After  (concurrent):  ~1 × inference_time  (overlap in GPU queue)
        """
        s = self.settings
        weights = [
            (ModelType.patchtst,  s.ENSEMBLE_WEIGHT_PATCHTST),
            (ModelType.tft,       s.ENSEMBLE_WEIGHT_TFT),
            (ModelType.timesnet,  s.ENSEMBLE_WEIGHT_TIMESNET),
            (ModelType.nbeats,    s.ENSEMBLE_WEIGHT_NBEATS),
            (ModelType.gru,       s.ENSEMBLE_WEIGHT_GRU),
        ]

        # Submit all models at once — they queue inside the GPU executor
        loop = asyncio.get_event_loop()
        tasks = [
            loop.run_in_executor(
                gpu_executor(),
                self._sync_predict,
                model_type,
                x.copy(),  # each thread gets its own array slice
                horizon,
                tenant_id,
            )
            for model_type, _ in weights
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)

        ensemble = np.zeros(horizon, dtype=np.float64)
        weight_sum = 0.0
        for (model_type, weight), result in zip(weights, results):
            if isinstance(result, Exception):
                log.warning("ensemble.model_failed", model=model_type.value, exc=str(result))
                continue
            arr = _trim_or_pad(result, horizon)
            ensemble   += weight * np.array(arr, dtype=np.float64)
            weight_sum += weight

        # Renormalise if any model failed
        if weight_sum > 0 and weight_sum < 1.0:
            ensemble /= weight_sum

        return ensemble.tolist()

    async def _run_single(
        self,
        model: ModelType,
        x: np.ndarray,
        horizon: int,
        tenant_id: str,
    ) -> List[float]:
        """Run one model inside the GPU executor thread pool."""
        loop = asyncio.get_event_loop()
        try:
            result = await loop.run_in_executor(
                gpu_executor(),
                self._sync_predict,
                model,
                x.copy(),
                horizon,
                tenant_id,
            )
            return _trim_or_pad(result, horizon)
        except Exception as exc:
            log.error("engine.model_error", model=model.value, exc=str(exc))
            return await self._gru_fallback(x, horizon)

    def _sync_predict(
        self,
        model: ModelType,
        x: np.ndarray,
        horizon: int,
        tenant_id: str,
    ) -> List[float]:
        """
        Pure synchronous prediction — safe to call from any thread.
        Loads the predictor (cached) and calls predict().
        """
        predictor = self._load_model(model, tenant_id)
        result = predictor.predict(x, horizon)
        return result.tolist() if isinstance(result, np.ndarray) else list(result)

    def _load_model(self, model: ModelType, tenant_id: str):
        cache_key = f"{tenant_id}:{model.value}"
        if cache_key in self._model_cache:
            return self._model_cache[cache_key]
        predictor = self._build_predictor(model)
        self._model_cache[cache_key] = predictor
        return predictor

    def _build_predictor(self, model: ModelType):
        if model == ModelType.patchtst:
            from forecasting.models.patchtst.model import PatchTSTPredictor
            return PatchTSTPredictor(self.settings)
        if model == ModelType.tft:
            from forecasting.models.tft.model import TFTPredictor
            return TFTPredictor(self.settings)
        if model == ModelType.timesnet:
            from forecasting.models.timesnet.model import TimesNetPredictor
            return TimesNetPredictor(self.settings)
        if model == ModelType.nbeats:
            from forecasting.models.nbeats.model import NBeatsPredictor
            return NBeatsPredictor(self.settings)
        if model in (ModelType.gru, ModelType.lstm):
            from forecasting.models.gru.model import GRUPredictor
            return GRUPredictor(self.settings)
        from forecasting.models.gru.model import GRUPredictor
        return GRUPredictor(self.settings)

    async def _gru_fallback(self, x: np.ndarray, horizon: int) -> List[float]:
        from forecasting.models.gru.model import GRUPredictor
        gru = GRUPredictor(self.settings)
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(gpu_executor(), gru.predict, x, horizon)
        return _trim_or_pad(result, horizon)


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _trim_or_pad(arr, horizon: int) -> List[float]:
    """Guarantee output is exactly `horizon` steps — no shape surprises."""
    a = list(arr) if not isinstance(arr, list) else arr
    if len(a) >= horizon:
        return a[:horizon]
    return a + [a[-1]] * (horizon - len(a))  # pad with last value

