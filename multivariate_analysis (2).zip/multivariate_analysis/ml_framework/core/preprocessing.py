"""
preprocessing.py — Scalable, sklearn-compatible preprocessing pipeline.

Responsibilities
----------------
1. Identify and impute missing values.
2. Encode categorical variables.
3. Scale / normalise numeric features.
4. Automated lag / rolling feature engineering.
5. Optional dimensionality reduction (PCA / UMAP).

All transformers are fit on training data only and serialised via pickle /
joblib so the same transformations are applied at inference time.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from pandas import DataFrame

from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.decomposition import PCA
from sklearn.impute import KNNImputer, SimpleImputer
from sklearn.experimental import enable_iterative_imputer  # noqa: F401
from sklearn.impute import IterativeImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import (
    LabelEncoder,
    MinMaxScaler,
    OrdinalEncoder,
    RobustScaler,
    StandardScaler,
)

from .config import FrameworkConfig, PreprocessingConfig

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Custom transformers (sklearn API)
# ---------------------------------------------------------------------------


class LagFeatureTransformer(BaseEstimator, TransformerMixin):
    """
    Add lag and rolling-window features for numeric columns.

    Designed to work on *training sequences only* to prevent leakage —
    it should be called after the temporal split.
    """

    def __init__(
        self,
        lag_periods: List[int],
        rolling_windows: List[int],
        target_cols: Optional[List[str]] = None,
    ) -> None:
        self.lag_periods    = lag_periods
        self.rolling_windows = rolling_windows
        self.target_cols    = target_cols or []  # lags on targets are safe at train time

    def fit(self, X: DataFrame, y=None):
        self.numeric_cols_ = X.select_dtypes(include="number").columns.tolist()
        # Never create lag features from target columns at inference
        self.feature_cols_ = [c for c in self.numeric_cols_
                               if c not in self.target_cols]
        return self

    def transform(self, X: DataFrame) -> DataFrame:
        X = X.copy()
        for col in self.feature_cols_:
            for lag in self.lag_periods:
                X[f"{col}__lag_{lag}"] = X[col].shift(lag)
            for win in self.rolling_windows:
                roll = X[col].rolling(win, min_periods=1)
                X[f"{col}__roll_mean_{win}"] = roll.mean()
                X[f"{col}__roll_std_{win}"]  = roll.std().fillna(0)
                X[f"{col}__roll_max_{win}"]  = roll.max()
        return X


class CategoricalEncoderTransformer(BaseEstimator, TransformerMixin):
    """Encodes every categorical column using the configured strategy."""

    def __init__(self, strategy: str = "ordinal") -> None:
        self.strategy = strategy
        self._encoders: Dict[str, OrdinalEncoder] = {}

    def fit(self, X: DataFrame, y=None):
        self.cat_cols_ = X.select_dtypes(exclude="number").columns.tolist()
        for col in self.cat_cols_:
            enc = OrdinalEncoder(
                handle_unknown="use_encoded_value",
                unknown_value=-1,
            )
            enc.fit(X[[col]])
            self._encoders[col] = enc
        return self

    def transform(self, X: DataFrame) -> DataFrame:
        X = X.copy()
        for col, enc in self._encoders.items():
            if col in X.columns:
                X[col] = enc.transform(X[[col]]).ravel()
        return X


class DimensionalityReducer(BaseEstimator, TransformerMixin):
    """
    Wrap PCA or UMAP to reduce feature space after scaling.

    UMAP is only imported if installed — it's an optional dependency.
    """

    def __init__(self, method: str = "pca", **kwargs) -> None:
        self.method = method
        self.kwargs = kwargs
        self._reducer = None

    def fit(self, X: np.ndarray, y=None):
        if self.method == "pca":
            variance = self.kwargs.get("variance_threshold", 0.95)
            self._reducer = PCA(n_components=variance, svd_solver="full")
            self._reducer.fit(X)
            logger.info(
                "PCA: %d → %d components (%.1f%% variance)",
                X.shape[1],
                self._reducer.n_components_,
                variance * 100,
            )
        elif self.method == "umap":
            try:
                import umap  # type: ignore
            except ImportError:
                raise ImportError("Install 'umap-learn' for UMAP reduction.")
            n_comp = self.kwargs.get("n_components", 32)
            self._reducer = umap.UMAP(n_components=n_comp, random_state=42)
            self._reducer.fit(X)
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        if self._reducer is None:
            return X
        return self._reducer.transform(X)


# ---------------------------------------------------------------------------
# Master preprocessing pipeline
# ---------------------------------------------------------------------------


class PreprocessingPipeline:
    """
    Orchestrates the full feature-engineering and transformation pipeline.

    Workflow
    --------
    fit_transform(train_df, targets) → (X_train, y_train, feature_names)
    transform(df, targets)           → (X, y, feature_names)

    The pipeline is stateful: scalers, encoders, and reducers are fit only
    on training data, then applied consistently during validation / test /
    inference.

    Parameters
    ----------
    config : FrameworkConfig
    targets : list[str]
        Names of target columns. These are extracted as y and excluded from X.
    """

    def __init__(self, config: FrameworkConfig, targets: List[str]) -> None:
        self.cfg     = config.preprocessing
        self.targets = targets
        self._is_fit  = False

        # These are set during fit
        self._lag_transformer: Optional[LagFeatureTransformer]           = None
        self._cat_encoder:     Optional[CategoricalEncoderTransformer]   = None
        self._imputer:         Optional[BaseEstimator]                   = None
        self._scaler:          Optional[BaseEstimator]                   = None
        self._reducer:         Optional[DimensionalityReducer]           = None
        self._feature_names:   List[str]                                 = []
        self._num_cols:        List[str]                                 = []

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def fit_transform(
        self,
        df: DataFrame,
    ) -> Tuple[np.ndarray, np.ndarray, List[str]]:
        """Fit the pipeline on df and return (X, y, feature_names)."""
        df = df.copy()

        # ---- 1. Lag / rolling features -----------------------------------
        if self.cfg.auto_feature_engineering:
            self._lag_transformer = LagFeatureTransformer(
                lag_periods=self.cfg.lag_periods,
                rolling_windows=self.cfg.rolling_windows,
                target_cols=self.targets,
            )
            df = self._lag_transformer.fit_transform(df)

        # ---- 2. Extract targets ------------------------------------------
        present_targets = [t for t in self.targets if t in df.columns]
        y  = df[present_targets].values.astype(np.float32)
        df = df.drop(columns=present_targets, errors="ignore")

        # ---- 3. Encode categoricals --------------------------------------
        self._cat_encoder = CategoricalEncoderTransformer(self.cfg.encoder)
        df = self._cat_encoder.fit_transform(df)

        # ---- 4. Drop remaining non-numeric columns -----------------------
        df = df.select_dtypes(include="number")
        self._feature_names = df.columns.tolist()

        # ---- 5. Imputation -----------------------------------------------
        self._imputer = self._build_imputer()
        X = self._imputer.fit_transform(df.values).astype(np.float32)

        # ---- 6. Scaling --------------------------------------------------
        self._scaler = self._build_scaler()
        X = self._scaler.fit_transform(X).astype(np.float32)

        # ---- 7. Dimensionality reduction ---------------------------------
        if self.cfg.dim_reduction != "none":
            self._reducer = DimensionalityReducer(
                method=self.cfg.dim_reduction,
                variance_threshold=self.cfg.pca_variance_threshold,
                n_components=self.cfg.umap_n_components,
            )
            X = self._reducer.fit_transform(X).astype(np.float32)
            self._feature_names = [
                f"component_{i}" for i in range(X.shape[1])
            ]

        self._is_fit = True
        logger.info(
            "Preprocessing fit: %d → %d features, %d samples",
            len(self._feature_names), X.shape[1], X.shape[0],
        )
        return X, y, self._feature_names

    def transform(
        self,
        df: DataFrame,
    ) -> Tuple[np.ndarray, np.ndarray, List[str]]:
        """Apply fitted transformers to new data (no re-fitting)."""
        if not self._is_fit:
            raise RuntimeError("Call fit_transform before transform.")
        df = df.copy()

        if self._lag_transformer is not None:
            df = self._lag_transformer.transform(df)

        present_targets = [t for t in self.targets if t in df.columns]
        y  = df[present_targets].values.astype(np.float32) if present_targets else np.empty((len(df), 0), dtype=np.float32)
        df = df.drop(columns=present_targets, errors="ignore")

        df = self._cat_encoder.transform(df)
        df = df.select_dtypes(include="number")

        # Align columns to training set (add missing cols as 0, drop extras)
        for col in self._feature_names:
            if col not in df.columns:
                df[col] = 0.0
        df = df[self._feature_names]

        X = self._imputer.transform(df.values).astype(np.float32)
        X = self._scaler.transform(X).astype(np.float32)
        if self._reducer is not None:
            X = self._reducer.transform(X).astype(np.float32)

        return X, y, self._feature_names

    def transform_sequences(
        self,
        X_seq: np.ndarray,
    ) -> np.ndarray:
        """
        Apply scaler (and optional PCA) to pre-built 3-D sequence arrays.
        Shape: (N, window_size, n_features) → (N, window_size, n_components)
        """
        if not self._is_fit:
            raise RuntimeError("Call fit_transform before transform_sequences.")
        N, W, F = X_seq.shape
        flat = X_seq.reshape(-1, F)
        flat = self._imputer.transform(flat).astype(np.float32)
        flat = self._scaler.transform(flat).astype(np.float32)
        if self._reducer is not None:
            flat = self._reducer.transform(flat).astype(np.float32)
        return flat.reshape(N, W, -1)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _build_imputer(self) -> BaseEstimator:
        strategy = self.cfg.imputer
        if strategy == "mean":
            return SimpleImputer(strategy="mean")
        elif strategy == "median":
            return SimpleImputer(strategy="median")
        elif strategy == "knn":
            return KNNImputer(n_neighbors=self.cfg.knn_neighbors)
        elif strategy == "iterative":
            return IterativeImputer(max_iter=10, random_state=42)
        elif strategy == "none":
            return SimpleImputer(strategy="constant", fill_value=0)
        else:
            raise ValueError(f"Unknown imputer strategy: {strategy}")

    def _build_scaler(self) -> BaseEstimator:
        scalers = {
            "standard": StandardScaler(),
            "minmax":   MinMaxScaler(),
            "robust":   RobustScaler(),
            "none":     None,
        }
        scaler = scalers.get(self.cfg.scaler)
        if scaler is None:
            # Identity scaler
            from sklearn.preprocessing import FunctionTransformer
            return FunctionTransformer()
        return scaler

    @property
    def feature_names(self) -> List[str]:
        return self._feature_names
