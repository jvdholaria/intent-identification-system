"""
Enterprise Temporal AI Platform — CSV Data Loader & Temporal Preprocessor

Handles:
- CSV ingestion with automatic column detection
- Timestamp parsing and validation
- Optional temporal resampling
- Gap filling / interpolation
- Normalisation (z-score, min-max, robust)
- Multi-variate feature support
- Train / val / test splitting
- .npy export for the training pipeline
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.preprocessing import (
    MinMaxScaler,
    RobustScaler,
    StandardScaler,
)

from shared.logging.logger import get_logger

log = get_logger("data.csv_loader")


# ─────────────────────────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class CSVLoaderConfig:
    """
    Configuration for the CSV temporal loader.
    """

    # ── Column mapping ────────────────────────────────────────────────────────
    timestamp_column: Optional[str] = None
    target_column: str = "value"
    feature_columns: List[str] = field(default_factory=list)

    # ── Temporal resampling ───────────────────────────────────────────────────
    # None = preserve native telemetry cadence
    resample_freq: Optional[str] = None

    aggregation_method: str = "mean"

    # ── Gap filling ───────────────────────────────────────────────────────────
    interpolation_method: str = "linear"
    max_gap_fill_periods: int = 8

    # ── Normalisation ─────────────────────────────────────────────────────────
    normalisation: str = "zscore"

    # ── Splits ────────────────────────────────────────────────────────────────
    train_ratio: float = 0.7
    val_ratio: float = 0.15

    # ── Sliding window ────────────────────────────────────────────────────────
    window_size: int = 168
    horizon: int = 24

    # ── Output ────────────────────────────────────────────────────────────────
    output_dir: str = "./data/processed"


# ─────────────────────────────────────────────────────────────────────────────
# Dataset Container
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class LoadedDataset:

    series: np.ndarray
    timestamps: pd.DatetimeIndex

    train: np.ndarray
    val: np.ndarray
    test: np.ndarray

    train_ts: pd.DatetimeIndex
    val_ts: pd.DatetimeIndex
    test_ts: pd.DatetimeIndex

    scaler: object

    feature_matrix: Optional[np.ndarray]

    metadata: Dict
    stats: Dict


# ─────────────────────────────────────────────────────────────────────────────
# Loader
# ─────────────────────────────────────────────────────────────────────────────

class CSVTemporalLoader:

    def __init__(self, config: CSVLoaderConfig):
        self.cfg = config
        self._scaler = None

    # ─────────────────────────────────────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────────────────────────────────────

    def load(self, csv_path: str) -> LoadedDataset:

        path = Path(csv_path)

        if not path.exists():
            raise FileNotFoundError(f"CSV not found: {csv_path}")

        log.info(
            "csv_loader.start",
            path=str(path)
        )

        # Step 1: Read
        df = self._read(path)

        log.info(
            "csv_loader.read",
            rows=len(df),
            cols=list(df.columns)
        )

        # Step 2: Parse timestamps
        df = self._parse_timestamps(df)

        # Step 3: Validate target
        self._validate_columns(df)

        # Step 4: Optional resampling
        df = self._resample(df)

        # Step 5: Fill gaps
        df = self._fill_gaps(df)

        # Step 6: Raw stats
        raw = df[self.cfg.target_column].values.astype(np.float64)

        stats = {
            "mean": float(np.mean(raw)),
            "std": float(np.std(raw)),
            "min": float(np.min(raw)),
            "max": float(np.max(raw)),
            "count": int(len(raw)),
            "null_count": int(np.isnan(raw).sum()),
        }

        # Step 7: Normalisation
        series, scaler = self._normalise(raw)

        # Step 8: Features
        feature_matrix = self._build_features(df)

        # Step 9: Splits
        train, val, test, ts_splits = self._split(
            series,
            df.index
        )

        ds = LoadedDataset(
            series=series,
            timestamps=df.index,

            train=train,
            val=val,
            test=test,

            train_ts=ts_splits[0],
            val_ts=ts_splits[1],
            test_ts=ts_splits[2],

            scaler=scaler,

            feature_matrix=feature_matrix,

            metadata={
                "source": str(path),
                "target_column": self.cfg.target_column,
                "resample_freq": self.cfg.resample_freq,
                "normalisation": self.cfg.normalisation,
                "window_size": self.cfg.window_size,
                "horizon": self.cfg.horizon,
            },

            stats=stats,
        )

        log.info(
            "csv_loader.done",
            total=len(series),
            train=len(train),
            val=len(val),
            test=len(test),
        )

        return ds

    # ─────────────────────────────────────────────────────────────────────────
    # Export
    # ─────────────────────────────────────────────────────────────────────────

    def export_npy(
        self,
        ds: LoadedDataset,
        output_dir: Optional[str] = None
    ) -> Dict[str, str]:

        out = Path(output_dir or self.cfg.output_dir)

        out.mkdir(
            parents=True,
            exist_ok=True
        )

        paths = {}

        for name, arr in [
            ("train", ds.train),
            ("val", ds.val),
            ("test", ds.test),
            ("full", ds.series),
        ]:

            p = out / f"{name}.npy"

            np.save(p, arr)

            paths[name] = str(p)

            log.info(
                "csv_loader.saved",
                split=name,
                path=str(p),
                shape=arr.shape
            )

        # timestamps
        ts_path = out / "timestamps.csv"

        ds.timestamps.to_frame(
            name="timestamp"
        ).to_csv(ts_path)

        paths["timestamps"] = str(ts_path)

        # metadata
        import json

        meta_path = out / "metadata.json"

        meta = {
            **ds.metadata,
            "stats": ds.stats,
            "split_sizes": {
                "train": len(ds.train),
                "val": len(ds.val),
                "test": len(ds.test),
            }
        }

        meta_path.write_text(
            json.dumps(meta, indent=2)
        )

        paths["metadata"] = str(meta_path)

        return paths

    # ─────────────────────────────────────────────────────────────────────────
    # Inverse transform
    # ─────────────────────────────────────────────────────────────────────────

    def inverse_transform(
        self,
        values: np.ndarray
    ) -> np.ndarray:

        if (
            self.cfg.normalisation == "none"
            or self._scaler is None
        ):
            return values

        reshaped = values.reshape(-1, 1)

        return self._scaler.inverse_transform(
            reshaped
        ).flatten()

    # ─────────────────────────────────────────────────────────────────────────
    # Read CSV
    # ─────────────────────────────────────────────────────────────────────────

    def _read(self, path: Path) -> pd.DataFrame:

        for sep in [",", ";", "\t", "|"]:

            try:
                df = pd.read_csv(
                    path,
                    sep=sep,
                    encoding="utf-8",
                    low_memory=False
                )

                if len(df.columns) > 1:
                    return df

            except Exception:
                continue

        return pd.read_csv(
            path,
            encoding="latin-1"
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Timestamp parsing
    # ─────────────────────────────────────────────────────────────────────────

    def _parse_timestamps(self, df):
        """
        Enterprise-grade timestamp parser.

        Handles:
        - integer column names
        - malformed timestamps
        - duplicate timestamps
        - mixed timestamp formats
        - automatic detection
        - timezone-safe parsing
        """

        import pandas as pd

        # ------------------------------------------------------------
        # Ensure ALL column names are strings
        # ------------------------------------------------------------
        df.columns = [str(c).strip() for c in df.columns]

        # ------------------------------------------------------------
        # Timestamp column selection
        # ------------------------------------------------------------
        ts_col = self.cfg.timestamp_column

        if ts_col is not None:
            ts_col = str(ts_col).strip()

            if ts_col not in df.columns:
                raise ValueError(
                    f"Timestamp column '{ts_col}' not found.\n"
                    f"Available columns: {list(df.columns)}"
                )

        else:

            timestamp_keywords = [
                "time",
                "timestamp",
                "date",
                "datetime",
                "created",
                "ts",
            ]

            candidates = []

            for c in df.columns:

                c_lower = str(c).lower()

                if any(k in c_lower for k in timestamp_keywords):
                    candidates.append(c)

            if not candidates:
                candidates = [df.columns[0]]

            ts_col = candidates[0]

        # ------------------------------------------------------------
        # Parse timestamps
        # ------------------------------------------------------------

        sample_value = str(df[ts_col].iloc[0])

        # Detect likely format
        if ":" in sample_value and "-" in sample_value:

            # Example:
            # 01-01-2025 00:00
            # 01-01-2025 00:00:00

            if len(sample_value.split(":")) == 2:

                timestamp_format = "%d-%m-%Y %H:%M"

            else:

                timestamp_format = "%d-%m-%Y %H:%M:%S"

        else:

            timestamp_format = None

        df[ts_col] = pd.to_datetime(
            df[ts_col],
            format=timestamp_format,
            errors="coerce",
            dayfirst=True,
        )

        # ------------------------------------------------------------
        # Stats BEFORE cleaning
        # ------------------------------------------------------------

        invalid_count = int(df[ts_col].isna().sum())

        log.info(
            "csv_loader.timestamp_stats",
            total_rows=len(df),
            invalid_timestamps=invalid_count,
            unique_timestamps=int(df[ts_col].nunique()),
        )

        # ------------------------------------------------------------
        # Drop invalid timestamps
        # ------------------------------------------------------------

        before_rows = len(df)

        df = df.dropna(subset=[ts_col])

        after_dropna = len(df)

        # ------------------------------------------------------------
        # Remove duplicate timestamps
        # ------------------------------------------------------------

        before_dedup = len(df)

        df = df.drop_duplicates(subset=[ts_col])

        after_dedup = len(df)

        # ------------------------------------------------------------
        # Sort chronologically
        # ------------------------------------------------------------

        df = df.sort_values(ts_col)

        # ------------------------------------------------------------
        # Set datetime index
        # ------------------------------------------------------------

        df = df.set_index(ts_col)

        # ------------------------------------------------------------
        # Final logging
        # ------------------------------------------------------------

        log.info(
            "csv_loader.timestamp_cleanup",
            original_rows=before_rows,
            after_dropna=after_dropna,
            after_dedup=after_dedup,
            final_rows=len(df),
        )

        return df

    # ─────────────────────────────────────────────────────────────────────────
    # Validation
    # ─────────────────────────────────────────────────────────────────────────

    def _validate_columns(
        self,
        df: pd.DataFrame
    ):

        if self.cfg.target_column not in df.columns:

            available = list(df.columns)

            raise ValueError(
                f"Target column '{self.cfg.target_column}' "
                f"not found. Available columns: {available}"
            )

        # Convert target to numeric
        df[self.cfg.target_column] = pd.to_numeric(
            df[self.cfg.target_column],
            errors="coerce"
        )

        before = len(df)

        # Remove invalid targets
        df.dropna(
            subset=[self.cfg.target_column],
            inplace=True
        )

        after = len(df)

        log.info(
            "csv_loader.target_cleaning",
            removed_rows=before - after,
            remaining_rows=after
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Optional resampling
    # ─────────────────────────────────────────────────────────────────────────

    def _resample(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Resample dataframe only if explicitly configured.
        """

        # Skip resampling entirely
        if self.cfg.resample_freq is None:
            log.info("csv_loader.resample_skipped")
            return df

        agg = self.cfg.aggregation_method

        numeric_cols = df.select_dtypes(
            include=[np.number]
        ).columns.tolist()

        df_num = df[numeric_cols].apply(
            pd.to_numeric,
            errors="coerce"
        )

        freq = (
            self.cfg.resample_freq
            .replace("H", "h")
            .replace("T", "min")
            .replace("M", "ME")
        )

        agg_fn = {
            "mean": lambda x: x.resample(freq).mean(),
            "sum": lambda x: x.resample(freq).sum(),
            "last": lambda x: x.resample(freq).last(),
            "first": lambda x: x.resample(freq).first(),
        }.get(agg, lambda x: x.resample(freq).mean())

        result = agg_fn(df_num)

        log.info(
            "csv_loader.resampled",
            original_rows=len(df),
            resampled_rows=len(result),
            freq=freq
        )

        return result

    # ─────────────────────────────────────────────────────────────────────────
    # Gap filling
    # ─────────────────────────────────────────────────────────────────────────

    def _fill_gaps(
        self,
        df: pd.DataFrame
    ) -> pd.DataFrame:

        method = self.cfg.interpolation_method
        limit = self.cfg.max_gap_fill_periods

        if method == "ffill":

            df = df.ffill(limit=limit)

        elif method == "bfill":

            df = df.bfill(limit=limit)

        else:

            df = df.infer_objects(copy=False)

            df = df.interpolate(
                method=method,
                limit=limit,
                limit_direction="both"
            )

        # Fill remaining edge NaNs
        df = df.bfill().ffill().infer_objects(copy=False)

        return df

    # ─────────────────────────────────────────────────────────────────────────
    # Normalisation
    # ─────────────────────────────────────────────────────────────────────────

    def _normalise(
        self,
        series: np.ndarray
    ) -> Tuple[np.ndarray, object]:

        method = self.cfg.normalisation

        x = series.reshape(-1, 1)

        if method == "zscore":

            scaler = StandardScaler()

        elif method == "minmax":

            scaler = MinMaxScaler(
                feature_range=(-1, 1)
            )

        elif method == "robust":

            scaler = RobustScaler()

        elif method == "none":

            return series.astype(np.float32), None

        else:

            scaler = StandardScaler()

        normalised = scaler.fit_transform(
            x
        ).flatten().astype(np.float32)

        self._scaler = scaler

        return normalised, scaler

    # ─────────────────────────────────────────────────────────────────────────
    # Features
    # ─────────────────────────────────────────────────────────────────────────

    def _build_features(
        self,
        df: pd.DataFrame
    ) -> Optional[np.ndarray]:

        cols = [
            c for c in self.cfg.feature_columns
            if c in df.columns
        ]

        if not cols:
            return None

        feat = df[cols].values.astype(
            np.float32
        )

        scaler = StandardScaler()

        return scaler.fit_transform(feat)

    # ─────────────────────────────────────────────────────────────────────────
    # Train / Val / Test Split
    # ─────────────────────────────────────────────────────────────────────────

    def _split(
        self,
        series: np.ndarray,
        timestamps: pd.DatetimeIndex,
    ) -> Tuple[
        np.ndarray,
        np.ndarray,
        np.ndarray,
        Tuple
    ]:

        n = len(series)

        train_end = int(
            n * self.cfg.train_ratio
        )

        val_end = train_end + int(
            n * self.cfg.val_ratio
        )

        train = series[:train_end]

        val = series[train_end:val_end]

        test = series[val_end:]

        return (
            train,
            val,
            test,
            (
                timestamps[:train_end],
                timestamps[train_end:val_end],
                timestamps[val_end:],
            ),
        )


# ─────────────────────────────────────────────────────────────────────────────
# CSV Preview Helper
# ─────────────────────────────────────────────────────────────────────────────

def preview_csv(
    csv_path: str,
    n_rows: int = 5
) -> Dict:

    df = pd.read_csv(
        csv_path,
        nrows=n_rows * 4
    )

    timestamp_candidates = [
        c for c in df.columns
        if any(
            kw in c.lower()
            for kw in [
                "time",
                "date",
                "ts",
                "dt",
            ]
        )
    ]

    numeric_candidates = df.select_dtypes(
        include=[np.number]
    ).columns.tolist()

    return {
        "columns": list(df.columns),
        "dtypes": df.dtypes.astype(str).to_dict(),
        "shape": df.shape,
        "sample": df.head(n_rows).to_dict(
            orient="records"
        ),
        "timestamp_candidates": timestamp_candidates,
        "numeric_candidates": numeric_candidates,
        "null_counts": df.isnull().sum().to_dict(),
    }