"""
Enterprise Temporal AI Platform — Anomaly Detection Service
"""

from __future__ import annotations

import time
from contextlib import asynccontextmanager
from typing import AsyncGenerator

import redis.asyncio as aioredis
import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from prometheus_client import Counter, Histogram, make_asgi_app

from shared.config.settings import settings
from shared.logging.logger import configure_logging, get_logger, set_request_context

configure_logging(
    service_name="anomaly-service",
    log_level=settings.LOG_LEVEL,
    json_output=settings.is_production,
)
log = get_logger("anomaly_service")

ANOMALY_COUNTER = Counter(
    "anomaly_detections_total",
    "Total anomaly detection requests",
    ["tenant_id", "method", "detected"],
)
ANOMALY_LATENCY = Histogram(
    "anomaly_detection_latency_seconds",
    "Anomaly detection latency",
    ["tenant_id", "method"],
)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator:
    log.info("anomaly_service.startup")
    app.state.redis = aioredis.from_url(
        settings.REDIS_URL,
        encoding="utf-8",
        decode_responses=True,
        max_connections=20,
    )
    await app.state.redis.ping()
    yield
    await app.state.redis.aclose()
    log.info("anomaly_service.shutdown")


def create_app() -> FastAPI:
    app = FastAPI(
        title="Temporal AI — Anomaly Detection Service",
        description=(
            "Hybrid anomaly detection: residual-based, autoencoder reconstruction, "
            "isolation forest, and drift-aware scoring."
        ),
        version="1.0.0",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.middleware("http")
    async def context_middleware(request: Request, call_next):
        set_request_context(
            request.headers.get("X-Request-ID"),
            request.headers.get("X-Tenant-ID"),
            request.headers.get("X-User-ID"),
        )
        start = time.perf_counter()
        response = await call_next(request)
        elapsed = (time.perf_counter() - start) * 1000
        log.info(
            "http.request",
            method=request.method,
            path=request.url.path,
            status=response.status_code,
            elapsed_ms=round(elapsed, 2),
        )
        return response

    @app.exception_handler(Exception)
    async def global_exc_handler(request: Request, exc: Exception):
        log.error("unhandled_exception", exc=str(exc))
        return JSONResponse(status_code=500, content={"status": "error", "message": str(exc)})

    # ── Routers ───────────────────────────────────────────────────────────────
    from routers import anomaly, alerts
    app.include_router(anomaly.router, prefix="/v1", tags=["Anomaly Detection"])
    app.include_router(alerts.router, prefix="/v1", tags=["Alerts"])

    metrics_app = make_asgi_app()
    app.mount("/metrics", metrics_app)

    @app.get("/health", tags=["Health"])
    async def health(request: Request):
        try:
            await request.app.state.redis.ping()
            redis_status = "ok"
        except Exception:
            redis_status = "unreachable"
        return {
            "status": "healthy" if redis_status == "ok" else "degraded",
            "service": "anomaly-service",
            "version": "1.0.0",
            "dependencies": {"redis": redis_status},
        }

    return app


app = create_app()

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=settings.ANOMALY_SERVICE_PORT,
        reload=not settings.is_production,
    )
