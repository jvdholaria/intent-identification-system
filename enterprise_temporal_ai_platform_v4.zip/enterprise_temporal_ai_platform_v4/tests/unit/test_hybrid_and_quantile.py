"""
Unit tests — Hybrid Anomaly Scorer & Quantile Loss
"""

import pytest
import torch
import numpy as np

from anomaly.hybrid.scorer import HybridAnomalyScorer, IsolationForestDetector
from forecasting.quantile.loss import QuantileLoss, CombinedForecastLoss


class TestHybridAnomalyScorer:
    def test_weights_must_sum_to_one(self):
        with pytest.raises(AssertionError):
            HybridAnomalyScorer(0.5, 0.5, 0.5)   # sums to 1.5

    def test_score_point(self):
        scorer = HybridAnomalyScorer()
        score = scorer.score_point(2.0, 1.0, 0.5)
        expected = 0.5 * 2.0 + 0.3 * 1.0 + 0.2 * 0.5
        assert abs(score - expected) < 1e-6

    def test_negative_scores_clipped_to_zero(self):
        scorer = HybridAnomalyScorer()
        score = scorer.score_point(-1.0, -2.0, -3.0)
        assert score == 0.0

    def test_batch_score_returns_correct_length(self):
        scorer = HybridAnomalyScorer()
        n = 100
        res = [1.0] * n
        rec = [0.5] * n
        dri = [0.2] * n
        scores = scorer.score_batch(res, rec, dri)
        assert len(scores) == n

    def test_adaptive_threshold(self):
        scorer = HybridAnomalyScorer()
        scores = [0.1, 0.2, 0.8, 0.1, 5.0, 0.15]   # 5.0 is the outlier
        threshold = scorer.adaptive_threshold(scores, contamination=0.1)
        # The threshold should be set below the outlier 5.0
        assert threshold < 5.0

    def test_mismatched_lengths_raise(self):
        scorer = HybridAnomalyScorer()
        with pytest.raises(AssertionError):
            scorer.score_batch([1.0, 2.0], [1.0], [1.0, 2.0])


class TestIsolationForestDetector:
    def test_not_fitted_returns_zeros(self):
        iso = IsolationForestDetector()
        features = np.random.randn(10, 3)
        scores = iso.score(features)
        assert all(s == 0.0 for s in scores)

    def test_fit_and_score(self):
        np.random.seed(42)
        iso = IsolationForestDetector(contamination=0.1)
        train = np.random.randn(200, 3)
        iso.fit(train)
        test = np.random.randn(50, 3)
        scores = iso.score(test)
        assert len(scores) == 50
        assert all(0.0 <= s <= 1.0 for s in scores)

    def test_outliers_get_higher_scores(self):
        np.random.seed(42)
        iso = IsolationForestDetector(contamination=0.05)
        normal = np.random.randn(500, 3)
        iso.fit(normal)
        inlier = np.array([[0.1, 0.2, -0.1]])
        outlier = np.array([[100.0, 100.0, 100.0]])
        score_in = iso.score(inlier)[0]
        score_out = iso.score(outlier)[0]
        assert score_out > score_in


class TestQuantileLoss:
    def test_loss_returns_scalar(self):
        loss_fn = QuantileLoss([0.1, 0.5, 0.9])
        preds = torch.randn(8, 24, 3)
        target = torch.randn(8, 24)
        loss = loss_fn(preds, target)
        assert loss.shape == torch.Size([])

    def test_perfect_p50_low_loss(self):
        """When p50 predictions equal targets, loss should be low."""
        loss_fn = QuantileLoss([0.5])
        target = torch.ones(4, 12)
        preds = target.unsqueeze(-1)   # (4, 12, 1)
        loss = loss_fn(preds, target)
        assert float(loss) < 1e-4

    def test_loss_non_negative(self):
        loss_fn = QuantileLoss([0.1, 0.5, 0.9])
        preds = torch.randn(4, 10, 3)
        target = torch.randn(4, 10)
        loss = loss_fn(preds, target)
        assert float(loss) >= 0.0


class TestCombinedForecastLoss:
    def test_combined_loss_scalar(self):
        loss_fn = CombinedForecastLoss()
        preds = torch.randn(8, 24, 3)
        target = torch.randn(8, 24)
        loss = loss_fn(preds, target)
        assert loss.shape == torch.Size([])

    def test_alpha_zero_uses_only_quantile(self):
        loss_fn_q = CombinedForecastLoss(alpha=0.0)
        loss_fn_q_only = QuantileLoss()
        preds = torch.randn(4, 12, 3)
        target = torch.randn(4, 12)
        assert abs(float(loss_fn_q(preds, target)) - float(loss_fn_q_only(preds, target))) < 1e-4
