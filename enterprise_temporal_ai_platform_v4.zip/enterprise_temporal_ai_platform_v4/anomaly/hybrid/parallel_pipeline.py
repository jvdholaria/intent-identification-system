"""
Enterprise Temporal AI Platform — Parallel Anomaly Pipeline

Runs residual scoring, reconstruction scoring, and drift scoring
concurrently in the CPU thread pool, then merges with hybrid weighting.

Before (sequential):   residual → reconstruction → drift  ≈ 3× unit_time
After  (parallel):     all three at once               ≈ 1× unit_time
"""

from __future__ import annotations

import asyncio
from typing import Dict, List, Optional

import numpy as np

from shared.logging.logger import get_logger
from shared.utilities.thread_pool import cpu_executor

log = get_logger("anomaly.parallel_pipeline")


class ParallelAnomalyPipeline:
    """
    Drop-in replacement for EnsembleAnomalyPipeline that runs all three
    detectors concurrently using the CPU thread pool.
    """

    def __init__(
        self,
        residual_weight: float = 0.5,
        reconstruction_weight: float = 0.3,
        drift_weight: float = 0.2,
        threshold_sigma: float = 3.0,
    ):
        self.w_res  = residual_weight
        self.w_rec  = reconstruction_weight
        self.w_drift = drift_weight
        self.threshold_sigma = threshold_sigma

    async def run_async(
        self,
        actual: List[float],
        predicted: List[float],
        feature_matrix: Optional[np.ndarray] = None,
        drift_scores: Optional[List[float]] = None,
    ) -> Dict:
        """
        Async entry point — submits all three detectors to the CPU pool
        concurrently and awaits them with asyncio.gather().
        """
        loop = asyncio.get_event_loop()

        # ── Submit all three jobs concurrently ────────────────────────────────
        fut_residual       = loop.run_in_executor(cpu_executor(), self._residual_score, actual, predicted)
        fut_reconstruction = loop.run_in_executor(cpu_executor(), self._reconstruction_score, actual)
        fut_isolation      = loop.run_in_executor(cpu_executor(), self._isolation_score, actual, predicted, feature_matrix)

        residual_scores, reconstruction_scores, iso_predictions = await asyncio.gather(
            fut_residual, fut_reconstruction, fut_isolation
        )

        # ── Drift scores (already computed upstream, or default to 0) ─────────
        d_scores = drift_scores or [0.0] * len(actual)

        # ── Hybrid merge ─────────────────────────────────────────────────────
        final_scores = self._hybrid_merge(residual_scores, reconstruction_scores, d_scores)

        threshold    = self._adaptive_threshold(final_scores)
        is_anomaly   = [s > threshold for s in final_scores]

        return {
            "final_scores":          final_scores,
            "residual_scores":       residual_scores,
            "reconstruction_scores": reconstruction_scores,
            "drift_scores":          d_scores,
            "is_anomaly":            is_anomaly,
            "iso_forest_anomaly":    iso_predictions,
            "threshold":             round(threshold, 4),
        }

    # ── CPU-bound workers (called inside thread pool) ─────────────────────────

    def _residual_score(self, actual: List[float], predicted: List[float]) -> List[float]:
        from anomaly.residual.detector import ResidualDetector
        return ResidualDetector(threshold_sigma=self.threshold_sigma).score(actual, predicted)

    def _reconstruction_score(self, actual: List[float]) -> List[float]:
        """
        Lightweight reconstruction scoring using rolling z-score as a
        proxy when the full autoencoder is not loaded (fast CPU path).
        """
        arr = np.array(actual, dtype=np.float64)
        window = min(24, len(arr))
        scores = np.zeros(len(arr))
        for i in range(len(arr)):
            start = max(0, i - window)
            w = arr[start:i + 1]
            mu, sigma = w.mean(), w.std() or 1.0
            scores[i] = abs(arr[i] - mu) / sigma
        # Normalise
        mu_s, sigma_s = scores.mean(), scores.std() or 1.0
        return [round(float((s - mu_s) / sigma_s), 4) for s in scores]

    def _isolation_score(
        self,
        actual: List[float],
        predicted: List[float],
        feature_matrix: Optional[np.ndarray],
    ) -> List[bool]:
        if feature_matrix is None or len(feature_matrix) != len(actual):
            return [False] * len(actual)
        from anomaly.hybrid.scorer import IsolationForestDetector
        iso = IsolationForestDetector()
        iso.fit(feature_matrix)
        return iso.predict(feature_matrix)

    def _hybrid_merge(
        self,
        residual:       List[float],
        reconstruction: List[float],
        drift:          List[float],
    ) -> List[float]:
        return [
            round(
                self.w_res   * max(r, 0.0)
              + self.w_rec   * max(rc, 0.0)
              + self.w_drift * max(d, 0.0),
                4,
            )
            for r, rc, d in zip(residual, reconstruction, drift)
        ]

    def _adaptive_threshold(self, scores: List[float], contamination: float = 0.05) -> float:
        return float(np.quantile(np.array(scores), 1.0 - contamination))

    # ── Sync wrapper for callers that can't await ─────────────────────────────

    def run(
        self,
        actual: List[float],
        predicted: List[float],
        feature_matrix: Optional[np.ndarray] = None,
        drift_scores: Optional[List[float]] = None,
    ) -> Dict:
        """Synchronous entry point — creates an event loop if necessary."""
        try:
            loop = asyncio.get_running_loop()
            # Already inside an event loop (FastAPI / async context)
            import concurrent.futures
            future = asyncio.run_coroutine_threadsafe(
                self.run_async(actual, predicted, feature_matrix, drift_scores), loop
            )
            return future.result(timeout=60)
        except RuntimeError:
            # No running loop — safe to use asyncio.run()
            return asyncio.run(
                self.run_async(actual, predicted, feature_matrix, drift_scores)
            )
