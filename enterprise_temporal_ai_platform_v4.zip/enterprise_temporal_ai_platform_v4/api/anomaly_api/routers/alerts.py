"""
Enterprise Temporal AI Platform — Alert Router
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from shared.logging.logger import get_logger
from shared.schemas.schemas import AnomalyDetail

log = get_logger("anomaly.alerts")
router = APIRouter()


async def get_redis(request: Request):
    return request.app.state.redis


@router.get(
    "/alerts/{tenant_id}",
    summary="Retrieve recent alerts for a tenant",
)
async def get_alerts(
    tenant_id: str,
    limit: int = 50,
    severity: str = "all",
    redis=Depends(get_redis),
):
    """
    Retrieve the most recent anomaly alerts stored in Redis
    for the given tenant. Optionally filter by severity level.
    """
    key = f"temporal:tenant:{tenant_id}:alerts"
    raw_alerts = await redis.lrange(key, 0, limit - 1)

    import json
    alerts = []
    for raw in raw_alerts:
        try:
            alert = json.loads(raw)
            if severity == "all" or alert.get("severity") == severity:
                alerts.append(alert)
        except Exception:
            continue

    return {
        "tenant_id": tenant_id,
        "count": len(alerts),
        "alerts": alerts,
    }


@router.delete(
    "/alerts/{tenant_id}/clear",
    summary="Clear alert queue for a tenant",
)
async def clear_alerts(tenant_id: str, redis=Depends(get_redis)):
    key = f"temporal:tenant:{tenant_id}:alerts"
    await redis.delete(key)
    log.info("alerts.cleared", tenant_id=tenant_id)
    return {"status": "ok", "tenant_id": tenant_id, "cleared": True}
