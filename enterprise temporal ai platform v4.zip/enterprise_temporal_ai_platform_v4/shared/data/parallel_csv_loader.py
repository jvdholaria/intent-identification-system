"""
Enterprise Temporal AI Platform — Parallel CSV Loader

Speeds up large CSV ingestion by:
1. Reading the file in parallel chunks using ThreadPoolExecutor
2. Running normalisation / feature engineering on each split concurrently
3. Overlapping disk IO with CPU preprocessing

Inherits from CSVTemporalLoader — same public API, just faster for large files.
"""

from __future__ import annotations

import math
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from shared.data.csv_loader import CSVLoaderConfig, CSVTemporalLoader, LoadedDataset
from shared.logging.logger import get_logger
from shared.utilities.thread_pool import cpu_executor, io_executor

log = get_logger("data.parallel_csv_loader")

# Files smaller than this are loaded single-threaded (overhead not worth it)
_PARALLEL_THRESHOLD_ROWS = 50_000
_CHUNK_SIZE = 10_000


class ParallelCSVLoader(CSVTemporalLoader):
    """
    Parallel CSV loader. For files under 50k rows, falls back to the
    standard single-threaded loader transparently.
    """

    def load(self, csv_path: str) -> LoadedDataset:
        path = Path(csv_path)
        if not path.exists():
            raise FileNotFoundError(f"CSV not found: {csv_path}")

        # Quick row count (read only first column headers + line count)
        n_rows = self._count_rows(path)
        log.info("parallel_loader.start", path=str(path), rows=n_rows)

        if n_rows < _PARALLEL_THRESHOLD_ROWS:
            log.info("parallel_loader.small_file — using standard loader")
            return super().load(csv_path)

        return self._load_parallel(path, n_rows)

    def _load_parallel(self, path: Path, n_rows: int) -> LoadedDataset:
        """
        Chunked parallel read → merge → standard processing pipeline.
        """
        n_chunks = max(2, math.ceil(n_rows / _CHUNK_SIZE))
        log.info("parallel_loader.chunked", chunks=n_chunks, chunk_size=_CHUNK_SIZE)

        # ── Step 1: Read all chunks concurrently using IO pool ────────────────
        chunks = self._read_chunks_parallel(path, n_chunks)

        # ── Step 2: Merge into single DataFrame ───────────────────────────────
        df = pd.concat(chunks, ignore_index=True)
        log.info("parallel_loader.merged", rows=len(df))

        # ── Step 3: Standard pipeline (timestamp, resample, gaps, normalise) ──
        df = self._parse_timestamps(df)
        self._validate_columns(df)
        df = self._resample(df)
        df = self._fill_gaps(df)

        raw = df[self.cfg.target_column].values.astype(np.float64)
        stats = {
            "mean": float(np.mean(raw)),
            "std":  float(np.std(raw)),
            "min":  float(np.min(raw)),
            "max":  float(np.max(raw)),
            "count": len(raw),
            "null_count": int(np.isnan(raw).sum()),
        }

        series, scaler = self._normalise(raw)

        # ── Step 4: Feature engineering runs concurrently on each split ───────
        feature_matrix = self._build_features_parallel(df, series)

        train, val, test, ts_splits = self._split(series, df.index)

        return LoadedDataset(
            series=series, timestamps=df.index,
            train=train, val=val, test=test,
            train_ts=ts_splits[0], val_ts=ts_splits[1], test_ts=ts_splits[2],
            scaler=scaler,
            feature_matrix=feature_matrix,
            metadata={
                "source": str(path),
                "target_column": self.cfg.target_column,
                "resample_freq": self.cfg.resample_freq,
                "normalisation": self.cfg.normalisation,
                "window_size": self.cfg.window_size,
                "horizon": self.cfg.horizon,
                "parallel": True,
                "n_chunks": n_chunks,
            },
            stats=stats,
        )

    def _read_chunks_parallel(self, path: Path, n_chunks: int) -> List[pd.DataFrame]:
        """
        Parallel CSV reading with proper shared headers.
        """

        # Read columns ONCE
        columns = pd.read_csv(path, nrows=0).columns.tolist()

        def read_chunk(skip: int, nrows: int) -> pd.DataFrame:
            return pd.read_csv(
                path,
                skiprows=range(1, skip + 1) if skip > 0 else None,
                nrows=nrows,
                encoding="utf-8",
                low_memory=False,
                names=columns,
                header=0,
            )

        futures = {}

        with ThreadPoolExecutor(
            max_workers=min(n_chunks, 8),
            thread_name_prefix="temporal-csv-read",
        ) as pool:

            for i in range(n_chunks):
                skip = i * _CHUNK_SIZE
                nrows = _CHUNK_SIZE

                fut = pool.submit(read_chunk, skip, nrows)
                futures[fut] = i

            ordered: Dict[int, pd.DataFrame] = {}

            for fut in as_completed(futures):
                idx = futures[fut]

                try:
                    ordered[idx] = fut.result()

                except Exception as exc:
                    log.warning(
                        "chunk_read_failed",
                        chunk=idx,
                        exc=str(exc)
                    )

        return [ordered[i] for i in sorted(ordered.keys())]

    def _build_features_parallel(
        self,
        df: pd.DataFrame,
        series: np.ndarray,
    ) -> Optional[np.ndarray]:
        """
        Build feature matrix for each covariate column concurrently,
        then concatenate column-wise.
        """
        cols = [c for c in self.cfg.feature_columns if c in df.columns]
        if not cols:
            return None

        from sklearn.preprocessing import StandardScaler

        def normalise_col(col_name: str) -> np.ndarray:
            vals = df[col_name].values.reshape(-1, 1).astype(np.float32)
            return StandardScaler().fit_transform(vals).flatten()

        loop_futures = {
            col: cpu_executor().submit(normalise_col, col)
            for col in cols
        }

        result_cols = []
        for col in cols:
            try:
                result_cols.append(loop_futures[col].result(timeout=30).reshape(-1, 1))
            except Exception as exc:
                log.warning("feature_col_failed", col=col, exc=str(exc))

        if not result_cols:
            return None
        return np.hstack(result_cols).astype(np.float32)

    @staticmethod
    def _count_rows(path: Path) -> int:
        """Count rows without loading the full file into memory."""
        try:
            with open(path, "rb") as f:
                return sum(1 for _ in f) - 1  # subtract header
        except Exception:
            return 0
