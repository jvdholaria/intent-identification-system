"""
Enterprise Temporal AI Platform — Parallel Drift Detector

Runs all four drift techniques (PSI, KS, Wasserstein, Residual)
concurrently in the CPU thread pool.

Before: PSI → KS → Wasserstein → Concept  (sequential, ~4× unit_time)
After:  all four submitted at once         (~1× unit_time)
"""

from __future__ import annotations

import asyncio
from typing import List, Optional

import numpy as np

from anomaly.drift.drift_detector import (
    DriftDetector,
    compute_concept_drift,
    compute_ks,
    compute_psi,
    compute_wasserstein,
)
from shared.logging.logger import get_logger
from shared.schemas.schemas import DriftResult, DriftType
from shared.utilities.thread_pool import cpu_executor

log = get_logger("anomaly.parallel_drift")


class ParallelDriftDetector(DriftDetector):
    """
    Subclass of DriftDetector that runs all techniques concurrently.
    Drop-in replacement: same public API, faster execution.
    """

    async def detect_async(
        self,
        baseline: List[float],
        current: List[float],
        drift_types: Optional[List[DriftType]] = None,
    ) -> List[DriftResult]:
        """
        Async version of detect() — submits all techniques to CPU pool
        concurrently and collects results.
        """
        b = np.array(baseline, dtype=np.float64)
        c = np.array(current,  dtype=np.float64)
        active = drift_types or list(DriftType)
        loop   = asyncio.get_event_loop()

        futures = {}

        if DriftType.data_drift in active:
            futures[DriftType.data_drift] = loop.run_in_executor(
                cpu_executor(), compute_psi, b, c
            )

        if DriftType.feature_drift in active:
            futures[DriftType.feature_drift] = loop.run_in_executor(
                cpu_executor(), compute_ks, b, c
            )

        if DriftType.distribution_drift in active:
            futures[DriftType.distribution_drift] = loop.run_in_executor(
                cpu_executor(), compute_wasserstein, b, c
            )

        if DriftType.concept_drift in active:
            futures[DriftType.concept_drift] = loop.run_in_executor(
                cpu_executor(), compute_concept_drift, b, c
            )

        # Await all concurrently
        awaited = {k: await v for k, v in futures.items()}
        results: List[DriftResult] = []

        if DriftType.data_drift in awaited:
            psi = awaited[DriftType.data_drift]
            results.append(DriftResult(
                drift_type=DriftType.data_drift,
                detected=psi >= self.psi_threshold,
                score=psi,
                threshold=self.psi_threshold,
                technique="PSI",
                detail={"interpretation": "significant" if psi >= 0.2 else "moderate" if psi >= 0.1 else "negligible"},
            ))

        if DriftType.feature_drift in awaited:
            ks_stat, p_value = awaited[DriftType.feature_drift]
            results.append(DriftResult(
                drift_type=DriftType.feature_drift,
                detected=p_value < self.ks_pvalue_threshold,
                score=ks_stat,
                threshold=self.ks_pvalue_threshold,
                technique="KS Test",
                p_value=p_value,
                detail={"ks_statistic": ks_stat, "p_value": p_value},
            ))

        if DriftType.distribution_drift in awaited:
            wass = awaited[DriftType.distribution_drift]
            wass_norm = wass / (b.std() or 1.0)
            results.append(DriftResult(
                drift_type=DriftType.distribution_drift,
                detected=wass_norm >= self.wasserstein_threshold,
                score=round(wass_norm, 6),
                threshold=self.wasserstein_threshold,
                technique="Wasserstein Distance",
                detail={"raw_distance": wass},
            ))

        if DriftType.concept_drift in awaited:
            z = awaited[DriftType.concept_drift]
            results.append(DriftResult(
                drift_type=DriftType.concept_drift,
                detected=z >= self.concept_z_threshold,
                score=z,
                threshold=self.concept_z_threshold,
                technique="Residual Monitoring (Z-score)",
            ))

        return results

    def detect(
        self,
        baseline: List[float],
        current: List[float],
        drift_types: Optional[List[DriftType]] = None,
    ) -> List[DriftResult]:
        """Sync wrapper — uses the parallel async implementation."""
        try:
            loop = asyncio.get_running_loop()
            import concurrent.futures
            future = asyncio.run_coroutine_threadsafe(
                self.detect_async(baseline, current, drift_types), loop
            )
            return future.result(timeout=30)
        except RuntimeError:
            return asyncio.run(self.detect_async(baseline, current, drift_types))
