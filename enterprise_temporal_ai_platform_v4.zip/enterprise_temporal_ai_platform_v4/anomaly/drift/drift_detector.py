"""
Enterprise Temporal AI Platform — Drift Detection Engine

| Type              | Technique             |
|-------------------|-----------------------|
| Data Drift        | PSI                   |
| Feature Drift     | KS Test               |
| Concept Drift     | Residual Monitoring   |
| Embedding Drift   | Cosine Similarity     |
| Distribution Drift| Wasserstein Distance  |
"""

from __future__ import annotations

import math
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy import stats
from scipy.spatial.distance import cosine
from scipy.stats import wasserstein_distance

from shared.config.settings import settings
from shared.logging.logger import get_logger
from shared.schemas.schemas import DriftResult, DriftType

log = get_logger("anomaly.drift")


# ─────────────────────────────────────────────────────────────────────────────
# PSI — Population Stability Index (Data Drift)
# ─────────────────────────────────────────────────────────────────────────────

def compute_psi(
    baseline: np.ndarray,
    current: np.ndarray,
    buckets: int = 10,
    epsilon: float = 1e-4,
) -> float:
    """
    PSI = Σ (current_pct - baseline_pct) * ln(current_pct / baseline_pct)

    Interpretation:
      PSI < 0.1  → negligible drift
      PSI < 0.2  → moderate drift
      PSI ≥ 0.2  → significant drift
    """
    min_val = min(baseline.min(), current.min())
    max_val = max(baseline.max(), current.max())
    bins = np.linspace(min_val, max_val, buckets + 1)

    baseline_pct = np.histogram(baseline, bins=bins)[0] / len(baseline) + epsilon
    current_pct = np.histogram(current, bins=bins)[0] / len(current) + epsilon

    psi = np.sum((current_pct - baseline_pct) * np.log(current_pct / baseline_pct))
    return round(float(psi), 6)


# ─────────────────────────────────────────────────────────────────────────────
# KS Test — Kolmogorov–Smirnov (Feature Drift)
# ─────────────────────────────────────────────────────────────────────────────

def compute_ks(
    baseline: np.ndarray,
    current: np.ndarray,
) -> Tuple[float, float]:
    """
    Two-sample KS test.
    Returns (statistic, p_value).
    Low p-value → distributions are significantly different.
    """
    stat, p_value = stats.ks_2samp(baseline, current)
    return round(float(stat), 6), round(float(p_value), 6)


# ─────────────────────────────────────────────────────────────────────────────
# Wasserstein Distance (Distribution Drift)
# ─────────────────────────────────────────────────────────────────────────────

def compute_wasserstein(
    baseline: np.ndarray,
    current: np.ndarray,
) -> float:
    """
    Earth Mover's Distance between two distributions.
    """
    dist = wasserstein_distance(baseline, current)
    return round(float(dist), 6)


# ─────────────────────────────────────────────────────────────────────────────
# Cosine Similarity (Embedding Drift)
# ─────────────────────────────────────────────────────────────────────────────

def compute_embedding_drift(
    baseline_embedding: np.ndarray,
    current_embedding: np.ndarray,
) -> float:
    """
    Cosine distance between mean embedding vectors.
    Higher distance → more drift.
    """
    if baseline_embedding.ndim > 1:
        baseline_embedding = baseline_embedding.mean(axis=0)
    if current_embedding.ndim > 1:
        current_embedding = current_embedding.mean(axis=0)

    dist = cosine(baseline_embedding, current_embedding)
    return round(float(dist), 6)


# ─────────────────────────────────────────────────────────────────────────────
# Residual Monitoring (Concept Drift)
# ─────────────────────────────────────────────────────────────────────────────

def compute_concept_drift(
    residuals_baseline: np.ndarray,
    residuals_current: np.ndarray,
    window: int = 24,
) -> float:
    """
    Detect concept drift by comparing the residual error distributions
    between a baseline window and the current window.
    Returns a z-score indicating how much the mean residual has shifted.
    """
    mu_base = residuals_baseline.mean()
    sigma_base = residuals_baseline.std() or 1.0
    mu_curr = residuals_current[-window:].mean()
    z_score = abs(mu_curr - mu_base) / sigma_base
    return round(float(z_score), 6)


# ─────────────────────────────────────────────────────────────────────────────
# Drift Detector — Unified API
# ─────────────────────────────────────────────────────────────────────────────

class DriftDetector:
    """
    Unified drift detection engine. Runs all enabled drift techniques
    and returns structured DriftResult objects.
    """

    def __init__(
        self,
        psi_threshold: float = None,
        ks_pvalue_threshold: float = None,
        wasserstein_threshold: float = None,
        cosine_threshold: float = None,
        concept_drift_z_threshold: float = 3.0,
    ):
        self.psi_threshold = psi_threshold or settings.DRIFT_PSI_THRESHOLD
        self.ks_pvalue_threshold = ks_pvalue_threshold or settings.DRIFT_KS_PVALUE_THRESHOLD
        self.wasserstein_threshold = wasserstein_threshold or settings.DRIFT_WASSERSTEIN_THRESHOLD
        self.cosine_threshold = cosine_threshold or settings.DRIFT_COSINE_THRESHOLD
        self.concept_z_threshold = concept_drift_z_threshold

    def detect(
        self,
        baseline: List[float],
        current: List[float],
        drift_types: Optional[List[DriftType]] = None,
    ) -> List[DriftResult]:
        """
        Run all requested drift detection techniques.
        Returns a list of DriftResult objects.
        """
        baseline_arr = np.array(baseline, dtype=np.float64)
        current_arr = np.array(current, dtype=np.float64)

        active_types = drift_types or list(DriftType)
        results: List[DriftResult] = []

        # ── PSI (Data Drift) ──────────────────────────────────────────────────
        if DriftType.data_drift in active_types:
            psi = compute_psi(baseline_arr, current_arr)
            results.append(DriftResult(
                drift_type=DriftType.data_drift,
                detected=psi >= self.psi_threshold,
                score=psi,
                threshold=self.psi_threshold,
                technique="PSI",
                detail={"interpretation": _psi_label(psi)},
            ))

        # ── KS Test (Feature Drift) ───────────────────────────────────────────
        if DriftType.feature_drift in active_types:
            ks_stat, p_value = compute_ks(baseline_arr, current_arr)
            results.append(DriftResult(
                drift_type=DriftType.feature_drift,
                detected=p_value < self.ks_pvalue_threshold,
                score=ks_stat,
                threshold=self.ks_pvalue_threshold,
                technique="KS Test",
                p_value=p_value,
                detail={"ks_statistic": ks_stat, "p_value": p_value},
            ))

        # ── Wasserstein (Distribution Drift) ─────────────────────────────────
        if DriftType.distribution_drift in active_types:
            wass = compute_wasserstein(baseline_arr, current_arr)
            # Normalise by baseline std for scale-independence
            wass_norm = wass / (baseline_arr.std() or 1.0)
            results.append(DriftResult(
                drift_type=DriftType.distribution_drift,
                detected=wass_norm >= self.wasserstein_threshold,
                score=round(wass_norm, 6),
                threshold=self.wasserstein_threshold,
                technique="Wasserstein Distance",
                detail={"raw_distance": wass},
            ))

        # ── Concept Drift (Residual Monitoring) ───────────────────────────────
        if DriftType.concept_drift in active_types:
            z = compute_concept_drift(baseline_arr, current_arr)
            results.append(DriftResult(
                drift_type=DriftType.concept_drift,
                detected=z >= self.concept_z_threshold,
                score=z,
                threshold=self.concept_z_threshold,
                technique="Residual Monitoring (Z-score)",
            ))

        return results

    def overall_score(self, results: List[DriftResult]) -> float:
        """Weighted composite drift score across all techniques."""
        if not results:
            return 0.0
        weights = {
            DriftType.data_drift: 0.3,
            DriftType.feature_drift: 0.25,
            DriftType.distribution_drift: 0.25,
            DriftType.concept_drift: 0.2,
        }
        total = sum(
            weights.get(r.drift_type, 0.1) * min(r.score / max(r.threshold, 1e-9), 2.0)
            for r in results
        )
        return round(min(total, 1.0), 4)

    def recommendation(self, overall_score: float, results: List[DriftResult]) -> str:
        detected = [r for r in results if r.detected]
        if not detected:
            return "No drift detected. Models are stable."
        types = [r.drift_type.value for r in detected]
        if overall_score > 0.7:
            return (
                f"CRITICAL drift detected ({', '.join(types)}). "
                "Immediate model retraining recommended."
            )
        if overall_score > 0.4:
            return (
                f"Moderate drift detected ({', '.join(types)}). "
                "Schedule model retraining within 24 hours."
            )
        return (
            f"Mild drift detected ({', '.join(types)}). "
            "Monitor closely; retraining may be needed soon."
        )


def _psi_label(psi: float) -> str:
    if psi < 0.1:
        return "negligible"
    if psi < 0.2:
        return "moderate"
    return "significant"
