-- Enterprise Temporal AI Platform — Database Init

-- ── MLflow backend ────────────────────────────────────────────────────────────
CREATE DATABASE IF NOT EXISTS mlflow_db;

-- ── Feast registry ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tenants (
    id          SERIAL PRIMARY KEY,
    tenant_id   VARCHAR(128) UNIQUE NOT NULL,
    name        VARCHAR(256),
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    config      JSONB DEFAULT '{}'
);

-- ── Anomaly events log ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS anomaly_events (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       VARCHAR(128) NOT NULL,
    series_id       VARCHAR(256) NOT NULL,
    event_timestamp TIMESTAMPTZ NOT NULL,
    anomaly_score   FLOAT NOT NULL,
    severity        VARCHAR(16),
    is_anomaly      BOOLEAN DEFAULT FALSE,
    llm_summary     TEXT,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_anomaly_tenant_ts ON anomaly_events (tenant_id, event_timestamp DESC);
CREATE INDEX idx_anomaly_series ON anomaly_events (series_id, event_timestamp DESC);

-- ── Drift history ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS drift_history (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       VARCHAR(128) NOT NULL,
    drift_type      VARCHAR(64) NOT NULL,
    drift_score     FLOAT NOT NULL,
    detected        BOOLEAN DEFAULT FALSE,
    technique       VARCHAR(64),
    evaluated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_drift_tenant ON drift_history (tenant_id, evaluated_at DESC);

-- ── Forecast log ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS forecast_log (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       VARCHAR(128) NOT NULL,
    series_id       VARCHAR(256),
    model_used      VARCHAR(64),
    horizon         INT,
    requested_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    latency_ms      FLOAT,
    cached          BOOLEAN DEFAULT FALSE
);

CREATE INDEX idx_forecast_tenant ON forecast_log (tenant_id, requested_at DESC);

-- ── Default tenant ────────────────────────────────────────────────────────────
INSERT INTO tenants (tenant_id, name) VALUES ('default', 'Default Tenant')
ON CONFLICT (tenant_id) DO NOTHING;
