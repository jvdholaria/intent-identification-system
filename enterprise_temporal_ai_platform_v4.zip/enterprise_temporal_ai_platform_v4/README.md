# Enterprise Temporal AI Platform

A fully open-source, production-grade, distributed platform for:

- **Multi-step & probabilistic forecasting** (PatchTST, TFT, TimesNet, N-BEATS, GRU ensemble)
- **Hybrid anomaly detection** (residual · autoencoder · isolation forest · drift-aware scoring)
- **Streaming intelligence** (Google Pub/Sub → Redis → real-time inference pipeline)
- **Drift detection** (PSI · KS Test · Wasserstein · Cosine · Residual monitoring)
- **Online learning** (streaming fine-tuning · EWC · drift-triggered retraining)
- **LLM-assisted anomaly explanations** (Mistral / Llama via Ollama)
- **Multi-tenancy & multi-user concurrency**
- **Kubernetes-native deployment** on GCP

---

## Architecture Overview

```
Pub/Sub → Streaming Consumer → Redis Buffer → Feature Store (Feast)
                                    ↓
                           Forecast Service (PatchTST + TFT + ensemble)
                                    ↓
                           Anomaly Service (Hybrid scorer)
                                    ↓
                           LLM Explanation Layer (Mistral/Llama)
                                    ↓
                           Alert Engine → Dashboard
```

### Microservices

| Service            | Port  | Scaling          | Description                              |
|--------------------|-------|------------------|------------------------------------------|
| API Gateway        | 8000  | HPA              | Rate-limited reverse proxy               |
| Forecast Service   | 8001  | GPU Autoscaling  | Multi-step probabilistic forecasting     |
| Anomaly Service    | 8002  | Autoscaling      | Hybrid anomaly detection + LLM explain   |
| Drift Service      | 8003  | Autoscaling      | PSI / KS / Wasserstein drift detection   |
| Admin API          | 8005  | Singleton        | Tenant management & MLOps operations     |
| MLflow             | 5000  | Singleton        | Experiment tracking & model registry     |
| Redis              | 6379  | StatefulSet      | Buffer, cache, queue, pub/sub            |
| PostgreSQL         | 5432  | StatefulSet      | Persistent metadata & audit logs         |
| Prometheus         | 9090  | Singleton        | Metrics collection                       |
| Grafana            | 3000  | Singleton        | Dashboards & alerting                    |

---

## Technology Stack

| Layer               | Technology                  |
|---------------------|-----------------------------|
| Cloud               | GCP                         |
| Data Lake           | BigQuery                    |
| Streaming           | Google Pub/Sub              |
| Cache / Buffer      | Redis                       |
| Feature Store       | Feast (offline: BQ, online: Redis) |
| Forecasting         | PatchTST + TFT + ensemble   |
| Fallback            | GRU Seq2Seq                 |
| Anomaly Detection   | Hybrid (residual + AE + IF) |
| Drift Detection     | PSI + KS + Wasserstein      |
| Experiment Tracking | MLflow                      |
| Distributed Training| Ray + PyTorch DDP           |
| HPO                 | Optuna + Ray Tune            |
| LLM                 | Mistral / Llama (Ollama)    |
| Monitoring          | Prometheus + Grafana        |
| Orchestration       | Kubernetes (GKE)            |
| Workflow Scheduling | Airflow                     |
| APIs                | FastAPI (async)             |
| CI/CD               | GitLab CI/CD                |

---

## Quick Start (Local Docker)

```bash
# 1. Clone and configure
cp .env.example .env
# Edit .env with your GCP project ID and other settings

# 2. Start the full local stack
docker-compose up -d

# 3. Verify services
curl http://localhost:8000/health        # API Gateway
curl http://localhost:8001/health        # Forecast Service
curl http://localhost:8002/health        # Anomaly Service
curl http://localhost:5000/health        # MLflow

# 4. Access dashboards
open http://localhost:3000               # Grafana (admin / temporal)
open http://localhost:5000               # MLflow
```

---

## Running a Forecast

```bash
curl -X POST http://localhost:8000/forecast/forecast \
  -H "Content-Type: application/json" \
  -H "X-Tenant-ID: my-tenant" \
  -H "X-User-ID: user-1" \
  -d '{
    "tenant_id": "my-tenant",
    "user_id": "user-1",
    "series": [1.2, 1.5, 1.3, ...],
    "horizon": 120,
    "model": "ensemble",
    "return_uncertainty": true,
    "return_quantiles": true
  }'
```

Response:
```json
{
  "forecast": [...],
  "lower_bound": [...],
  "upper_bound": [...],
  "uncertainty": [...],
  "quantiles": { "p10": [...], "p50": [...], "p90": [...] },
  "model_used": "ensemble",
  "horizon": 120
}
```

---

## Running Anomaly Detection

```bash
curl -X POST http://localhost:8000/anomaly/detect \
  -H "Content-Type: application/json" \
  -H "X-Tenant-ID: my-tenant" \
  -d '{
    "tenant_id": "my-tenant",
    "user_id": "user-1",
    "actual": [...],
    "predicted": [...],
    "return_explanations": true
  }'
```

---

## Temporal Configuration

```python
TemporalConfig(
    resample_freq="1H",          # Hourly data
    window_size=168,             # 7-day context window
    horizon=120,                 # 5-day forecast horizon
    multi_step=True,
    forecast_strategy="seq2seq",
)
```

---

## Forecast Ensemble Weights

```python
FINAL_FORECAST = (
    0.35 * patchtst
  + 0.30 * tft
  + 0.15 * timesnet
  + 0.10 * nbeats
  + 0.10 * gru
)
```

---

## Anomaly Hybrid Scoring

```python
FINAL_SCORE = (
    0.5 * residual_score
  + 0.3 * reconstruction_score
  + 0.2 * drift_score
)
```

---

## Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests
pytest tests/unit/ -v

# Run integration tests (requires docker-compose up)
pytest tests/integration/ -v

# Lint
ruff check .
mypy shared/ forecasting/ anomaly/

# Run a specific service locally
cd api/forecasting_api
uvicorn main:app --reload --port 8001
```

---

## Kubernetes Deployment (GKE)

```bash
# Authenticate
gcloud container clusters get-credentials temporal-ai-cluster --region us-central1

# Apply all manifests
kubectl apply -f infrastructure/kubernetes/

# Check status
kubectl get all -n temporal-ai

# Watch rolling deploy
kubectl rollout status deployment/forecast-service -n temporal-ai
```

---

## CI/CD

Push to `main` → GitLab pipeline:

```
Git Push → Unit Tests → Integration Tests → Docker Build
         → Model Validation → Deploy to Staging → [manual] → Production
```

---

## Multi-Tenancy

Every API request must include tenant context:

```json
{ "tenant_id": "acme-corp", "user_id": "analyst-42" }
```

Each tenant gets isolated:
- Redis namespaces
- Feature store partitions
- MLflow experiments
- Drift metrics
- Alert queues

---

## Project Structure

```
enterprise-temporal-ai/
├── api/
│   ├── gateway/              # API Gateway (rate limiting, routing)
│   ├── forecasting_api/      # Forecast + Training + Inference endpoints
│   ├── anomaly_api/          # Anomaly detection + Alerts endpoints
│   └── admin_api/            # Tenant management, model registry ops
├── forecasting/
│   ├── models/               # PatchTST, TFT, TimesNet, N-BEATS, GRU
│   ├── training/             # Lightning trainer + Optuna HPO
│   ├── inference/            # Ensemble engine
│   └── quantile/             # Quantile + combined loss functions
├── anomaly/
│   ├── residual/             # Residual-based detection
│   ├── autoencoder/          # LSTM + Transformer AE
│   ├── hybrid/               # Hybrid scorer + Isolation Forest
│   └── drift/                # PSI, KS, Wasserstein, cosine, residual
├── feature_store/feast/      # Feast config, feature views, client
├── streaming/consumers/      # Pub/Sub consumer + Redis buffer
├── llm/
│   ├── explainability/       # LLM anomaly explainer (Ollama)
│   └── explainability/       # SHAP, attention maps, saliency, counterfactuals
├── orchestration/
│   ├── airflow/              # Retraining DAG
│   └── retraining/           # Online learner + Celery workers
├── mlops/registry/           # MLflow model registry wrapper
├── shared/
│   ├── config/               # Settings (pydantic-settings)
│   ├── schemas/              # Shared Pydantic schemas
│   └── logging/              # Structured logging (structlog)
├── infrastructure/
│   ├── kubernetes/           # K8s manifests (Deployments, HPA, Services)
│   └── docker/               # Dockerfiles + init.sql
├── monitoring/
│   ├── prometheus/           # prometheus.yml
│   └── grafana/              # Dashboard provisioning
├── tests/
│   ├── unit/                 # Unit tests (models, detectors, losses)
│   └── integration/          # Integration tests (API, feature store)
├── docker-compose.yml
├── .gitlab-ci.yml
├── pyproject.toml
└── .env.example
```
