"""
Enterprise Temporal AI Platform — Explainability

Implements:
- SHAP feature attribution (DeepSHAP / KernelSHAP)
- Attention map extraction from Transformer models
- Temporal saliency maps via input gradients
- Counterfactual analysis
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn

from shared.logging.logger import get_logger

log = get_logger("llm.explainability.shap")


# ─────────────────────────────────────────────────────────────────────────────
# SHAP Attribution
# ─────────────────────────────────────────────────────────────────────────────

class SHAPAttributor:
    """
    Wraps SHAP library to provide feature attributions for temporal models.
    Uses KernelSHAP for model-agnostic attribution and DeepSHAP for PyTorch models.
    """

    def __init__(self, model: nn.Module, background_data: np.ndarray):
        self.model = model
        self.background = background_data
        self._explainer = None

    def _get_explainer(self, use_deep: bool = True):
        if self._explainer is not None:
            return self._explainer
        try:
            import shap
            if use_deep:
                self._explainer = shap.DeepExplainer(
                    self.model,
                    torch.tensor(self.background[:50], dtype=torch.float32),
                )
            else:
                def model_fn(x):
                    t = torch.tensor(x, dtype=torch.float32)
                    with torch.no_grad():
                        return self.model(t).numpy()
                self._explainer = shap.KernelExplainer(
                    model_fn,
                    self.background[:20],
                )
        except ImportError:
            log.warning("shap.not_installed — using gradient fallback")
            return None
        return self._explainer

    def attribute(
        self,
        x: np.ndarray,
        use_deep: bool = True,
    ) -> Optional[np.ndarray]:
        """
        Compute SHAP values for input x.
        Returns array of shape (n_samples, n_timesteps) or None if unavailable.
        """
        explainer = self._get_explainer(use_deep)
        if explainer is None:
            return self._gradient_attribution(x)
        try:
            import shap
            shap_values = explainer.shap_values(
                torch.tensor(x, dtype=torch.float32)
                if use_deep
                else x
            )
            if isinstance(shap_values, list):
                shap_values = shap_values[0]
            return np.array(shap_values)
        except Exception as exc:
            log.warning("shap.attribution_failed", exc=str(exc))
            return self._gradient_attribution(x)

    def _gradient_attribution(self, x: np.ndarray) -> np.ndarray:
        """Gradient × Input as lightweight attribution fallback."""
        tensor = torch.tensor(x, dtype=torch.float32, requires_grad=True)
        out = self.model(tensor)
        if out.dim() > 1:
            out = out.mean(dim=-1)
        grad = torch.autograd.grad(out.sum(), tensor)[0]
        return (tensor * grad).detach().numpy()

    def get_top_features(
        self,
        shap_values: np.ndarray,
        feature_names: Optional[List[str]] = None,
        top_k: int = 10,
    ) -> Dict[str, float]:
        """
        Return the top-k most important timesteps/features by mean |SHAP|.
        """
        mean_abs = np.abs(shap_values).mean(axis=0)
        top_indices = np.argsort(mean_abs)[::-1][:top_k]
        if feature_names:
            return {feature_names[i]: round(float(mean_abs[i]), 4) for i in top_indices}
        return {f"t-{i}": round(float(mean_abs[i]), 4) for i in top_indices}


# ─────────────────────────────────────────────────────────────────────────────
# Attention Map Extractor
# ─────────────────────────────────────────────────────────────────────────────

class AttentionExtractor:
    """
    Hooks into Transformer self-attention layers to extract
    attention weight matrices for visualisation and attribution.
    """

    def __init__(self, model: nn.Module):
        self.model = model
        self._hooks: List[Any] = []
        self._attention_maps: List[np.ndarray] = []

    def register_hooks(self):
        """Register forward hooks on all MultiheadAttention modules."""
        self._attention_maps.clear()
        self._hooks.clear()
        for name, module in self.model.named_modules():
            if isinstance(module, nn.MultiheadAttention):
                hook = module.register_forward_hook(self._attn_hook)
                self._hooks.append(hook)

    def _attn_hook(self, module, input, output):
        _, attn_weights = output
        if attn_weights is not None:
            self._attention_maps.append(attn_weights.detach().cpu().numpy())

    def remove_hooks(self):
        for h in self._hooks:
            h.remove()
        self._hooks.clear()

    def extract(self, x: torch.Tensor) -> List[np.ndarray]:
        """
        Forward pass with hooks to collect attention maps.
        Returns list of attention weight arrays per layer.
        """
        self.register_hooks()
        try:
            with torch.no_grad():
                self.model(x)
        finally:
            self.remove_hooks()
        return list(self._attention_maps)

    def aggregate_attention(self, attention_maps: List[np.ndarray]) -> np.ndarray:
        """
        Compute mean attention across all layers and heads.
        Returns (seq_len, seq_len) array.
        """
        if not attention_maps:
            return np.array([])
        # Average across layers: each map is (B, n_heads, T, T) or (B, T, T)
        agg = []
        for attn in attention_maps:
            if attn.ndim == 4:
                agg.append(attn.mean(axis=(0, 1)))   # (T, T)
            elif attn.ndim == 3:
                agg.append(attn.mean(axis=0))         # (T, T)
        return np.mean(agg, axis=0) if agg else np.array([])


# ─────────────────────────────────────────────────────────────────────────────
# Temporal Saliency Maps
# ─────────────────────────────────────────────────────────────────────────────

class TemporalSaliencyMapper:
    """
    Computes input-gradient saliency maps — which timesteps most influenced
    the forecast output.
    """

    def __init__(self, model: nn.Module, device: Optional[str] = None):
        self.model = model
        self.device = torch.device(
            device or ("cuda" if torch.cuda.is_available() else "cpu")
        )
        self.model.to(self.device).eval()

    def saliency(self, x: np.ndarray, target_step: int = 0) -> np.ndarray:
        """
        Vanilla gradient saliency: ∂output[target_step] / ∂input.
        Returns array of shape (seq_len,).
        """
        tensor = torch.tensor(
            x, dtype=torch.float32, requires_grad=True
        ).unsqueeze(0).to(self.device)

        output = self.model(tensor)
        if output.dim() == 1:
            scalar = output[target_step]
        else:
            scalar = output[0, target_step]

        scalar.backward()
        grad = tensor.grad.squeeze(0).cpu().numpy()
        return np.abs(grad)

    def integrated_gradients(
        self,
        x: np.ndarray,
        baseline: Optional[np.ndarray] = None,
        steps: int = 50,
        target_step: int = 0,
    ) -> np.ndarray:
        """
        Integrated Gradients attribution (Sundararajan et al., 2017).
        More stable than vanilla gradients.
        """
        if baseline is None:
            baseline = np.zeros_like(x)

        x_t = torch.tensor(x, dtype=torch.float32).unsqueeze(0).to(self.device)
        b_t = torch.tensor(baseline, dtype=torch.float32).unsqueeze(0).to(self.device)

        grads = []
        for alpha in np.linspace(0, 1, steps):
            interpolated = b_t + alpha * (x_t - b_t)
            interpolated.requires_grad_(True)
            output = self.model(interpolated)
            if output.dim() == 1:
                scalar = output[target_step]
            else:
                scalar = output[0, target_step]
            scalar.backward()
            grads.append(interpolated.grad.squeeze(0).cpu().numpy())

        avg_grad = np.mean(grads, axis=0)
        ig = (x - baseline) * avg_grad
        return np.abs(ig)


# ─────────────────────────────────────────────────────────────────────────────
# Counterfactual Analyser
# ─────────────────────────────────────────────────────────────────────────────

class CounterfactualAnalyser:
    """
    Generates counterfactual explanations by finding the minimal perturbation
    to the input that would push the forecast below / above a threshold.
    Uses gradient descent on the input space.
    """

    def __init__(self, model: nn.Module, device: Optional[str] = None):
        self.model = model
        self.device = torch.device(
            device or ("cuda" if torch.cuda.is_available() else "cpu")
        )

    def find_counterfactual(
        self,
        x: np.ndarray,
        target_value: float,
        target_step: int = 0,
        lr: float = 0.01,
        max_steps: int = 500,
        l2_reg: float = 0.1,
    ) -> Tuple[np.ndarray, float]:
        """
        Find x' close to x such that model(x')[target_step] ≈ target_value.
        Returns (counterfactual_x, achieved_value).
        """
        x_cf = torch.tensor(x, dtype=torch.float32, requires_grad=True).unsqueeze(0).to(self.device)
        x_orig = torch.tensor(x, dtype=torch.float32).unsqueeze(0).to(self.device)
        optimizer = torch.optim.Adam([x_cf], lr=lr)
        target = torch.tensor(target_value)

        for _ in range(max_steps):
            optimizer.zero_grad()
            out = self.model(x_cf)
            pred = out[0, target_step] if out.dim() > 1 else out[target_step]
            pred_loss = (pred - target) ** 2
            prox_loss = l2_reg * torch.mean((x_cf - x_orig) ** 2)
            loss = pred_loss + prox_loss
            loss.backward()
            optimizer.step()

        achieved = float(self.model(x_cf)[0, target_step].detach())
        return x_cf.squeeze(0).detach().cpu().numpy(), achieved
