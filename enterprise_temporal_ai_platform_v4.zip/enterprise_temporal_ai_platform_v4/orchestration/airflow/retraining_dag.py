"""
Enterprise Temporal AI Platform — Airflow Retraining DAG

Triggers model retraining on:
1. Scheduled basis (weekly)
2. Drift detection events (Redis pub/sub signal)
3. Manual via Airflow UI

Pipeline:
  data_validation → feature_materialisation → model_training
  → model_evaluation → model_registration → promote_to_staging
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any

from airflow import DAG
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.operators.empty import EmptyOperator

# ── Default args ──────────────────────────────────────────────────────────────

DEFAULT_ARGS = {
    "owner": "temporal-ai",
    "depends_on_past": False,
    "start_date": datetime(2024, 1, 1),
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 2,
    "retry_delay": timedelta(minutes=5),
}


# ── Task functions ────────────────────────────────────────────────────────────

def check_drift_signal(**context) -> str:
    """
    Read the latest drift score from Redis.
    Branch to forced_retrain if drift threshold exceeded,
    else continue with schedule_check.
    """
    import redis
    import os

    r = redis.from_url(os.environ.get("REDIS_URL", "redis://redis:6379"))
    tenant_id = context["params"].get("tenant_id", "default")
    score_raw = r.get(f"temporal:tenant:{tenant_id}:drift:latest")

    drift_score = float(score_raw) if score_raw else 0.0
    context["ti"].xcom_push(key="drift_score", value=drift_score)

    if drift_score > 0.4:
        return "drift_triggered_retrain"
    return "scheduled_check"


def validate_data(**context) -> None:
    """Run data quality checks before training."""
    import logging
    log = logging.getLogger("validate_data")
    # In production: run Great Expectations or custom validators
    log.info("data_validation.started")
    # Simulate validation
    log.info("data_validation.passed")


def materialise_features(**context) -> None:
    """Materialise latest features from BigQuery into Redis."""
    import sys, os
    sys.path.insert(0, "/app")
    from feature_store.feast.client import TemporalFeatureClient
    client = TemporalFeatureClient()
    client.materialise()


def run_training(**context) -> str:
    """
    Trigger training for the specified model type and tenant.
    Returns the MLflow run_id.
    """
    import sys, os, uuid, logging
    sys.path.insert(0, "/app")
    log = logging.getLogger("run_training")

    tenant_id = context["params"].get("tenant_id", "default")
    model_type = context["params"].get("model_type", "gru")
    run_id = str(uuid.uuid4())

    from shared.config.settings import settings
    from forecasting.training.trainer import TemporalTrainer
    from shared.schemas.schemas import ModelType

    import asyncio

    trainer = TemporalTrainer(settings=settings)
    asyncio.run(trainer.train(
        dataset_path=context["params"].get("dataset_path", "/data/default.npy"),
        model_type=ModelType(model_type),
        run_id=run_id,
        experiment_name=f"retraining/{tenant_id}/{model_type}",
        epochs=context["params"].get("epochs", 100),
        tenant_id=tenant_id,
    ))

    context["ti"].xcom_push(key="run_id", value=run_id)
    log.info("training.complete", run_id=run_id)
    return run_id


def evaluate_model(**context) -> None:
    """
    Pull validation metrics from MLflow and gate promotion.
    Raises on poor performance.
    """
    import mlflow, os, logging
    log = logging.getLogger("evaluate_model")
    run_id = context["ti"].xcom_pull(key="run_id", task_ids="run_training")
    mlflow.set_tracking_uri(os.environ.get("MLFLOW_TRACKING_URI", "http://mlflow:5000"))
    client = mlflow.tracking.MlflowClient()
    run = client.get_run(run_id)
    val_loss = run.data.metrics.get("val_loss", float("inf"))

    threshold = context["params"].get("val_loss_threshold", 1.0)
    if val_loss > threshold:
        raise ValueError(f"Model val_loss={val_loss:.4f} exceeds threshold={threshold}")
    log.info("evaluation.passed", val_loss=val_loss)


def register_and_stage(**context) -> None:
    """Register the trained model and promote to Staging."""
    import sys
    sys.path.insert(0, "/app")
    from mlops.registry.model_registry import get_registry

    run_id = context["ti"].xcom_pull(key="run_id", task_ids="run_training")
    tenant_id = context["params"].get("tenant_id", "default")
    model_type = context["params"].get("model_type", "gru")

    registry = get_registry()
    version = registry.register(
        run_id=run_id,
        model_artifact_path="model",
        model_name=f"{model_type}_{tenant_id}",
        description=f"Auto-retrained on {datetime.utcnow().date()}",
        tags={"tenant_id": tenant_id, "trigger": context["params"].get("trigger", "scheduled")},
    )
    registry.promote_to_staging(f"{model_type}_{tenant_id}", version.version)


def notify_completion(**context) -> None:
    """Publish completion event to Redis for downstream services."""
    import redis, json, os
    r = redis.from_url(os.environ.get("REDIS_URL", "redis://redis:6379"))
    tenant_id = context["params"].get("tenant_id", "default")
    r.publish(
        f"temporal:tenant:{tenant_id}:retrain:complete",
        json.dumps({"status": "complete", "run_id": context["ti"].xcom_pull(key="run_id", task_ids="run_training")}),
    )


# ── DAG Definition ────────────────────────────────────────────────────────────

with DAG(
    dag_id="temporal_ai_retraining",
    description="Scheduled and drift-triggered model retraining pipeline",
    default_args=DEFAULT_ARGS,
    schedule_interval="0 2 * * 0",   # Weekly at 02:00 UTC on Sunday
    catchup=False,
    max_active_runs=1,
    tags=["temporal-ai", "ml", "retraining"],
    params={
        "tenant_id": "default",
        "model_type": "patchtst",
        "dataset_path": "/data/default.npy",
        "epochs": 100,
        "val_loss_threshold": 1.0,
        "trigger": "scheduled",
    },
) as dag:

    start = EmptyOperator(task_id="start")

    check_drift = BranchPythonOperator(
        task_id="check_drift_signal",
        python_callable=check_drift_signal,
        provide_context=True,
    )

    drift_retrain = EmptyOperator(task_id="drift_triggered_retrain")
    scheduled_check = EmptyOperator(task_id="scheduled_check")

    join = EmptyOperator(task_id="join", trigger_rule="none_failed_min_one_success")

    validate = PythonOperator(
        task_id="validate_data",
        python_callable=validate_data,
        provide_context=True,
    )

    materialise = PythonOperator(
        task_id="materialise_features",
        python_callable=materialise_features,
        provide_context=True,
    )

    train = PythonOperator(
        task_id="run_training",
        python_callable=run_training,
        provide_context=True,
    )

    evaluate = PythonOperator(
        task_id="evaluate_model",
        python_callable=evaluate_model,
        provide_context=True,
    )

    register = PythonOperator(
        task_id="register_and_stage",
        python_callable=register_and_stage,
        provide_context=True,
    )

    notify = PythonOperator(
        task_id="notify_completion",
        python_callable=notify_completion,
        provide_context=True,
    )

    end = EmptyOperator(task_id="end")

    # ── Task dependencies ─────────────────────────────────────────────────────
    start >> check_drift >> [drift_retrain, scheduled_check] >> join
    join >> validate >> materialise >> train >> evaluate >> register >> notify >> end
