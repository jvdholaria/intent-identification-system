# ml_framework — Long-Format Telemetry Edition

Multivariate anomaly detection and prediction framework, updated to
support long-format telemetry data with `ts`, `asset_id`, and
`telemetry_N` columns.

## Dataset schema

```
ts,                   asset_id, telemetry_1, telemetry_2, telemetry_3
2026-01-01 00:00:00,  asset_A,  42.1,        81.5,        0.93
2026-01-01 00:00:00,  asset_B,  39.8,        79.2,        0.88
2026-01-01 00:01:00,  asset_A,  42.3,        81.7,        0.91
```

Each row is one timestamp for one asset. The pipeline automatically
pivots this to wide format before training:

```
ts               | telemetry_1__asset_A | telemetry_1__asset_B | …
2026-01-01 00:00 | 42.1                 | 39.8                 | …
```

## Quick start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Generate sample data (optional — skips if you have your own CSV)
python sample_data_generator.py

# 3. Edit the config at the top of run.py
#    Set CSV_PATH, TS_COL, ASSET_ID_COL, TARGET_COLUMNS
vi run.py

# 4. Run
python run.py
```

## What changed from the original

| File | Change |
|------|--------|
| `ml_framework/core/config.py` | `TemporalConfig.timestamp_col` default → `"ts"` |
| | `DataSourceConfig.timestamp_col` default → `"ts"` |
| | `DataSourceConfig.asset_id_col` **NEW** — asset pivot key |
| | `DataSourceConfig.telemetry_prefix` **NEW** — auto-detect sensor cols |
| `ml_framework/core/data_ingestion.py` | `_pivot_long_to_wide()` **NEW** |
| | `_load_sources()` — calls pivot after timestamp coercion |
| | `_resample_source()` — auto-detects numeric cols when `numerical_cols=[]` |
| | `_resample_all()` — skips extra subsystem prefix for pivoted sources |
| `run.py` | Completely rewritten for the new schema |
| `sample_data_generator.py` | **NEW** — generates test data |

Everything else (`pipeline.py`, `preprocessing.py`, `anomaly/`,
`evaluation/`, `explainability/`, `inference/`, `models/`) is
**unchanged**.

## Target column naming

After pivoting, column names follow the pattern `{telemetry_col}__{asset_id}`.

```python
# Predict telemetry_1 for asset_A only
TARGET_COLUMNS = ["telemetry_1__asset_A"]

# Predict telemetry_1 for all assets
TARGET_COLUMNS = [
    "telemetry_1__asset_A",
    "telemetry_1__asset_B",
    "telemetry_1__asset_C",
]

# Leave empty to auto-detect (first telemetry col per asset)
TARGET_COLUMNS = []
```

## Reload a checkpoint without retraining

```python
from run import predict_new

preds = predict_new(
    new_csv_path   = "new_telemetry.csv",
    checkpoint_dir = "./outputs/checkpoint",
)
print(preds.head())
```

## Project structure

```
ml_framework_telemetry/
├── run.py                        ← main entry point
├── sample_data_generator.py      ← generate test data
├── requirements.txt
├── README.md
└── ml_framework/
    ├── core/
    │   ├── config.py             ← UPDATED
    │   ├── data_ingestion.py     ← UPDATED
    │   └── preprocessing.py
    ├── models/
    │   ├── tree_models.py
    │   └── deep_models.py
    ├── anomaly/
    │   └── detector.py
    ├── evaluation/
    │   └── metrics.py
    ├── explainability/
    │   └── shap_explainer.py
    ├── inference/
    │   └── engine.py
    └── pipeline.py
```
