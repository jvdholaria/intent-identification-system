"""
Enterprise Temporal AI Platform — Celery Workers

Handles:
- Async forecast jobs
- Async anomaly detection
- Background retraining dispatch
- Feature materialisation
"""

from __future__ import annotations

import json
import time
from typing import Any, Dict, List

from celery import Celery
from celery.utils.log import get_task_logger

from shared.config.settings import settings

# ── Celery App ────────────────────────────────────────────────────────────────
celery_app = Celery(
    "temporal_ai",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=["workers.celery_workers"],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_routes={
        "workers.celery_workers.run_forecast_job": {"queue": "forecast"},
        "workers.celery_workers.run_anomaly_job": {"queue": "anomaly"},
        "workers.celery_workers.run_retraining_job": {"queue": "retraining"},
        "workers.celery_workers.materialise_features": {"queue": "features"},
    },
    beat_schedule={
        "weekly-retraining": {
            "task": "workers.celery_workers.run_retraining_job",
            "schedule": 7 * 24 * 3600,
            "args": ({"tenant_id": "default", "reason": "scheduled_weekly"},),
        },
        "daily-feature-materialise": {
            "task": "workers.celery_workers.materialise_features",
            "schedule": 24 * 3600,
            "args": (),
        },
        "hourly-drift-check": {
            "task": "workers.celery_workers.check_drift_all_tenants",
            "schedule": 3600,
            "args": (),
        },
    },
)

log = get_task_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Forecast Task
# ─────────────────────────────────────────────────────────────────────────────

@celery_app.task(
    name="workers.celery_workers.run_forecast_job",
    bind=True,
    max_retries=3,
    default_retry_delay=30,
    time_limit=120,
)
def run_forecast_job(self, payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Run a single forecast job asynchronously.
    Enqueued by the streaming consumer for series that require inference.
    """
    import asyncio
    from forecasting.inference.engine import ForecastEngine
    from shared.schemas.schemas import ModelType

    tenant_id = payload.get("tenant_id", "default")
    series = payload["series"]
    horizon = payload.get("horizon", settings.FORECAST_HORIZON)
    model = ModelType(payload.get("model", "ensemble"))

    log.info(f"[forecast_job] tenant={tenant_id} horizon={horizon} model={model.value}")

    try:
        engine = ForecastEngine(settings=settings)
        result = asyncio.get_event_loop().run_until_complete(
            engine.run(series=series, horizon=horizon, model=model,
                       quantiles=settings.FORECAST_QUANTILES, tenant_id=tenant_id)
        )
        _cache_result(tenant_id, payload.get("series_id", "unknown"), result)
        return {"status": "ok", "result": result}
    except Exception as exc:
        log.error(f"[forecast_job] failed: {exc}")
        raise self.retry(exc=exc)


# ─────────────────────────────────────────────────────────────────────────────
# Anomaly Task
# ─────────────────────────────────────────────────────────────────────────────

@celery_app.task(
    name="workers.celery_workers.run_anomaly_job",
    bind=True,
    max_retries=3,
    default_retry_delay=15,
    time_limit=60,
)
def run_anomaly_job(self, payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Run hybrid anomaly detection asynchronously.
    """
    from anomaly.hybrid.scorer import EnsembleAnomalyPipeline
    import numpy as np

    tenant_id = payload.get("tenant_id", "default")
    actual = payload["actual"]
    predicted = payload["predicted"]

    log.info(f"[anomaly_job] tenant={tenant_id} n={len(actual)}")

    try:
        pipeline = EnsembleAnomalyPipeline()
        result = pipeline.run(actual=actual, predicted=predicted)
        return {"status": "ok", "result": result}
    except Exception as exc:
        log.error(f"[anomaly_job] failed: {exc}")
        raise self.retry(exc=exc)


# ─────────────────────────────────────────────────────────────────────────────
# Retraining Task
# ─────────────────────────────────────────────────────────────────────────────

@celery_app.task(
    name="workers.celery_workers.run_retraining_job",
    bind=True,
    max_retries=1,
    time_limit=7200,   # 2 hours
)
def run_retraining_job(self, payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Dispatch a full retraining job for a tenant.
    Triggers Airflow DAG via REST API (or runs directly).
    """
    import requests

    tenant_id = payload.get("tenant_id", "default")
    reason = payload.get("reason", "unknown")
    log.info(f"[retrain_job] tenant={tenant_id} reason={reason}")

    airflow_url = "http://airflow-webserver:8080/api/v1/dags/temporal_ai_retraining/dagRuns"
    try:
        resp = requests.post(
            airflow_url,
            json={
                "conf": {
                    "tenant_id": tenant_id,
                    "model_type": "patchtst",
                    "trigger": reason,
                }
            },
            auth=("airflow", "airflow"),
            timeout=10,
        )
        resp.raise_for_status()
        return {"status": "ok", "dag_run_id": resp.json().get("dag_run_id")}
    except Exception as exc:
        log.warning(f"[retrain_job] Airflow unreachable ({exc}); running inline")
        return {"status": "skipped", "reason": str(exc)}


# ─────────────────────────────────────────────────────────────────────────────
# Feature Materialisation Task
# ─────────────────────────────────────────────────────────────────────────────

@celery_app.task(
    name="workers.celery_workers.materialise_features",
    time_limit=1800,
)
def materialise_features() -> Dict[str, Any]:
    """Materialise Feast features from BigQuery → Redis."""
    from feature_store.feast.client import TemporalFeatureClient
    client = TemporalFeatureClient()
    client.materialise()
    return {"status": "ok", "materialized_at": time.time()}


# ─────────────────────────────────────────────────────────────────────────────
# Drift Check Task
# ─────────────────────────────────────────────────────────────────────────────

@celery_app.task(
    name="workers.celery_workers.check_drift_all_tenants",
    time_limit=600,
)
def check_drift_all_tenants() -> Dict[str, Any]:
    """
    Iterate all known tenants and trigger drift detection.
    Run hourly via Celery Beat.
    """
    import redis as sync_redis
    r = sync_redis.from_url(settings.REDIS_URL, decode_responses=True)

    tenants = r.smembers("temporal:tenants:active") or {"default"}
    results = {}
    for tenant_id in tenants:
        baseline_key = f"temporal:tenant:{tenant_id}:baseline_series"
        current_key = f"temporal:tenant:{tenant_id}:buffer:default"
        raw_b = r.lrange(baseline_key, 0, 499)
        raw_c = r.lrange(current_key, 0, 499)
        if len(raw_b) < 10 or len(raw_c) < 10:
            continue

        baseline = [float(v) for v in raw_b]
        current = [float(v) for v in raw_c]

        from anomaly.drift.drift_detector import DriftDetector
        detector = DriftDetector()
        drift_results = detector.detect(baseline, current)
        score = detector.overall_score(drift_results)
        r.setex(f"temporal:tenant:{tenant_id}:drift:latest", 3600, str(score))
        results[tenant_id] = {"drift_score": score}

    return {"status": "ok", "tenants_checked": len(results), "results": results}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _cache_result(tenant_id: str, series_id: str, result: Dict):
    import redis as sync_redis
    r = sync_redis.from_url(settings.REDIS_URL, decode_responses=True)
    key = f"temporal:tenant:{tenant_id}:latest:{series_id}"
    r.setex(key, settings.REDIS_BUFFER_TTL, json.dumps(result))
