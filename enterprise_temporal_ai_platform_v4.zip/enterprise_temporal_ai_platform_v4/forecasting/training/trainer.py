"""
Enterprise Temporal AI Platform V4 — Distributed Trainer

Changes from V3:
  - Dataset builder works on multi-asset LoadedDataset (X:[N,L,F], Y:[N,H,T], asset_ids:[N])
  - Lightning module handles [B,L,F] → [B,H,T] contract for all models
  - Asset ids fed to every model forward pass
  - Loss computed over all T targets
  - Model factory builds V4 models with correct F, T, num_assets dims
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Dict, List, Optional

import numpy as np
import pytorch_lightning as pl
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

from forecasting.quantile.loss import CombinedForecastLoss
from shared.config.settings import Settings
from shared.logging.logger import get_logger
from shared.schemas.schemas import ModelType

log = get_logger("forecast.trainer")

torch.set_float32_matmul_precision("high")
if torch.cuda.is_available():
    torch.backends.cudnn.benchmark = True


# ─────────────────────────────────────────────────────────────────────────────
# Multi-Asset Dataset Builder
# ─────────────────────────────────────────────────────────────────────────────

class MultiAssetDatasetBuilder:
    """
    Converts pre-built numpy arrays (from CSVTemporalLoader) into
    a TensorDataset for PyTorch Lightning.

    Expected inputs:
        X:         [N, L, F]   float32
        Y:         [N, H, T]   float32
        asset_ids: [N]         int32

    Output TensorDataset yields: (X_batch, Y_batch, asset_id_batch)
    """

    def build(
        self,
        X:         np.ndarray,
        Y:         np.ndarray,
        asset_ids: np.ndarray,
    ) -> TensorDataset:

        X_t   = torch.tensor(X,         dtype=torch.float32)
        Y_t   = torch.tensor(Y,         dtype=torch.float32)
        aid_t = torch.tensor(asset_ids, dtype=torch.long)

        log.info(
            "dataset_builder.built",
            X=tuple(X_t.shape),
            Y=tuple(Y_t.shape),
            asset_ids=tuple(aid_t.shape),
        )
        return TensorDataset(X_t, Y_t, aid_t)


# ─────────────────────────────────────────────────────────────────────────────
# Lightning Module
# ─────────────────────────────────────────────────────────────────────────────

class TemporalLightningModule(pl.LightningModule):
    """
    V4 Lightning wrapper.

    All models receive:
        forward(x, asset_id)  →  [B, H, T]

    Loss computed across all T targets.
    """

    def __init__(
        self,
        model:         nn.Module,
        learning_rate: float       = 1e-4,
        quantiles:     List[float] = None,
    ):
        super().__init__()
        self.model     = model
        self.lr        = learning_rate
        self.quantiles = quantiles or [0.1, 0.5, 0.9]
        self.loss_fn   = CombinedForecastLoss(self.quantiles)
        self.save_hyperparameters(ignore=["model"])

    def forward(self, x, asset_id=None):
        return self.model(x, asset_id)

    def _shared_step(self, batch, stage: str):
        x, y, asset_id = batch        # [B,L,F], [B,H,T], [B]

        pred = self(x, asset_id)      # [B, H, T]

        # ── Loss expects [B, H, Q] per target; sum over targets ──────────────
        total_loss = torch.tensor(0.0, device=x.device)
        T = y.shape[-1]

        for t in range(T):
            pred_t = pred[..., t]     # [B, H]
            y_t    = y[..., t]        # [B, H]

            # Expand to quantile dim
            pred_q = pred_t.unsqueeze(-1).expand(-1, -1, len(self.quantiles))
            total_loss = total_loss + self.loss_fn(pred_q, y_t)

        loss = total_loss / T

        self.log(f"{stage}/loss", loss, prog_bar=True, on_step=False, on_epoch=True, sync_dist=True)

        # Also log per-target MSE for monitoring
        with torch.no_grad():
            mse = nn.functional.mse_loss(pred, y)
            self.log(f"{stage}/mse", mse, on_step=False, on_epoch=True, sync_dist=True)

        return loss

    def training_step(self, batch, batch_idx):
        return self._shared_step(batch, "train")

    def validation_step(self, batch, batch_idx):
        return self._shared_step(batch, "val")

    def configure_optimizers(self):
        optimizer = torch.optim.AdamW(self.parameters(), lr=self.lr, weight_decay=1e-5)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=50)
        return {"optimizer": optimizer, "lr_scheduler": scheduler}


# ─────────────────────────────────────────────────────────────────────────────
# Trainer
# ─────────────────────────────────────────────────────────────────────────────

class TemporalTrainer:

    def __init__(self, settings: Settings):
        self.settings = settings

    async def train(
        self,
        dataset_path:    str,
        model_type:      ModelType,
        run_id:          str,
        experiment_name: str,
        epochs:          int        = 100,
        batch_size:      int        = 64,
        learning_rate:   float      = 1e-4,
        horizon:         int        = 24,
        window_size:     int        = 168,
        num_features:    int        = 1,
        num_targets:     int        = 1,
        num_assets:      int        = 1,
        quantiles:       List[float] = None,
        use_distributed: bool       = False,
        run_hpo:         bool       = False,
        tenant_id:       str        = "default",
        tags:            Dict       = None,
    ):
        await asyncio.get_event_loop().run_in_executor(
            None,
            self._train_sync,
            dataset_path, model_type, run_id, experiment_name,
            epochs, batch_size, learning_rate, horizon, window_size,
            num_features, num_targets, num_assets,
            quantiles, use_distributed, run_hpo, tenant_id, tags or {},
        )

    def _train_sync(
        self,
        dataset_path, model_type, run_id, experiment_name,
        epochs, batch_size, learning_rate, horizon, window_size,
        num_features, num_targets, num_assets,
        quantiles, use_distributed, run_hpo, tenant_id, tags,
    ):
        import mlflow
        import mlflow.pytorch

        mlflow.set_tracking_uri(self.settings.MLFLOW_TRACKING_URI)
        mlflow.set_experiment(experiment_name)

        # ── Load dataset ─────────────────────────────────────────────────────
        base = dataset_path.rstrip("/").rstrip("\\")
        X_train    = np.load(f"{base}/X_train.npy")
        Y_train    = np.load(f"{base}/Y_train.npy")
        aids_train = np.load(f"{base}/asset_ids_train.npy")
        X_val      = np.load(f"{base}/X_val.npy")
        Y_val      = np.load(f"{base}/Y_val.npy")
        aids_val   = np.load(f"{base}/asset_ids_val.npy")

        # Infer dims from data
        _, L, F = X_train.shape
        _, H, T = Y_train.shape

        log.info("trainer.loaded_data", X_train=X_train.shape, Y_train=Y_train.shape)

        builder   = MultiAssetDatasetBuilder()
        train_ds  = builder.build(X_train, Y_train, aids_train)
        val_ds    = builder.build(X_val,   Y_val,   aids_val)

        # ── Build model ───────────────────────────────────────────────────────
        model = self._build_model(model_type, L, H, F, T, num_assets)

        # ── Train ─────────────────────────────────────────────────────────────
        with mlflow.start_run(run_name=run_id) as run:
            mlflow.set_tags({**tags, "tenant_id": tenant_id, "model_type": model_type.value})
            mlflow.log_params({
                "epochs": epochs, "batch_size": batch_size,
                "learning_rate": learning_rate,
                "horizon": H, "window_size": L,
                "num_features": F, "num_targets": T, "num_assets": num_assets,
            })

            module = TemporalLightningModule(model, learning_rate, quantiles)

            trainer = pl.Trainer(
                max_epochs=epochs,
                accelerator="gpu" if torch.cuda.is_available() else "cpu",
                devices=self.settings.TRAINING_GPUS if use_distributed else 1,
                strategy="ddp" if use_distributed else "auto",
                precision="16-mixed" if torch.cuda.is_available() else 32,
                accumulate_grad_batches=self.settings.TRAINING_GRADIENT_ACCUMULATION,
                gradient_clip_val=1.0,
                enable_progress_bar=True,
                log_every_n_steps=10,
            )

            num_workers = 4
            loader_kwargs = dict(num_workers=num_workers, pin_memory=torch.cuda.is_available(),
                                 persistent_workers=num_workers > 0)

            train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True,  **loader_kwargs)
            val_loader   = DataLoader(val_ds,   batch_size=batch_size, shuffle=False, **loader_kwargs)

            t0 = time.time()
            trainer.fit(module, train_loader, val_loader)
            elapsed = time.time() - t0

            val_loss = float(trainer.callback_metrics.get("val/loss", 0.0))
            val_mse  = float(trainer.callback_metrics.get("val/mse",  0.0))

            mlflow.log_metrics({"val_loss": val_loss, "val_mse": val_mse, "training_time_s": elapsed})
            mlflow.pytorch.log_model(
                model, artifact_path="model",
                registered_model_name=f"{model_type.value}_{tenant_id}",
            )

            log.info("trainer.done", run_id=run.info.run_id, val_loss=val_loss, val_mse=val_mse)

    # ─────────────────────────────────────────────────────────────────────────
    # Model factory
    # ─────────────────────────────────────────────────────────────────────────

    def _build_model(
        self,
        model_type:   ModelType,
        seq_len:      int,
        pred_len:     int,
        num_features: int,
        num_targets:  int,
        num_assets:   int,
    ) -> nn.Module:

        common = dict(
            seq_len=seq_len, pred_len=pred_len,
            num_assets=num_assets,
        )

        if model_type == ModelType.patchtst:
            from forecasting.models.patchtst.model import PatchTSTModel
            return PatchTSTModel(**common, num_features=num_features, num_targets=num_targets)

        if model_type == ModelType.tft:
            from forecasting.models.tft.model import TFTModel
            return TFTModel(**common, num_dynamic_vars=num_features, num_targets=num_targets)

        if model_type == ModelType.nbeats:
            from forecasting.models.nbeats.model import NBEATSModel
            return NBEATSModel(**common, num_features=num_features, num_targets=num_targets)

        # default: GRU
        from forecasting.models.gru.model import GRUSeq2Seq
        return GRUSeq2Seq(
            input_size=num_features, output_size=num_targets,
            pred_len=pred_len, num_assets=num_assets,
        )
