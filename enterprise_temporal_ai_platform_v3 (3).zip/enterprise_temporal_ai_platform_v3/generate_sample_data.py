#!/usr/bin/env python3
"""
Enterprise Temporal AI Platform — Sample Data Generator

Generates realistic time-series CSV files for testing.

Usage:
    python generate_sample_data.py                    # default: energy.csv
    python generate_sample_data.py --type sales       # retail sales pattern
    python generate_sample_data.py --type server      # server CPU/memory metrics
    python generate_sample_data.py --type sensor      # IoT sensor readings
    python generate_sample_data.py --type multivar    # multi-variate dataset
    python generate_sample_data.py --rows 5000 --anomalies 10
"""

from __future__ import annotations

import argparse
import math
import os
from pathlib import Path

import numpy as np
import pandas as pd


def generate_energy(rows: int = 8760, n_anomalies: int = 5, seed: int = 42) -> pd.DataFrame:
    """
    Hourly energy consumption with:
    - Daily cycle (peak at 9am and 6pm)
    - Weekly pattern (lower on weekends)
    - Monthly seasonality
    - Trend + noise
    - Injected anomaly spikes
    """
    np.random.seed(seed)
    ts = pd.date_range("2023-01-01", periods=rows, freq="1H")
    t = np.arange(rows)

    # Base components
    hourly_cycle = 3 * np.sin(2 * math.pi * t / 24 - math.pi / 2) + \
                   1.5 * np.sin(4 * math.pi * t / 24)
    weekly_cycle = 1.5 * np.sin(2 * math.pi * t / (24 * 7))
    trend = 0.0003 * t
    noise = np.random.normal(0, 0.5, rows)
    base_load = 10.0

    value = base_load + hourly_cycle + weekly_cycle + trend + noise

    # Weekend reduction
    weekday = ts.dayofweek.values
    value[weekday >= 5] *= 0.75

    # Inject anomalies
    anomaly_indices = np.random.choice(rows // 2 + np.arange(rows // 2), n_anomalies, replace=False)
    for idx in anomaly_indices:
        value[idx] *= np.random.choice([3.5, 0.1])  # spike up or near-zero

    value = np.maximum(value, 0)   # no negative energy

    df = pd.DataFrame({
        "timestamp": ts,
        "kwh": np.round(value, 4),
        "hour": ts.hour,
        "day_of_week": ts.dayofweek,
        "is_weekend": (ts.dayofweek >= 5).astype(int),
        "month": ts.month,
    })
    return df


def generate_sales(rows: int = 730, n_anomalies: int = 5, seed: int = 42) -> pd.DataFrame:
    """Daily retail sales with weekly + monthly seasonality and promotions."""
    np.random.seed(seed)
    ts = pd.date_range("2022-01-01", periods=rows, freq="1D")
    t = np.arange(rows)

    weekly = 200 * np.sin(2 * math.pi * t / 7 + math.pi)
    monthly = 80 * np.sin(2 * math.pi * t / 30)
    trend = 0.05 * t
    noise = np.random.normal(0, 50, rows)
    base = 500

    sales = base + weekly + monthly + trend + noise

    # Promotions (sales spikes)
    promo_days = np.random.choice(rows, n_anomalies, replace=False)
    for d in promo_days:
        sales[d] *= np.random.uniform(1.5, 2.5)

    sales = np.maximum(sales, 0)
    df = pd.DataFrame({
        "date": ts,
        "sales": np.round(sales, 2),
        "day_of_week": ts.dayofweek,
        "month": ts.month,
        "is_weekend": (ts.dayofweek >= 5).astype(int),
    })
    return df


def generate_server_metrics(rows: int = 4320, n_anomalies: int = 8, seed: int = 42) -> pd.DataFrame:
    """
    10-minute server metrics: CPU, memory, latency, requests/sec.
    Anomalies represent outages or traffic spikes.
    """
    np.random.seed(seed)
    ts = pd.date_range("2024-01-01", periods=rows, freq="10T")
    t = np.arange(rows)

    # CPU: business hours pattern
    cpu_daily = 20 * np.sin(2 * math.pi * t / 144 - math.pi / 2) + \
                10 * np.sin(4 * math.pi * t / 144)
    cpu_weekly = 5 * np.sin(2 * math.pi * t / (144 * 7))
    cpu_noise = np.random.normal(0, 3, rows)
    cpu = np.clip(35 + cpu_daily + cpu_weekly + cpu_noise, 5, 100)

    # Memory: gradual growth with GC dips
    mem_trend = 0.003 * t
    mem_sawtooth = 5 * (t % 144) / 144
    mem_noise = np.random.normal(0, 2, rows)
    mem = np.clip(40 + mem_trend + mem_sawtooth + mem_noise, 20, 95)

    # Latency: correlated with CPU
    latency = 50 + 2 * cpu + np.random.normal(0, 10, rows)

    # Requests/sec
    rps = np.maximum(800 + 300 * np.sin(2 * math.pi * t / 144) + np.random.normal(0, 50, rows), 0)

    # Inject anomalies — CPU spikes + memory spikes
    anom_idx = np.random.choice(rows // 2 + np.arange(rows // 2), n_anomalies, replace=False)
    for i in anom_idx:
        window = min(6, rows - i)
        cpu[i:i + window] = np.random.uniform(85, 100, window)
        latency[i:i + window] *= 5

    df = pd.DataFrame({
        "timestamp": ts,
        "cpu_percent": np.round(cpu, 2),
        "memory_percent": np.round(mem, 2),
        "latency_ms": np.round(latency, 2),
        "requests_per_sec": np.round(rps, 2),
    })
    return df


def generate_iot_sensor(rows: int = 10080, n_anomalies: int = 12, seed: int = 42) -> pd.DataFrame:
    """Minute-level IoT temperature sensor with noise and fault events."""
    np.random.seed(seed)
    ts = pd.date_range("2024-01-01", periods=rows, freq="1T")
    t = np.arange(rows)

    daily = 5 * np.sin(2 * math.pi * t / 1440)
    noise = np.random.normal(0, 0.3, rows)
    trend = 0.0001 * t
    temp = 21 + daily + noise + trend

    # Fault events (step changes)
    fault_idx = np.random.choice(rows // 2 + np.arange(rows // 2), n_anomalies, replace=False)
    for i in fault_idx:
        window = min(np.random.randint(5, 30), rows - i)
        temp[i:i + window] += np.random.choice([+10, -8])

    df = pd.DataFrame({
        "ts": ts,
        "temperature_c": np.round(temp, 3),
        "sensor_id": "SENSOR_001",
    })
    return df


def generate_multivariate(rows: int = 8760, seed: int = 42) -> pd.DataFrame:
    """Multi-variate hourly dataset with correlated features."""
    np.random.seed(seed)
    ts = pd.date_range("2023-01-01", periods=rows, freq="1H")
    t = np.arange(rows)

    # Wind speed
    wind = np.abs(8 + 4 * np.sin(2 * math.pi * t / (24 * 30)) + np.random.normal(0, 2, rows))

    # Temperature
    temp = 15 + 10 * np.sin(2 * math.pi * t / (24 * 365)) + \
           5 * np.sin(2 * math.pi * t / 24) + np.random.normal(0, 1, rows)

    # Solar irradiance (only during day)
    hour = ts.hour.values
    solar_base = np.maximum(np.sin(math.pi * (hour - 6) / 12), 0)
    solar = 900 * solar_base + np.random.normal(0, 30, rows)
    solar = np.maximum(solar, 0)

    # Power output (correlated with wind + solar)
    power = 0.3 * wind ** 2 + 0.001 * solar + 0.5 * np.random.normal(0, 5, rows)
    power = np.maximum(power, 0)

    df = pd.DataFrame({
        "timestamp": ts,
        "power_kw": np.round(power, 4),
        "wind_speed_ms": np.round(wind, 3),
        "temperature_c": np.round(temp, 3),
        "solar_irradiance_wm2": np.round(solar, 2),
        "hour": hour,
        "month": ts.month,
    })
    return df


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

GENERATORS = {
    "energy": (generate_energy, "kwh", "Energy consumption (hourly kWh)"),
    "sales": (generate_sales, "sales", "Retail sales (daily $)"),
    "server": (generate_server_metrics, "cpu_percent", "Server CPU/memory/latency (10-min)"),
    "sensor": (generate_iot_sensor, "temperature_c", "IoT temperature sensor (1-min)"),
    "multivar": (generate_multivariate, "power_kw", "Wind/solar power multi-variate (hourly)"),
}


def main():
    parser = argparse.ArgumentParser(description="Generate sample time-series CSV")
    parser.add_argument("--type", default="energy", choices=list(GENERATORS.keys()))
    parser.add_argument("--rows", type=int, default=None)
    parser.add_argument("--anomalies", type=int, default=5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out", default="./data", help="Output directory")
    args = parser.parse_args()

    Path(args.out).mkdir(parents=True, exist_ok=True)

    fn, target_col, desc = GENERATORS[args.type]

    kw = {"seed": args.seed, "n_anomalies": args.anomalies}
    if args.rows:
        kw["rows"] = args.rows

    print(f"Generating {args.type} dataset: {desc}")
    df = fn(**kw)

    out_path = Path(args.out) / f"{args.type}.csv"
    df.to_csv(out_path, index=False)

    print(f"✅ Saved: {out_path}")
    print(f"   Rows       : {len(df):,}")
    print(f"   Columns    : {list(df.columns)}")
    print(f"   Target col : {target_col}")
    print(f"\n   Sample:")
    print(df.head(3).to_string(index=False))

    print(f"""
To run the Temporal AI pipeline on this file:

  python run_local.py --csv {out_path} --target {target_col}

  # With longer training:
  python run_local.py --csv {out_path} --target {target_col} --model patchtst --epochs 50

  # Quick mode (no training):
  python run_local.py --csv {out_path} --target {target_col} --quick
""")


if __name__ == "__main__":
    main()
