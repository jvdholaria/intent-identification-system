"""
Enterprise Temporal AI Platform — MLflow Model Registry

Handles model registration, versioning, staging transitions,
and loading production models for inference.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import mlflow
import mlflow.pytorch
from mlflow.tracking import MlflowClient

from shared.config.settings import settings
from shared.logging.logger import get_logger

log = get_logger("mlops.registry")


class ModelRegistry:
    """
    Wrapper around MLflow Model Registry providing:
    - Model registration
    - Stage promotion (Staging → Production → Archived)
    - Production model loading
    - Rollback support
    - Per-tenant model isolation
    """

    def __init__(self):
        mlflow.set_tracking_uri(settings.MLFLOW_TRACKING_URI)
        self.client = MlflowClient()

    # ── Registration ──────────────────────────────────────────────────────────

    def register(
        self,
        run_id: str,
        model_artifact_path: str,
        model_name: str,
        description: str = "",
        tags: Optional[Dict[str, str]] = None,
    ) -> mlflow.entities.model_registry.ModelVersion:
        """
        Register a model from a completed training run.
        Returns the new ModelVersion.
        """
        model_uri = f"runs:/{run_id}/{model_artifact_path}"
        version = mlflow.register_model(
            model_uri=model_uri,
            name=model_name,
            tags=tags or {},
        )
        if description:
            self.client.update_model_version(
                name=model_name,
                version=version.version,
                description=description,
            )
        log.info(
            "registry.registered",
            name=model_name,
            version=version.version,
            run_id=run_id,
        )
        return version

    # ── Stage transitions ─────────────────────────────────────────────────────

    def promote_to_staging(self, name: str, version: str) -> None:
        self.client.transition_model_version_stage(
            name=name, version=version, stage="Staging", archive_existing_versions=False
        )
        log.info("registry.promoted_to_staging", name=name, version=version)

    def promote_to_production(self, name: str, version: str) -> None:
        self.client.transition_model_version_stage(
            name=name, version=version, stage="Production", archive_existing_versions=True
        )
        log.info("registry.promoted_to_production", name=name, version=version)

    def archive(self, name: str, version: str) -> None:
        self.client.transition_model_version_stage(
            name=name, version=version, stage="Archived"
        )
        log.info("registry.archived", name=name, version=version)

    # ── Loading ───────────────────────────────────────────────────────────────

    def load_production_model(self, name: str, map_location: str = "cpu") -> Any:
        """Load the current Production-staged model for inference."""
        model_uri = f"models:/{name}/Production"
        try:
            model = mlflow.pytorch.load_model(model_uri, map_location=map_location)
            model.eval()
            log.info("registry.loaded", name=name, stage="Production")
            return model
        except Exception as exc:
            log.error("registry.load_failed", name=name, exc=str(exc))
            raise

    def load_model_version(
        self, name: str, version: str, map_location: str = "cpu"
    ) -> Any:
        """Load a specific model version."""
        model_uri = f"models:/{name}/{version}"
        model = mlflow.pytorch.load_model(model_uri, map_location=map_location)
        model.eval()
        return model

    # ── Rollback ──────────────────────────────────────────────────────────────

    def rollback(self, name: str) -> Optional[str]:
        """
        Rollback to the previous Production model version.
        Archives the current Production and re-promotes the last Archived.
        Returns the rolled-back version number or None.
        """
        versions = self.client.get_latest_versions(name)
        production_versions = [v for v in versions if v.current_stage == "Production"]
        archived_versions = sorted(
            [v for v in versions if v.current_stage == "Archived"],
            key=lambda v: int(v.version),
            reverse=True,
        )

        if not archived_versions:
            log.warning("registry.rollback_no_archived", name=name)
            return None

        # Archive current production
        for pv in production_versions:
            self.archive(name, pv.version)

        # Promote latest archived back to production
        rollback_version = archived_versions[0].version
        self.promote_to_production(name, rollback_version)
        log.info("registry.rolled_back", name=name, version=rollback_version)
        return rollback_version

    # ── Listing ───────────────────────────────────────────────────────────────

    def list_models(self) -> List[Dict]:
        """Return all registered models with their current versions."""
        models = self.client.search_registered_models()
        return [
            {
                "name": m.name,
                "description": m.description,
                "latest_versions": [
                    {
                        "version": v.version,
                        "stage": v.current_stage,
                        "created_at": v.creation_timestamp,
                        "run_id": v.run_id,
                    }
                    for v in m.latest_versions
                ],
            }
            for m in models
        ]

    def get_production_version(self, name: str) -> Optional[str]:
        """Return the current Production version number for a model."""
        try:
            versions = self.client.get_latest_versions(name, stages=["Production"])
            return versions[0].version if versions else None
        except Exception:
            return None


# ── Singleton accessor ────────────────────────────────────────────────────────

_registry: Optional[ModelRegistry] = None


def get_registry() -> ModelRegistry:
    global _registry
    if _registry is None:
        _registry = ModelRegistry()
    return _registry
