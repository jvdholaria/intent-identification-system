"""
Enterprise Temporal AI Platform — N-BEATS Predictor

N-BEATS: Neural Basis Expansion Analysis for Interpretable Time Series Forecasting
(Oreshkin et al., 2020). Pure MLP stack with basis expansion.
Supports generic and interpretable (trend + seasonality) configurations.
"""

from __future__ import annotations

import math
from typing import List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn

from shared.config.settings import Settings
from shared.logging.logger import get_logger

log = get_logger("models.nbeats")


class NBEATSBlock(nn.Module):
    """
    Single N-BEATS block: FC stack → basis expansion for backcast + forecast.
    """

    def __init__(
        self,
        input_size: int,
        theta_size: int,
        horizon: int,
        hidden_units: int = 256,
        num_layers: int = 4,
    ):
        super().__init__()
        self.input_size = input_size
        self.theta_size = theta_size
        self.horizon = horizon

        layers = [nn.Linear(input_size, hidden_units), nn.ReLU()]
        for _ in range(num_layers - 1):
            layers += [nn.Linear(hidden_units, hidden_units), nn.ReLU()]
        self.fc_stack = nn.Sequential(*layers)
        self.backcast_head = nn.Linear(hidden_units, theta_size)
        self.forecast_head = nn.Linear(hidden_units, theta_size)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        h = self.fc_stack(x)
        theta_b = self.backcast_head(h)
        theta_f = self.forecast_head(h)
        return theta_b, theta_f


class GenericBlock(NBEATSBlock):
    """
    Generic N-BEATS block: uses linear basis.
    theta directly represents the output values.
    """

    def __init__(self, input_size: int, horizon: int, hidden_units: int = 256):
        super().__init__(input_size, max(input_size, horizon), horizon, hidden_units)
        self.backcast_proj = nn.Linear(self.theta_size, input_size)
        self.forecast_proj = nn.Linear(self.theta_size, horizon)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        theta_b, theta_f = super().forward(x)
        return self.backcast_proj(theta_b), self.forecast_proj(theta_f)


class TrendBlock(NBEATSBlock):
    """
    Interpretable trend block: polynomial basis expansion.
    """

    def __init__(self, input_size: int, horizon: int, degree: int = 3):
        super().__init__(input_size, degree + 1, horizon)
        # Vandermonde polynomial basis
        t_b = torch.linspace(-1, 1, input_size)
        t_f = torch.linspace(0, 1, horizon)
        T_b = torch.stack([t_b ** i for i in range(degree + 1)], dim=1)
        T_f = torch.stack([t_f ** i for i in range(degree + 1)], dim=1)
        self.register_buffer("T_b", T_b)   # (input_size, degree+1)
        self.register_buffer("T_f", T_f)   # (horizon, degree+1)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        theta_b, theta_f = super().forward(x)
        backcast = theta_b @ self.T_b.t()
        forecast = theta_f @ self.T_f.t()
        return backcast, forecast


class SeasonalityBlock(NBEATSBlock):
    """
    Interpretable seasonality block: Fourier basis expansion.
    """

    def __init__(self, input_size: int, horizon: int, num_harmonics: int = 1):
        n_freqs = 2 * num_harmonics
        super().__init__(input_size, n_freqs, horizon)

        # Fourier basis
        freqs = torch.arange(1, num_harmonics + 1).float()
        t_b = torch.linspace(0, 2 * math.pi, input_size)
        t_f = torch.linspace(0, 2 * math.pi, horizon)

        S_b = torch.cat([
            torch.stack([torch.sin(f * t_b) for f in freqs], dim=1),
            torch.stack([torch.cos(f * t_b) for f in freqs], dim=1),
        ], dim=1)
        S_f = torch.cat([
            torch.stack([torch.sin(f * t_f) for f in freqs], dim=1),
            torch.stack([torch.cos(f * t_f) for f in freqs], dim=1),
        ], dim=1)
        self.register_buffer("S_b", S_b)
        self.register_buffer("S_f", S_f)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        theta_b, theta_f = super().forward(x)
        backcast = theta_b @ self.S_b.t()
        forecast = theta_f @ self.S_f.t()
        return backcast, forecast


class NBEATSStack(nn.Module):
    """Stack of N-BEATS blocks with residual connections."""

    def __init__(self, blocks: List[NBEATSBlock]):
        super().__init__()
        self.blocks = nn.ModuleList(blocks)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        residual = x
        stack_forecast = torch.zeros(x.size(0), self.blocks[0].horizon, device=x.device)
        for block in self.blocks:
            backcast, forecast = block(residual)
            residual = residual - backcast
            stack_forecast = stack_forecast + forecast
        return residual, stack_forecast


class NBEATSModel(nn.Module):
    """
    N-BEATS: interpretable decomposition into trend + seasonality + generic residual.
    """

    def __init__(
        self,
        seq_len: int = 168,
        pred_len: int = 120,
        hidden_units: int = 256,
        num_blocks_per_stack: int = 3,
        use_interpretable: bool = True,
    ):
        super().__init__()
        self.seq_len = seq_len
        self.pred_len = pred_len

        stacks = []

        if use_interpretable:
            trend_blocks = [TrendBlock(seq_len, pred_len, degree=3) for _ in range(num_blocks_per_stack)]
            stacks.append(NBEATSStack(trend_blocks))

            seasonal_blocks = [SeasonalityBlock(seq_len, pred_len, num_harmonics=4) for _ in range(num_blocks_per_stack)]
            stacks.append(NBEATSStack(seasonal_blocks))

        # Generic stack (always present)
        generic_blocks = [GenericBlock(seq_len, pred_len, hidden_units) for _ in range(num_blocks_per_stack)]
        stacks.append(NBEATSStack(generic_blocks))

        self.stacks = nn.ModuleList(stacks)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, seq_len)
        residual = x
        forecast = torch.zeros(x.size(0), self.pred_len, device=x.device)
        for stack in self.stacks:
            residual, stack_forecast = stack(residual)
            forecast = forecast + stack_forecast
        return forecast


class NBeatsPredictor:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._model: Optional[NBEATSModel] = None

    def _load(self):
        if self._model is not None:
            return
        self._model = NBEATSModel(
            seq_len=self.settings.FORECAST_WINDOW_SIZE,
            pred_len=self.settings.FORECAST_HORIZON,
        ).to(self.device)
        self._model.eval()
        log.info("nbeats.loaded", device=str(self.device))

    def predict(self, x: np.ndarray, horizon: int) -> np.ndarray:
        self._load()
        with torch.no_grad():
            arr = np.asarray(x, dtype=np.float32).flatten()
            tensor = torch.tensor(arr).unsqueeze(0).to(self.device)  # (1, seq_len)
            out = self._model(tensor)   # (1, pred_len)
            result = out.squeeze(0).cpu().numpy()
            if len(result) >= horizon:
                return result[:horizon]
            return np.pad(result, (0, horizon - len(result)), mode="edge")
