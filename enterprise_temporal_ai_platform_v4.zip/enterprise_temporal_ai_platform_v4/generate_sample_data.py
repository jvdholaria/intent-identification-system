"""
Enterprise Temporal AI Platform V4 — Multi-Asset Sample Data Generator

Generates a CSV with the V4 schema:
    ts, asset_id, temperature, pressure, vibration, humidity

Supports N assets with realistic, slightly different telemetry patterns.
"""

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def generate(
    num_assets:  int   = 5,
    rows_per_asset: int = 2000,
    output_path: str  = "./data/sample_multiasset.csv",
    seed:        int   = 42,
):
    np.random.seed(seed)
    rng = np.random.default_rng(seed)

    asset_ids = [f"A{i+1:03d}" for i in range(num_assets)]
    start_ts  = pd.Timestamp("2023-01-01")
    freq      = "1h"

    records = []
    for asset_id in asset_ids:
        ts_index = pd.date_range(start=start_ts, periods=rows_per_asset, freq=freq)
        n = rows_per_asset
        t = np.linspace(0, 4 * np.pi, n)

        # Each asset has slightly different base levels and amplitudes
        asset_seed = sum(ord(c) for c in asset_id)
        rng2       = np.random.default_rng(asset_seed)

        temp_base  = rng2.uniform(60.0,  90.0)
        pres_base  = rng2.uniform(1.0,   2.0)
        vib_base   = rng2.uniform(0.1,   0.5)
        hum_base   = rng2.uniform(30.0,  60.0)

        temperature = temp_base + 10 * np.sin(t) + 2 * np.sin(3 * t) + rng.normal(0, 0.5, n)
        pressure    = pres_base + 0.2 * np.cos(t) + rng.normal(0, 0.02, n)
        vibration   = vib_base  + 0.1 * np.abs(np.sin(2 * t)) + rng.normal(0, 0.01, n)
        humidity    = hum_base  + 5 * np.sin(t * 0.5) + rng.normal(0, 1.0, n)

        # Inject some anomalies
        anom_idx = rng.integers(n // 2, n, size=5)
        temperature[anom_idx] += rng.uniform(20, 40, size=5)
        vibration[anom_idx]   += rng.uniform(0.5, 1.5, size=5)

        df = pd.DataFrame({
            "ts":          ts_index.strftime("%Y-%m-%d %H:%M:%S"),
            "asset_id":    asset_id,
            "temperature": np.round(temperature, 4),
            "pressure":    np.round(pressure,    4),
            "vibration":   np.round(vibration,   4),
            "humidity":    np.round(humidity,     4),
        })
        records.append(df)

    full = pd.concat(records, ignore_index=True)

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    full.to_csv(output_path, index=False)
    print(f"✅ Generated {len(full):,} rows × {num_assets} assets → {output_path}")
    print(f"   Schema: {list(full.columns)}")
    print(f"   Assets: {asset_ids}")
    print(full.head(3).to_string())
    return output_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--num_assets",      type=int, default=5)
    parser.add_argument("--rows_per_asset",  type=int, default=2000)
    parser.add_argument("--output",          type=str, default="./data/sample_multiasset.csv")
    parser.add_argument("--seed",            type=int, default=42)
    args = parser.parse_args()
    generate(args.num_assets, args.rows_per_asset, args.output, args.seed)
