
"""
HTSMO Framework: Heterogeneous Time-Series Multi-Output Framework
Author: Expert ML Engineer
Version: 1.0.0
"""

import logging
import pickle
import warnings
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
import shap
import torch
import torch.nn as nn
from lightgbm import LGBMRegressor
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.model_selection import TimeSeriesSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer

# Configure Logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# ==============================================================================
# 1. Configuration & Data Structures
# ==============================================================================

@dataclass
class ModelConfig:
    """Configuration for the modeling pipeline."""
    target_frequency: str = '1T'  # e.g., '1T' (1 min), '1H' (1 hour)
    lookback_window: int = 60     # Number of past time steps to include for DL
    test_size: float = 0.2
    n_splits: int = 5
    model_type: str = 'lightgbm'  # 'lightgbm' or 'pytorch'
    model_params: Dict = field(default_factory=dict)
    artifact_path: Path = Path('./artifacts')

@dataclass
class FeatureSpec:
    """Specification for input features."""
    dynamic_numeric: List[str]
    dynamic_categorical: List[str]
    static_numeric: List[str]
    static_categorical: List[str]
    target_columns: List[str]
    timestamp_col: str = 'timestamp'
    source_id_col: Optional[str] = None

# ==============================================================================
# 2. Time Alignment & Preprocessing
# ==============================================================================

class AsyncDataAligner:
    """
    Aligns heterogeneous, asynchronous time-series data to a unified grid.
    Handles multi-frequency inputs by resampling to a target frequency.
    """
    def __init__(self, timestamp_col: str, target_frequency: str, method: str = 'ffill'):
        self.timestamp_col = timestamp_col
        self.target_frequency = target_frequency
        self.method = method  # 'ffill', 'interpolate'

    def align(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Resamples dataframe to target frequency.
        Assumes df has a datetime index or column.
        """
        if df.empty:
            return df

        # Ensure timestamp is datetime
        if not pd.api.types.is_datetime64_any_dtype(df[self.timestamp_col]):
            df[self.timestamp_col] = pd.to_datetime(df[self.timestamp_col])

        df = df.set_index(self.timestamp_col)
        
        # Resample
        if self.method == 'ffill':
            resampled = df.resample(self.target_frequency).ffill()
        elif self.method == 'interpolate':
            resampled = df.resample(self.target_frequency).mean().interpolate(method='time')
        else:
            resampled = df.resample(self.target_frequency).mean()

        return resampled.reset_index().rename(columns={'index': self.timestamp_col})

class FeatureEngine(BaseEstimator, TransformerMixin):
    """
    Scikit-learn compatible transformer for handling mixed data types
    and missing values specifically for time-series contexts.
    """
    def __init__(self, spec: FeatureSpec):
        self.spec = spec
        self.pipeline = None

    def fit(self, X: pd.DataFrame, y: Optional[pd.DataFrame] = None):
        # Define transformers
        numeric_transformer = Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='median')),
            ('scaler', StandardScaler())
        ])
        
        categorical_transformer = Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='most_frequent')),
            ('onehot', OneHotEncoder(handle_unknown='ignore'))
        ])

        # Collect columns
        num_cols = self.spec.dynamic_numeric + self.spec.static_numeric
        cat_cols = self.spec.dynamic_categorical + self.spec.static_categorical
        
        # Filter columns that actually exist in X
        existing_num = [c for c in num_cols if c in X.columns]
        existing_cat = [c for c in cat_cols if c in X.columns]

        transformations = []
        if existing_num:
            transformations.append(('num', numeric_transformer, existing_num))
        if existing_cat:
            transformations.append(('cat', categorical_transformer, existing_cat))

        if not transformations:
            raise ValueError("No valid features found in input dataframe.")

        self.pipeline = ColumnTransformer(transformers=transformations)
        self.pipeline.fit(X)
        return self

    def transform(self, X: pd.DataFrame) -> np.ndarray:
        if self.pipeline is None:
            raise RuntimeError("FeatureEngine must be fitted before transform.")
        return self.pipeline.transform(X)

# ==============================================================================
# 3. Modeling Abstraction
# ==============================================================================

class BaseModel(ABC):
    """Abstract Base Class for Models to ensure interface consistency."""
    
    @abstractmethod
    def fit(self, X: np.ndarray, y: np.ndarray, **kwargs):
        pass

    @abstractmethod
    def predict(self, X: np.ndarray) -> np.ndarray:
        pass

    @abstractmethod
    def save(self, path: Path):
        pass

    @abstractmethod
    def load(self, path: Path):
        pass

class LightGBMModel(BaseModel):
    """Wrapper for LightGBM supporting multi-output regression."""
    
    def __init__(self, params: Dict = None):
        self.params = params or {'n_estimators': 100, 'learning_rate': 0.1}
        self.model = None

    def fit(self, X: np.ndarray, y: np.ndarray, **kwargs):
        # LightGBM natively supports multi-output if y is 2D
        self.model = LGBMRegressor(**self.params)
        self.model.fit(X, y, **kwargs)
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        return self.model.predict(X)

    def save(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'wb') as f:
            pickle.dump(self.model, f)

    def load(self, path: Path):
        with open(path, 'rb') as f:
            self.model = pickle.load(f)

class TemporalNet(nn.Module):
    """Simple LSTM/MLP Hybrid for Time-Series."""
    def __init__(self, input_dim: int, output_dim: int, hidden_dim: int = 64):
        super().__init__()
        self.lstm = nn.LSTM(input_dim, hidden_dim, batch_first=True)
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim)
        )

    def forward(self, x):
        # x shape: (Batch, Seq_Len, Features)
        lstm_out, _ = self.lstm(x)
        # Take last time step
        return self.fc(lstm_out[:, -1, :])

class PyTorchModel(BaseModel):
    """Wrapper for PyTorch models with training loop."""
    
    def __init__(self, input_dim: int, output_dim: int, config: Dict = None):
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.config = config or {'epochs': 50, 'lr': 0.001, 'batch_size': 32}
        self.model = None
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    def fit(self, X: np.ndarray, y: np.ndarray, **kwargs):
        # Reshape for LSTM: (Samples, Lookback, Features)
        # Note: For this generic framework, we assume X is already windowed if using DL
        # If X is 2D (tabular), we add a sequence dimension of 1
        if len(X.shape) == 2:
            X = np.expand_dims(X, axis=1)
        
        X_tensor = torch.FloatTensor(X).to(self.device)
        y_tensor = torch.FloatTensor(y).to(self.device)

        self.model = TemporalNet(X.shape[2], self.output_dim).to(self.device)
        optimizer = torch.optim.Adam(self.model.parameters(), lr=self.config['lr'])
        criterion = nn.MSELoss()

        self.model.train()
        dataset = torch.utils.data.TensorDataset(X_tensor, y_tensor)
        loader = torch.utils.data.DataLoader(dataset, batch_size=self.config['batch_size'], shuffle=True)

        for epoch in range(self.config['epochs']):
            total_loss = 0
            for batch_x, batch_y in loader:
                optimizer.zero_grad()
                outputs = self.model(batch_x)
                loss = criterion(outputs, batch_y)
                loss.backward()
                optimizer.step()
                total_loss += loss.item()
            if epoch % 10 == 0:
                logger.info(f"Epoch {epoch}, Loss: {total_loss/len(loader):.4f}")
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        if len(X.shape) == 2:
            X = np.expand_dims(X, axis=1)
        X_tensor = torch.FloatTensor(X).to(self.device)
        self.model.eval()
        with torch.no_grad():
            preds = self.model(X_tensor)
        return preds.cpu().numpy()

    def save(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(self.model.state_dict(), path)

    def load(self, path: Path):
        self.model = TemporalNet(self.input_dim, self.output_dim).to(self.device)
        self.model.load_state_dict(torch.load(path, map_location=self.device))
        self.model.eval()

# ==============================================================================
# 4. Training & Evaluation Pipeline
# ==============================================================================

class SystemPredictor:
    """
    Main Orchestrator class. Handles alignment, feature engineering, 
    training, evaluation, and inference.
    """
    def __init__(self, config: ModelConfig, feature_spec: FeatureSpec):
        self.config = config
        self.spec = feature_spec
        self.aligner = AsyncDataAligner(feature_spec.timestamp_col, config.target_frequency)
        self.feature_engine = FeatureEngine(feature_spec)
        self.model: Optional[BaseModel] = None
        self.is_fitted = False

    def prepare_data(self, raw_df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """
        Full preprocessing pipeline: Align -> Clean -> Feature Transform.
        """
        logger.info("Aligning asynchronous data...")
        aligned_df = self.aligner.align(raw_df.copy())
        
        # Drop rows where targets are NaN (if any)
        aligned_df = aligned_df.dropna(subset=self.spec.target_columns)
        
        # Separate Features and Targets
        # Exclude timestamp and targets from features
        feature_cols = [c for c in aligned_df.columns 
                        if c not in self.spec.target_columns 
                        and c != self.spec.timestamp_col]
        
        X_raw = aligned_df[feature_cols]
        y_raw = aligned_df[self.spec.target_columns]

        logger.info("Engineering features...")
        X_processed = self.feature_engine.fit_transform(X_raw, y_raw)
        y_processed = y_raw.values

        return X_processed, y_processed, aligned_df

    def train(self, raw_df: pd.DataFrame) -> Dict[str, float]:
        """
        Train the model with TimeSeriesSplit to prevent leakage.
        """
        X, y, _ = self.prepare_data(raw_df)
        
        # Initialize Model
        if self.config.model_type == 'lightgbm':
            self.model = LightGBMModel(self.config.model_params)
        elif self.config.model_type == 'pytorch':
            self.model = PyTorchModel(X.shape[1], y.shape[1], self.config.model_params)
        else:
            raise ValueError(f"Unknown model type: {self.config.model_type}")

        # Time Series Split
        tscv = TimeSeriesSplit(n_splits=self.config.n_splits)
        metrics = []

        logger.info(f"Starting training with {self.config.n_splits} temporal splits...")
        
        for fold, (train_idx, val_idx) in enumerate(tscv.split(X)):
            X_train, X_val = X[train_idx], X[val_idx]
            y_train, y_val = y[train_idx], y[val_idx]

            # For DL, we might want to reset weights or fine-tune. 
            # For this framework, we retrain per fold for robust validation.
            if self.config.model_type == 'pytorch':
                self.model = PyTorchModel(X.shape[1], y.shape[1], self.config.model_params)

            self.model.fit(X_train, y_train)
            preds = self.model.predict(X_val)
            
            # Multi-output metrics (averaged across targets)
            mae = mean_absolute_error(y_val, preds)
            rmse = np.sqrt(mean_squared_error(y_val, preds))
            metrics.append({'fold': fold, 'mae': mae, 'rmse': rmse})
            logger.info(f"Fold {fold}: MAE={mae:.4f}, RMSE={rmse:.4f}")

        # Final fit on full data for deployment
        logger.info("Retraining on full dataset for deployment...")
        if self.config.model_type == 'pytorch':
            self.model = PyTorchModel(X.shape[1], y.shape[1], self.config.model_params)
        else:
            self.model = LightGBMModel(self.config.model_params)
            
        self.model.fit(X, y)
        self.is_fitted = True
        
        # Save Artifacts
        self.config.artifact_path.mkdir(parents=True, exist_ok=True)
        self.model.save(self.config.artifact_path / 'model.bin')
        with open(self.config.artifact_path / 'feature_engine.pkl', 'wb') as f:
            pickle.dump(self.feature_engine, f)

        avg_mae = np.mean([m['mae'] for m in metrics])
        return {'avg_mae': avg_mae, 'fold_metrics': metrics}

    def predict(self, raw_df: pd.DataFrame) -> pd.DataFrame:
        """
        Batch prediction on new raw data.
        """
        if not self.is_fitted:
            raise RuntimeError("Model must be trained before prediction.")
        
        # Load feature engine if needed (in case this is a new instance)
        if self.feature_engine.pipeline is None:
             with open(self.config.artifact_path / 'feature_engine.pkl', 'rb') as f:
                self.feature_engine = pickle.load(f)
        if self.model.model is None:
            self.model.load(self.config.artifact_path / 'model.bin')

        # Align and Transform
        aligned_df = self.aligner.align(raw_df.copy())
        feature_cols = [c for c in aligned_df.columns 
                        if c not in self.spec.target_columns 
                        and c != self.spec.timestamp_col]
        
        # Handle case where incoming data might miss columns present in training
        # Fill missing training columns with NaN (imputer will handle)
        training_cols = self.spec.dynamic_numeric + self.spec.dynamic_categorical + \
                        self.spec.static_numeric + self.spec.static_categorical
        # Filter to existing columns in aligned_df that were used in training
        # Note: In production, strict schema validation is preferred
        X_raw = aligned_df[[c for c in training_cols if c in aligned_df.columns]]
        
        X_proc = self.feature_engine.transform(X_raw)
        preds = self.model.predict(X_proc)

        # Reconstruct DataFrame
        pred_df = pd.DataFrame(preds, columns=self.spec.target_columns, index=aligned_df.index)
        pred_df[self.spec.timestamp_col] = aligned_df[self.spec.timestamp_col].values
        return pred_df

# ==============================================================================
# 5. Explainability Module
# ==============================================================================

class ModelExplainer:
    """
    Handles SHAP explanations for both Tree and Deep Learning models.
    """
    def __init__(self, model: BaseModel, feature_engine: FeatureEngine, spec: FeatureSpec):
        self.model = model
        self.feature_engine = feature_engine
        self.spec = spec
        self.explainer = None
        self.feature_names = None

    def _get_feature_names(self, X_sample: pd.DataFrame):
        """Extract feature names after preprocessing (handling OneHotEncoding)."""
        # This is a simplification. In production, use pipeline.named_steps to get get_feature_names_out
        # For sklearn >= 1.0
        try:
            names = self.feature_engine.pipeline.get_feature_names_out()
        except AttributeError:
            names = [f"feature_{i}" for i in range(X_sample.shape[1])]
        return names

    def fit_explainer(self, background_data: pd.DataFrame):
        """
        Initialize SHAP explainer using a background dataset.
        """
        logger.info("Initializing SHAP explainer...")
        # Preprocess background data
        X_bg = self.feature_engine.transform(background_data)
        self.feature_names = self._get_feature_names(background_data)

        if isinstance(self.model, LightGBMModel):
            # TreeSHAP is fast and exact
            self.explainer = shap.TreeExplainer(self.model.model)
        elif isinstance(self.model, PyTorchModel):
            # DeepSHAP is approximate and slower
            # We need a wrapper function for torch model that accepts numpy
            def model_predict(x):
                return self.model.predict(x)
            self.explainer = shap.KernelExplainer(model_predict, X_bg[:100]) # Sample for speed
        else:
            raise NotImplementedError("Explainer not supported for this model type.")

    def get_global_importance(self, X_data: pd.DataFrame, max_display: int = 10) -> pd.DataFrame:
        """
        Calculate global feature importance.
        """
        if self.explainer is None:
            raise RuntimeError("Explainer not fitted. Call fit_explainer first.")
        
        X_proc = self.feature_engine.transform(X_data)
        shap_values = self.explainer.shap_values(X_proc)
        
        # Handle multi-output SHAP (returns list of arrays)
        if isinstance(shap_values, list):
            # Average importance across all targets
            shap_summary = np.mean([np.abs(v).mean(axis=0) for v in shap_values], axis=0)
        else:
            shap_summary = np.abs(shap_values).mean(axis=0)

        importance_df = pd.DataFrame({
            'feature': self.feature_names,
            'importance': shap_summary
        }).sort_values(by='importance', ascending=False)

        return importance_df.head(max_display)

    def get_local_explanation(self, single_row: pd.DataFrame, target_idx: int = 0) -> Dict:
        """
        Explain a single prediction.
        """
        if self.explainer is None:
            raise RuntimeError("Explainer not fitted.")
            
        X_proc = self.feature_engine.transform(single_row)
        shap_values = self.explainer.shap_values(X_proc)

        # Extract for specific target
        if isinstance(shap_values, list):
            sv = shap_values[target_idx][0, :]
        else:
            sv = shap_values[0, :]

        return {
            'features': self.feature_names,
            'shap_values': sv.tolist(),
            'base_value': self.explainer.expected_value
        }

# ==============================================================================
# 6. Usage Example & Dummy Data Generation
# ==============================================================================

def generate_dummy_data() -> pd.DataFrame:
    """
    Generates heterogeneous, asynchronous data to simulate the problem context.
    """
    np.random.seed(42)
    n_samples = 5000
    
    # Source 1: High frequency sensor (every 10s)
    ts1 = pd.date_range(start='2023-01-01', periods=n_samples*6, freq='10S')
    df1 = pd.DataFrame({
        'timestamp': ts1,
        'sensor_temp': np.sin(np.arange(len(ts1))/100) + np.random.normal(0, 0.1, len(ts1)),
        'source_id': 'S1'
    })
    
    # Source 2: Low frequency logs (every 10 min)
    ts2 = pd.date_range(start='2023-01-01', periods=n_samples, freq='10T')
    df2 = pd.DataFrame({
        'timestamp': ts2,
        'log_error_count': np.random.poisson(5, len(ts2)),
        'system_status': np.random.choice(['OK', 'WARN', 'ERR'], len(ts2)),
        'source_id': 'S2'
    })
    
    # Merge asynchronously (outer join simulation)
    df = pd.concat([df1, df2], ignore_index=True).sort_values('timestamp').reset_index(drop=True)
    
    # Create Targets (dependent on features with lag)
    # Target 1: Continuous (Regression)
    df['target_pressure'] = df['sensor_temp'].shift(1).fillna(0) * 10 + np.random.normal(0, 1, len(df))
    # Target 2: Continuous (Regression)
    df['target_efficiency'] = (df['log_error_count'].shift(1).fillna(0) * -2) + 100 + np.random.normal(0, 5, len(df))
    
    return df

if __name__ == "__main__":
    # 1. Setup Config
    spec = FeatureSpec(
        dynamic_numeric=['sensor_temp', 'log_error_count'],
        dynamic_categorical=['system_status'],
        static_numeric=[],
        static_categorical=['source_id'],
        target_columns=['target_pressure', 'target_efficiency'],
        timestamp_col='timestamp'
    )
    
    config = ModelConfig(
        target_frequency='10T', # Align to 10 minutes
        model_type='lightgbm',
        model_params={'n_estimators': 50, 'verbose': -1},
        artifact_path=Path('./production_artifacts')
    )
    
    # 2. Initialize Framework
    predictor = SystemPredictor(config, spec)
    
    # 3. Generate Data & Train
    logger.info("Generating dummy data...")
    data = generate_dummy_data()
    
    logger.info("Training Model...")
    metrics = predictor.train(data)
    print(f"Training Complete. Avg MAE: {metrics['avg_mae']:.4f}")
    
    # 4. Inference
    logger.info("Running Inference...")
    # Simulate new batch
    new_data = data.tail(100).copy()
    predictions = predictor.predict(new_data)
    print(predictions.head())
    
    # 5. Explainability
    logger.info("Generating Explanations...")
    explainer = ModelExplainer(predictor.model, predictor.feature_engine, spec)
    # Use a subset for background
    bg_data = data.sample(100, random_state=42).drop(columns=spec.target_columns)
    explainer.fit_explainer(bg_data)
    
    importance = explainer.get_global_importance(bg_data)
    print("\nTop Feature Importances:")
    print(importance)
    
    local_exp = explainer.get_local_explanation(new_data.iloc[[0]])
    print(f"\nLocal SHAP values for first row: {local_exp['shap_values']}")