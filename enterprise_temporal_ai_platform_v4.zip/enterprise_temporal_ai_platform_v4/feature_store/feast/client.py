"""
Enterprise Temporal AI Platform — Feature Store Client

Wraps Feast for:
- Online feature retrieval (low-latency, from Redis)
- Offline feature retrieval (historical, from BigQuery)
- Feature materialisation
- Feature engineering pipelines
"""

from __future__ import annotations

import math
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from shared.config.settings import settings
from shared.logging.logger import get_logger

log = get_logger("feature_store.client")


class TemporalFeatureClient:
    """
    Unified client for online + offline feature retrieval via Feast,
    with built-in temporal feature engineering.
    """

    def __init__(self, repo_path: str = None):
        self.repo_path = repo_path or settings.FEAST_REPO_PATH
        self._store = None

    def _get_store(self):
        if self._store is None:
            from feast import FeatureStore
            self._store = FeatureStore(repo_path=self.repo_path)
        return self._store

    # ── Online retrieval ──────────────────────────────────────────────────────

    def get_online_features(
        self,
        series_ids: List[str],
        feature_refs: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Low-latency feature retrieval from the Redis online store.
        Used at inference time.
        """
        store = self._get_store()
        feature_refs = feature_refs or [
            "lag_features:lag_1h",
            "lag_features:lag_24h",
            "lag_features:lag_168h",
            "rolling_stats:rolling_mean_24h",
            "rolling_stats:rolling_std_24h",
            "seasonality_features:hour_of_day",
            "seasonality_features:day_of_week",
            "anomaly_features:drift_score_latest",
        ]
        entity_rows = [{"series_id": sid} for sid in series_ids]
        feature_vector = store.get_online_features(
            features=feature_refs,
            entity_rows=entity_rows,
        )
        return feature_vector.to_dict()

    # ── Offline retrieval ─────────────────────────────────────────────────────

    def get_historical_features(
        self,
        entity_df: pd.DataFrame,
        feature_service_name: str = "forecasting_features",
    ) -> pd.DataFrame:
        """
        Historical feature retrieval from BigQuery for training.
        entity_df must contain [series_id, event_timestamp] columns.
        """
        store = self._get_store()
        return store.get_historical_features(
            entity_df=entity_df,
            features=store.get_feature_service(feature_service_name),
        ).to_df()

    # ── Materialise ───────────────────────────────────────────────────────────

    def materialise(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
    ):
        """
        Materialise offline features into the Redis online store.
        Run periodically via Airflow or retraining triggers.
        """
        store = self._get_store()
        start = start_date or (datetime.utcnow() - timedelta(days=7))
        end = end_date or datetime.utcnow()
        store.materialize(start_date=start, end_date=end)
        log.info("feature_store.materialised", start=str(start), end=str(end))

    # ── Inline feature engineering ────────────────────────────────────────────

    @staticmethod
    def build_lag_features(series: np.ndarray, lags: List[int] = None) -> Dict[str, float]:
        """Compute lag features from a raw time series array."""
        lags = lags or [1, 6, 12, 24, 48, 168]
        features = {}
        for lag in lags:
            if len(series) > lag:
                features[f"lag_{lag}h"] = float(series[-lag - 1])
            else:
                features[f"lag_{lag}h"] = float(series[0])
        return features

    @staticmethod
    def build_rolling_stats(series: np.ndarray, windows: List[int] = None) -> Dict[str, float]:
        """Compute rolling statistics from a time series array."""
        windows = windows or [1, 6, 24, 168]
        features = {}
        for w in windows:
            window = series[-w:] if len(series) >= w else series
            features[f"rolling_mean_{w}h"] = float(np.mean(window))
            features[f"rolling_std_{w}h"] = float(np.std(window))
        if len(series) >= 24:
            w24 = series[-24:]
            features["rolling_min_24h"] = float(np.min(w24))
            features["rolling_max_24h"] = float(np.max(w24))
            features["rolling_p10_24h"] = float(np.percentile(w24, 10))
            features["rolling_p90_24h"] = float(np.percentile(w24, 90))
        return features

    @staticmethod
    def build_seasonality_features(dt: datetime) -> Dict[str, float]:
        """Compute Fourier-encoded seasonality features from a timestamp."""
        h = dt.hour
        d = dt.weekday()
        w = dt.isocalendar()[1]
        return {
            "hour_of_day": float(h),
            "day_of_week": float(d),
            "week_of_year": float(w),
            "month": float(dt.month),
            "is_weekend": float(d >= 5),
            "is_business_hour": float(9 <= h <= 17 and d < 5),
            "sin_hour": math.sin(2 * math.pi * h / 24),
            "cos_hour": math.cos(2 * math.pi * h / 24),
            "sin_day": math.sin(2 * math.pi * d / 7),
            "cos_day": math.cos(2 * math.pi * d / 7),
            "sin_week": math.sin(2 * math.pi * w / 52),
            "cos_week": math.cos(2 * math.pi * w / 52),
        }

    def build_all_features(
        self,
        series: np.ndarray,
        dt: datetime,
        anomaly_score: float = 0.0,
        drift_score: float = 0.0,
        uncertainty_width: float = 0.0,
    ) -> Dict[str, float]:
        """
        Build the complete feature vector for a single inference point.
        Combines lag, rolling, seasonality, and anomaly features inline
        (without hitting Feast for ultra-low latency paths).
        """
        features: Dict[str, float] = {}
        features.update(self.build_lag_features(series))
        features.update(self.build_rolling_stats(series))
        features.update(self.build_seasonality_features(dt))
        features.update({
            "anomaly_score_latest": anomaly_score,
            "drift_score_latest": drift_score,
            "uncertainty_width_latest": uncertainty_width,
        })
        return features
