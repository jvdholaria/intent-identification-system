"""
data_ingestion.py — Multi-source data loading, temporal alignment,
resampling, windowing, and feature extraction from asynchronous streams.

Design principles
-----------------
* Each data source is parsed independently and tagged with its subsystem.
* Sources are aligned to a common time grid via resampling + interpolation.
* Missing timestamps and irregular cadences are handled explicitly.
* The final output is either a flat DataFrame (static mode) or a 3-D
  numpy array (samples × time-steps × features) for sequence models.
"""

from __future__ import annotations

import logging
import warnings
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from pandas import DataFrame, DatetimeIndex

from .config import DataSourceConfig, FrameworkConfig, TemporalConfig

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _coerce_timestamp(df: DataFrame, col: str) -> DataFrame:
    """Coerce a timestamp column to UTC-aware DatetimeIndex."""
    df = df.copy()
    df[col] = pd.to_datetime(df[col], infer_datetime_format=True, utc=True)
    df = df.set_index(col).sort_index()
    return df


def _resample_source(
    df: DataFrame,
    cfg: TemporalConfig,
    source_cfg: DataSourceConfig,
) -> DataFrame:
    """
    Resample a single source to the common grid frequency.

    Numeric columns → aggregated (mean/max/…)
    Categorical columns → last observed value within each period
    """
    num_cols  = [c for c in source_cfg.numerical_cols   if c in df.columns]
    cat_cols  = [c for c in source_cfg.categorical_cols if c in df.columns]

    agg_dict: Dict[str, str] = {}
    for c in num_cols:
        agg_dict[c] = cfg.aggregation_method
    for c in cat_cols:
        agg_dict[c] = "last"

    if not agg_dict:
        return df

    resampled = df[list(agg_dict)].resample(cfg.resample_freq).agg(agg_dict)
    return resampled


def _interpolate(df: DataFrame, cfg: TemporalConfig) -> DataFrame:
    """Fill gaps in resampled data, honouring max_gap_fill_periods."""
    if cfg.interpolation_method == "none":
        return df

    # Mark consecutive NaN runs > max_gap_fill_periods so they stay NaN
    numeric_cols = df.select_dtypes(include="number").columns.tolist()
    cat_cols     = df.select_dtypes(exclude="number").columns.tolist()

    if numeric_cols:
        df[numeric_cols] = (
            df[numeric_cols]
            .interpolate(
                method=cfg.interpolation_method,
                limit=cfg.max_gap_fill_periods,
                limit_direction="forward",
            )
        )
    if cat_cols:
        df[cat_cols] = df[cat_cols].ffill(limit=cfg.max_gap_fill_periods)

    return df


# ---------------------------------------------------------------------------
# Core ingestion class
# ---------------------------------------------------------------------------

class DataIngestionPipeline:
    """
    Load, align, and merge heterogeneous data sources onto a single timeline.

    Parameters
    ----------
    config : FrameworkConfig
        Master pipeline configuration.

    Usage
    -----
    >>> pipeline = DataIngestionPipeline(cfg)
    >>> merged_df = pipeline.run(source_dfs)   # dict[source_name → DataFrame]
    """

    def __init__(self, config: FrameworkConfig) -> None:
        self.cfg      = config
        self.tcfg     = config.temporal
        self._sources: Dict[str, DataFrame] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(
        self,
        source_dfs: Optional[Dict[str, DataFrame]] = None,
    ) -> DataFrame:
        """
        Full ingestion pipeline.

        Parameters
        ----------
        source_dfs : dict, optional
            Pre-loaded DataFrames keyed by source name. When None, data is
            read from the paths defined in config.data_sources.

        Returns
        -------
        merged : DataFrame
            Single DataFrame on the common time grid, columns prefixed by
            subsystem tag for disambiguation.
        """
        raw = self._load_sources(source_dfs)
        resampled = self._resample_all(raw)
        merged    = self._merge_sources(resampled)
        merged    = _interpolate(merged, self.tcfg)
        merged    = self._add_time_features(merged)
        logger.info(
            "Ingestion complete: shape=%s, date_range=[%s, %s]",
            merged.shape,
            merged.index.min(),
            merged.index.max(),
        )
        return merged

    def build_sequences(
        self,
        df: DataFrame,
        targets: List[str],
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, List[str]]:
        """
        Slide a fixed-length window over the time axis to produce
        (X_seq, X_static, y) arrays for sequence models.

        X_seq    : (N, window_size, n_temporal_features)
        X_static : (N, n_static_features)   — time-invariant columns
        y        : (N, n_targets)
        timestamps : (N,) prediction timestamps

        'Static' features are those not in a time-aware subsystem
        (e.g., metadata, one-hot encoded categoricals that don't change).
        """
        W = self.tcfg.window_size
        H = self.tcfg.horizon
        S = self.tcfg.stride

        feature_cols = [c for c in df.columns if c not in targets]
        target_cols  = [c for c in df.columns if c in targets]

        if not target_cols:
            raise ValueError(f"None of {targets} found in dataframe columns.")

        values   = df[feature_cols].values.astype(np.float32)
        tgt_vals = df[target_cols].values.astype(np.float32)
        ts       = df.index

        X_list, y_list, ts_list = [], [], []
        for i in range(0, len(df) - W - H + 1, S):
            X_list.append(values[i : i + W])              # window of features
            y_list.append(tgt_vals[i + W + H - 1])        # target at horizon
            ts_list.append(ts[i + W + H - 1])

        X_seq  = np.stack(X_list, axis=0)                # (N, W, F)
        y      = np.stack(y_list, axis=0)                # (N, T)
        timestamps = np.array(ts_list)

        logger.info(
            "Sequences built: X_seq=%s  y=%s", X_seq.shape, y.shape
        )
        return X_seq, y, timestamps, feature_cols

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load_sources(
        self,
        source_dfs: Optional[Dict[str, DataFrame]],
    ) -> Dict[str, DataFrame]:
        """Load each source from file or from the supplied dict."""
        result: Dict[str, DataFrame] = {}
        for src_cfg in self.cfg.data_sources:
            if source_dfs and src_cfg.name in source_dfs:
                df = source_dfs[src_cfg.name].copy()
            elif src_cfg.path:
                df = self._read_file(Path(src_cfg.path))
            else:
                logger.warning("Source '%s' has no data; skipping.", src_cfg.name)
                continue

            df = _coerce_timestamp(df, src_cfg.timestamp_col)
            result[src_cfg.name] = df
            logger.debug("Loaded '%s': %d rows", src_cfg.name, len(df))
        return result

    @staticmethod
    def _read_file(path: Path) -> DataFrame:
        ext = path.suffix.lower()
        readers = {
            ".csv":     pd.read_csv,
            ".parquet": pd.read_parquet,
            ".feather": pd.read_feather,
            ".json":    pd.read_json,
        }
        if ext not in readers:
            raise ValueError(f"Unsupported file extension: {ext}")
        return readers[ext](path)

    def _resample_all(
        self,
        raw: Dict[str, DataFrame],
    ) -> Dict[str, DataFrame]:
        out: Dict[str, DataFrame] = {}
        for src_cfg in self.cfg.data_sources:
            if src_cfg.name not in raw:
                continue
            df = _resample_source(raw[src_cfg.name], self.tcfg, src_cfg)
            # Prefix columns with subsystem tag to avoid collisions
            prefix = src_cfg.subsystem
            df.columns = [f"{prefix}__{c}" for c in df.columns]
            out[src_cfg.name] = df
        return out

    def _merge_sources(self, resampled: Dict[str, DataFrame]) -> DataFrame:
        """
        Outer-join all sources on the common time grid, then trim to the
        intersection period that has coverage from all sources.
        """
        frames = list(resampled.values())
        if not frames:
            raise RuntimeError("No data sources were loaded.")
        if len(frames) == 1:
            return frames[0]

        merged = frames[0]
        for df in frames[1:]:
            merged = merged.join(df, how="outer")

        # Trim to the overlap window (at least one non-NaN per row)
        row_coverage = merged.notna().mean(axis=1)
        merged = merged[row_coverage > 0]
        return merged

    def _add_time_features(self, df: DataFrame) -> DataFrame:
        """Cyclically-encoded calendar features — no data leakage risk."""
        if not self.cfg.preprocessing.add_time_features:
            return df
        idx = df.index
        df["time__hour_sin"]    = np.sin(2 * np.pi * idx.hour / 24)
        df["time__hour_cos"]    = np.cos(2 * np.pi * idx.hour / 24)
        df["time__dow_sin"]     = np.sin(2 * np.pi * idx.dayofweek / 7)
        df["time__dow_cos"]     = np.cos(2 * np.pi * idx.dayofweek / 7)
        df["time__month_sin"]   = np.sin(2 * np.pi * idx.month / 12)
        df["time__month_cos"]   = np.cos(2 * np.pi * idx.month / 12)
        df["time__is_weekend"]  = (idx.dayofweek >= 5).astype(np.float32)
        return df


# ---------------------------------------------------------------------------
# Temporal train/val/test split — no data leakage
# ---------------------------------------------------------------------------

class TemporalSplitter:
    """
    Produces strictly chronological train / val / test splits and optional
    cross-validation folds (expanding or sliding window).

    No shuffling is performed — shuffling would constitute data leakage for
    time-series problems.
    """

    def __init__(self, config: FrameworkConfig) -> None:
        self.cfg = config.training
        self.tcfg = config.temporal

    def split(
        self,
        df: DataFrame,
    ) -> Tuple[DataFrame, DataFrame, DataFrame]:
        """Return (train, val, test) dataframes in chronological order."""
        n = len(df)
        test_n = int(n * self.cfg.test_fraction)
        val_n  = int(n * self.cfg.val_fraction)
        train_n = n - val_n - test_n

        train = df.iloc[:train_n]
        val   = df.iloc[train_n : train_n + val_n]
        test  = df.iloc[train_n + val_n :]

        logger.info(
            "Temporal split — train=%d  val=%d  test=%d",
            len(train), len(val), len(test)
        )
        return train, val, test

    def cv_folds(
        self,
        df: DataFrame,
    ) -> List[Tuple[np.ndarray, np.ndarray]]:
        """
        Generate (train_idx, val_idx) pairs for temporal cross-validation.

        Expanding window: training set grows with each fold.
        Sliding window  : fixed-size training window slides forward.
        """
        n      = len(df)
        folds  = self.cfg.n_cv_folds
        val_sz = n // (folds + 1)

        result = []
        for k in range(folds):
            val_end   = n - (folds - k - 1) * val_sz
            val_start = val_end - val_sz

            if self.cfg.cv_strategy == "expanding":
                train_start = 0
            else:  # sliding
                train_start = max(0, val_start - val_sz * folds)

            train_idx = np.arange(train_start, val_start)
            val_idx   = np.arange(val_start, val_end)
            result.append((train_idx, val_idx))

        return result
