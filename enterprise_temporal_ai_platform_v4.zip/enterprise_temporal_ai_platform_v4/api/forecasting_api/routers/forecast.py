"""
Enterprise Temporal AI Platform — Forecast Router
"""

from __future__ import annotations

import time
import uuid
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request, BackgroundTasks
from prometheus_client import Counter, Histogram

from shared.config.settings import settings
from shared.logging.logger import get_logger, log_execution
from shared.schemas.schemas import (
    ForecastRequest,
    ForecastResponse,
    QuantileForecast,
    ModelType,
)

log = get_logger("forecast.router")
router = APIRouter()

# ── Metrics ───────────────────────────────────────────────────────────────────
FORECAST_COUNTER = Counter(
    "forecast_endpoint_calls_total",
    "Forecast endpoint call count",
    ["tenant_id", "model"],
)
FORECAST_LATENCY = Histogram(
    "forecast_endpoint_latency_seconds",
    "Forecast endpoint latency in seconds",
    ["tenant_id", "model"],
)


# ── Dependency: Redis client from app state ───────────────────────────────────
async def get_redis(request: Request):
    return request.app.state.redis


# ── Forecast Engine (import from forecasting layer) ───────────────────────────
def _get_engine():
    """Lazy import to avoid circular deps; engine initialised once per worker."""
    from forecasting.inference.engine import ForecastEngine
    return ForecastEngine(settings=settings)


# ── Routes ────────────────────────────────────────────────────────────────────

@router.post("/forecast", response_model=ForecastResponse, summary="Run multi-step forecast")
@log_execution(log)
async def forecast(
    req: ForecastRequest,
    background_tasks: BackgroundTasks,
    redis=Depends(get_redis),
) -> ForecastResponse:
    """
    Run multi-step probabilistic and quantile forecasting.

    - Supports all primary/secondary/fallback model types.
    - Returns point forecast, confidence bounds, uncertainty and P10/P50/P90 quantiles.
    - Results cached in Redis under tenant namespace.
    """
    request_id = req.request_id or str(uuid.uuid4())
    cache_key = (
        f"{settings.TENANT_NAMESPACE_PREFIX}:{req.tenant_id}"
        f":forecast:{hash(tuple(req.series[-168:]))}"
        f":h{req.horizon}:{req.model.value}"
    )

    # ── Cache check ───────────────────────────────────────────────────────────
    cached = await redis.get(cache_key)
    if cached:
        log.info("forecast.cache_hit", tenant=req.tenant_id, cache_key=cache_key)
        import json
        data = json.loads(cached)
        return ForecastResponse(**data, request_id=request_id)

    FORECAST_COUNTER.labels(tenant_id=req.tenant_id, model=req.model.value).inc()

    # ── Run forecast ──────────────────────────────────────────────────────────
    t0 = time.perf_counter()
    try:
        engine = _get_engine()
        result = await engine.run(
            series=req.series,
            horizon=req.horizon,
            model=req.model,
            quantiles=req.quantiles,
            tenant_id=req.tenant_id,
        )
    except Exception as exc:
        log.error("forecast.engine_error", exc=str(exc), tenant=req.tenant_id)
        raise HTTPException(status_code=500, detail=f"Forecast engine error: {exc}")

    elapsed = time.perf_counter() - t0
    FORECAST_LATENCY.labels(tenant_id=req.tenant_id, model=req.model.value).observe(elapsed)

    response = ForecastResponse(
        request_id=request_id,
        tenant_id=req.tenant_id,
        forecast=result["forecast"],
        lower_bound=result["lower_bound"],
        upper_bound=result["upper_bound"],
        uncertainty=result["uncertainty"],
        quantiles=QuantileForecast(
            p10=result["p10"],
            p50=result["p50"],
            p90=result["p90"],
        ),
        model_used=req.model,
        horizon=req.horizon,
        window_size=settings.FORECAST_WINDOW_SIZE,
    )

    # ── Background cache write ────────────────────────────────────────────────
    background_tasks.add_task(
        _cache_response, redis, cache_key, response, settings.REDIS_BUFFER_TTL
    )

    log.info(
        "forecast.complete",
        tenant=req.tenant_id,
        model=req.model.value,
        horizon=req.horizon,
        elapsed_ms=round(elapsed * 1000, 2),
    )
    return response


@router.post("/forecast/batch", summary="Batch forecast for multiple series")
async def forecast_batch(
    requests: list[ForecastRequest],
    redis=Depends(get_redis),
) -> list[ForecastResponse]:
    """
    Run forecasting on multiple series concurrently.
    """
    import asyncio
    tasks = [forecast.__wrapped__(req, None, redis) for req in requests]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    responses = []
    for i, r in enumerate(results):
        if isinstance(r, Exception):
            log.error("batch_forecast.item_error", index=i, exc=str(r))
            responses.append(None)
        else:
            responses.append(r)
    return [r for r in responses if r is not None]


@router.get("/forecast/models", summary="List available forecasting models")
async def list_models():
    """Return all supported model types and the current ensemble weights."""
    return {
        "models": [m.value for m in ModelType],
        "primary": ["patchtst", "tft", "timesnet"],
        "secondary": ["nbeats", "transformer", "informer"],
        "fallback": ["gru", "lstm"],
        "ensemble_weights": {
            "patchtst": settings.ENSEMBLE_WEIGHT_PATCHTST,
            "tft": settings.ENSEMBLE_WEIGHT_TFT,
            "timesnet": settings.ENSEMBLE_WEIGHT_TIMESNET,
            "nbeats": settings.ENSEMBLE_WEIGHT_NBEATS,
            "gru": settings.ENSEMBLE_WEIGHT_GRU,
        },
    }


@router.get("/forecast/config", summary="Return temporal configuration")
async def forecast_config():
    """Return the active temporal forecasting configuration."""
    return {
        "resample_freq": settings.FORECAST_RESAMPLE_FREQ,
        "window_size": settings.FORECAST_WINDOW_SIZE,
        "horizon": settings.FORECAST_HORIZON,
        "max_gap_fill_periods": settings.FORECAST_MAX_GAP_FILL,
        "quantiles": settings.FORECAST_QUANTILES,
        "strategy": "seq2seq",
        "multi_step": True,
    }


# ── Helpers ───────────────────────────────────────────────────────────────────

async def _cache_response(redis, key: str, response: ForecastResponse, ttl: int):
    try:
        await redis.setex(key, ttl, response.model_dump_json())
    except Exception as exc:
        log.warning("forecast.cache_write_failed", exc=str(exc))
