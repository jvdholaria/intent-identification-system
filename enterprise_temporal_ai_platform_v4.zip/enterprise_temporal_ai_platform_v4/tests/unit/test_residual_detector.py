"""
Unit tests — Residual Anomaly Detector
"""

import pytest
import numpy as np
from anomaly.residual.detector import ResidualDetector


@pytest.fixture
def detector():
    return ResidualDetector(threshold_sigma=3.0, rolling_window=24)


def make_series(n=100, noise=0.1, spike_idx=None, spike_mag=10.0):
    series = np.sin(np.linspace(0, 4 * np.pi, n)) + np.random.randn(n) * noise
    if spike_idx is not None:
        series[spike_idx] += spike_mag
    return series.tolist()


class TestResidualDetector:
    def test_score_returns_correct_length(self, detector):
        actual = make_series(50)
        predicted = make_series(50)
        scores = detector.score(actual, predicted)
        assert len(scores) == 50

    def test_scores_are_floats(self, detector):
        actual = make_series(30)
        predicted = make_series(30)
        scores = detector.score(actual, predicted)
        assert all(isinstance(s, float) for s in scores)

    def test_large_spike_produces_high_score(self, detector):
        actual = make_series(100, spike_idx=80, spike_mag=50.0)
        predicted = make_series(100)
        scores = detector.score(actual, predicted)
        # The spike at index 80 should produce the highest score
        assert max(scores) == max(scores[75:85])

    def test_zero_residuals_produce_low_scores(self, detector):
        series = make_series(50, noise=0.0)
        scores = detector.score(series, series)
        # Perfect prediction — all residuals are zero
        assert all(s <= 0.01 for s in scores)

    def test_detect_returns_flags_and_scores(self, detector):
        actual = make_series(60)
        predicted = make_series(60)
        flags, scores = detector.detect(actual, predicted)
        assert len(flags) == 60
        assert len(scores) == 60
        assert all(isinstance(f, bool) for f in flags)

    def test_dynamic_threshold_positive(self, detector):
        actual = make_series(100)
        predicted = make_series(100)
        threshold = detector.dynamic_threshold(actual, predicted)
        assert threshold > 0

    def test_seasonal_residual_score(self, detector):
        actual = make_series(100)
        predicted = make_series(100)
        scores = detector.seasonal_residual_score(actual, predicted, period=24)
        assert len(scores) == 100


class TestResidualDetectorEdgeCases:
    def test_single_point(self, detector):
        scores = detector.score([1.0], [0.9])
        assert len(scores) == 1

    def test_identical_series(self, detector):
        series = list(range(50))
        scores = detector.score(series, series)
        assert all(s <= 0.01 for s in scores)

    def test_constant_series(self, detector):
        actual = [5.0] * 50
        predicted = [4.0] * 50
        scores = detector.score(actual, predicted)
        assert len(scores) == 50
