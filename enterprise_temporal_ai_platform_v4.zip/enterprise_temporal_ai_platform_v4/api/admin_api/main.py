"""
Enterprise Temporal AI Platform — Admin API

Provides:
- Tenant management (create / list / delete)
- Model registry management (list / promote / rollback)
- Platform health dashboard
- Drift and anomaly monitoring overview
- Manual retraining triggers
"""

from __future__ import annotations

import uuid
from contextlib import asynccontextmanager
from typing import Dict, List, Optional

import redis.asyncio as aioredis
import uvicorn
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from shared.config.settings import settings
from shared.logging.logger import configure_logging, get_logger

configure_logging("admin-api", settings.LOG_LEVEL, settings.is_production)
log = get_logger("admin")


# ── Pydantic models ───────────────────────────────────────────────────────────

class TenantCreate(BaseModel):
    tenant_id: str
    name: str
    description: Optional[str] = None
    config: Optional[Dict] = None


class ModelPromoteRequest(BaseModel):
    model_name: str
    version: str
    target_stage: str   # "Staging" | "Production"


class ManualRetrainRequest(BaseModel):
    tenant_id: str
    model_type: str = "patchtst"
    reason: str = "manual"
    dataset_path: Optional[str] = None


# ── Lifespan ──────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.redis = aioredis.from_url(settings.REDIS_URL, decode_responses=True)
    await app.state.redis.ping()
    yield
    await app.state.redis.aclose()


# ── App factory ───────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    app = FastAPI(
        title="Temporal AI — Admin API",
        description="Platform administration, tenant management and MLOps operations.",
        version="1.0.0",
        lifespan=lifespan,
    )
    app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

    @app.exception_handler(Exception)
    async def handler(request: Request, exc: Exception):
        return JSONResponse(status_code=500, content={"status": "error", "message": str(exc)})

    async def get_redis(request: Request):
        return request.app.state.redis

    # ── Health ─────────────────────────────────────────────────────────────────
    @app.get("/health")
    async def health():
        return {"status": "healthy", "service": "admin-api", "version": "1.0.0"}

    # ─────────────────────────────────────────────────────────────────────────
    # TENANT MANAGEMENT
    # ─────────────────────────────────────────────────────────────────────────

    @app.post("/v1/tenants", tags=["Tenants"], summary="Create a new tenant")
    async def create_tenant(body: TenantCreate, redis=Depends(get_redis)):
        tenant_key = f"temporal:tenants:{body.tenant_id}"
        exists = await redis.exists(tenant_key)
        if exists:
            raise HTTPException(status_code=409, detail=f"Tenant '{body.tenant_id}' already exists")

        import json
        tenant_data = {
            "tenant_id": body.tenant_id,
            "name": body.name,
            "description": body.description or "",
            "config": json.dumps(body.config or {}),
        }
        await redis.hset(tenant_key, mapping=tenant_data)
        await redis.sadd("temporal:tenants:active", body.tenant_id)
        log.info("tenant.created", tenant_id=body.tenant_id)
        return {"status": "created", "tenant_id": body.tenant_id}

    @app.get("/v1/tenants", tags=["Tenants"], summary="List all tenants")
    async def list_tenants(redis=Depends(get_redis)):
        tenant_ids = await redis.smembers("temporal:tenants:active")
        tenants = []
        for tid in tenant_ids:
            data = await redis.hgetall(f"temporal:tenants:{tid}")
            tenants.append(data)
        return {"tenants": tenants, "count": len(tenants)}

    @app.delete("/v1/tenants/{tenant_id}", tags=["Tenants"], summary="Delete a tenant")
    async def delete_tenant(tenant_id: str, redis=Depends(get_redis)):
        await redis.delete(f"temporal:tenants:{tenant_id}")
        await redis.srem("temporal:tenants:active", tenant_id)
        log.info("tenant.deleted", tenant_id=tenant_id)
        return {"status": "deleted", "tenant_id": tenant_id}

    @app.get("/v1/tenants/{tenant_id}/stats", tags=["Tenants"])
    async def tenant_stats(tenant_id: str, redis=Depends(get_redis)):
        """Return per-tenant AI health metrics."""
        import asyncio

        async def safe_get(key):
            try:
                return await redis.get(key)
            except Exception:
                return None

        prefix = f"temporal:tenant:{tenant_id}"
        drift_raw, anomaly_rate_raw = await asyncio.gather(
            safe_get(f"{prefix}:drift:latest"),
            safe_get(f"{prefix}:anomaly_rate"),
        )
        alert_count = await redis.llen(f"{prefix}:alerts")
        return {
            "tenant_id": tenant_id,
            "drift_score": float(drift_raw) if drift_raw else None,
            "anomaly_rate": float(anomaly_rate_raw) if anomaly_rate_raw else None,
            "open_alerts": alert_count,
        }

    # ─────────────────────────────────────────────────────────────────────────
    # MODEL REGISTRY
    # ─────────────────────────────────────────────────────────────────────────

    @app.get("/v1/models", tags=["Models"], summary="List all registered models")
    async def list_models():
        try:
            from mlops.registry.model_registry import get_registry
            registry = get_registry()
            return {"models": registry.list_models()}
        except Exception as exc:
            raise HTTPException(status_code=503, detail=f"MLflow unavailable: {exc}")

    @app.post("/v1/models/promote", tags=["Models"], summary="Promote model to a stage")
    async def promote_model(body: ModelPromoteRequest):
        from mlops.registry.model_registry import get_registry
        registry = get_registry()
        if body.target_stage == "Production":
            registry.promote_to_production(body.model_name, body.version)
        elif body.target_stage == "Staging":
            registry.promote_to_staging(body.model_name, body.version)
        else:
            raise HTTPException(status_code=400, detail=f"Unknown stage: {body.target_stage}")
        return {"status": "promoted", "model": body.model_name, "version": body.version, "stage": body.target_stage}

    @app.post("/v1/models/{model_name}/rollback", tags=["Models"], summary="Rollback to previous production version")
    async def rollback_model(model_name: str):
        from mlops.registry.model_registry import get_registry
        registry = get_registry()
        version = registry.rollback(model_name)
        if version is None:
            raise HTTPException(status_code=404, detail="No archived version to rollback to")
        return {"status": "rolled_back", "model": model_name, "restored_version": version}

    # ─────────────────────────────────────────────────────────────────────────
    # RETRAINING
    # ─────────────────────────────────────────────────────────────────────────

    @app.post("/v1/retrain", tags=["Retraining"], summary="Manually trigger retraining")
    async def manual_retrain(body: ManualRetrainRequest, redis=Depends(get_redis)):
        import json
        job = {
            "tenant_id": body.tenant_id,
            "model_type": body.model_type,
            "reason": body.reason,
            "dataset_path": body.dataset_path,
            "triggered_at": str(uuid.uuid4()),
        }
        queue_key = f"temporal:tenant:{body.tenant_id}:retrain_queue"
        await redis.lpush(queue_key, json.dumps(job))
        log.info("retrain.manual_trigger", **job)
        return {"status": "queued", "job": job}

    # ─────────────────────────────────────────────────────────────────────────
    # PLATFORM OVERVIEW
    # ─────────────────────────────────────────────────────────────────────────

    @app.get("/v1/platform/overview", tags=["Platform"])
    async def platform_overview(redis=Depends(get_redis)):
        """High-level platform health snapshot."""
        tenants = await redis.smembers("temporal:tenants:active")
        return {
            "platform": "Enterprise Temporal AI",
            "version": "1.0.0",
            "active_tenants": len(tenants),
            "services": {
                "forecast_service": settings.FORECAST_SERVICE_URL,
                "anomaly_service": settings.ANOMALY_SERVICE_URL,
                "drift_service": settings.DRIFT_SERVICE_URL,
                "mlflow": settings.MLFLOW_TRACKING_URI,
            },
            "config": {
                "forecast_horizon": settings.FORECAST_HORIZON,
                "window_size": settings.FORECAST_WINDOW_SIZE,
                "ensemble_weights": {
                    "patchtst": settings.ENSEMBLE_WEIGHT_PATCHTST,
                    "tft": settings.ENSEMBLE_WEIGHT_TFT,
                    "timesnet": settings.ENSEMBLE_WEIGHT_TIMESNET,
                    "nbeats": settings.ENSEMBLE_WEIGHT_NBEATS,
                    "gru": settings.ENSEMBLE_WEIGHT_GRU,
                },
            },
        }

    @app.get("/v1/platform/queues", tags=["Platform"])
    async def queue_stats(redis=Depends(get_redis)):
        """Return inference queue depths for all active tenants."""
        tenants = await redis.smembers("temporal:tenants:active") or {"default"}
        stats = {}
        for tid in tenants:
            depth = await redis.llen(f"temporal:tenant:{tid}:retrain_queue")
            buf = await redis.llen(f"temporal:tenant:{tid}:buffer:default")
            stats[tid] = {"retrain_queue": depth, "buffer_depth": buf}
        return {"queue_stats": stats}

    return app


app = create_app()

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8005, reload=False)
