"""
Unit tests — Drift Detector
"""

import pytest
import numpy as np

from anomaly.drift.drift_detector import (
    DriftDetector,
    compute_psi,
    compute_ks,
    compute_wasserstein,
    compute_concept_drift,
)
from shared.schemas.schemas import DriftType


@pytest.fixture
def detector():
    return DriftDetector()


def normal_dist(n=500, mu=0.0, sigma=1.0):
    return np.random.normal(mu, sigma, n)


class TestPSI:
    def test_same_distribution_low_psi(self):
        np.random.seed(42)
        a = normal_dist(1000)
        b = normal_dist(1000)
        psi = compute_psi(a, b)
        assert psi < 0.1, f"Expected PSI < 0.1 for same distribution, got {psi}"

    def test_shifted_distribution_high_psi(self):
        np.random.seed(42)
        a = normal_dist(1000, mu=0.0)
        b = normal_dist(1000, mu=5.0)
        psi = compute_psi(a, b)
        assert psi >= 0.2, f"Expected PSI >= 0.2 for shifted distribution, got {psi}"

    def test_psi_non_negative(self):
        np.random.seed(42)
        a = normal_dist(500)
        b = normal_dist(500, mu=1.0)
        psi = compute_psi(a, b)
        assert psi >= 0.0


class TestKSTest:
    def test_same_dist_high_pvalue(self):
        np.random.seed(42)
        a = normal_dist(500)
        b = normal_dist(500)
        stat, p_val = compute_ks(a, b)
        assert p_val > 0.05

    def test_different_dist_low_pvalue(self):
        np.random.seed(42)
        a = normal_dist(500, mu=0.0, sigma=1.0)
        b = normal_dist(500, mu=10.0, sigma=1.0)
        stat, p_val = compute_ks(a, b)
        assert p_val < 0.05


class TestWasserstein:
    def test_same_dist_small_distance(self):
        np.random.seed(42)
        a = normal_dist(500)
        b = normal_dist(500)
        d = compute_wasserstein(a, b)
        assert d < 0.5

    def test_distant_dists_larger_distance(self):
        np.random.seed(42)
        a = normal_dist(500, mu=0.0)
        b = normal_dist(500, mu=20.0)
        d = compute_wasserstein(a, b)
        assert d > 10.0


class TestDriftDetector:
    def test_no_drift_detected_for_same_dist(self, detector):
        np.random.seed(42)
        a = normal_dist(500).tolist()
        b = normal_dist(500).tolist()
        results = detector.detect(a, b)
        any_detected = any(r.detected for r in results)
        assert not any_detected

    def test_drift_detected_for_shifted_dist(self, detector):
        np.random.seed(42)
        a = normal_dist(500, mu=0.0).tolist()
        b = normal_dist(500, mu=10.0).tolist()
        results = detector.detect(a, b)
        any_detected = any(r.detected for r in results)
        assert any_detected

    def test_results_include_all_drift_types(self, detector):
        np.random.seed(42)
        a = normal_dist(200).tolist()
        b = normal_dist(200).tolist()
        results = detector.detect(a, b, drift_types=list(DriftType))
        result_types = {r.drift_type for r in results}
        expected = {DriftType.data_drift, DriftType.feature_drift, DriftType.distribution_drift, DriftType.concept_drift}
        assert expected <= result_types

    def test_overall_score_between_0_and_1(self, detector):
        np.random.seed(42)
        a = normal_dist(500).tolist()
        b = normal_dist(500, mu=2.0).tolist()
        results = detector.detect(a, b)
        score = detector.overall_score(results)
        assert 0.0 <= score <= 1.0

    def test_recommendation_returned(self, detector):
        np.random.seed(42)
        a = normal_dist(500, mu=0.0).tolist()
        b = normal_dist(500, mu=10.0).tolist()
        results = detector.detect(a, b)
        score = detector.overall_score(results)
        rec = detector.recommendation(score, results)
        assert isinstance(rec, str)
        assert len(rec) > 10
