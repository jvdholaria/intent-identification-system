"""
Enterprise Temporal AI Platform — TimesNet Predictor

TimesNet: Temporal 2D-Variation Modelling for General Time Series Analysis
(Wu et al., 2023). Transforms 1D time series into 2D space to capture
inter-period and intra-period variations via 2D convolutions.
"""

from __future__ import annotations

from typing import Optional

import numpy as np
import torch
import torch.nn as nn
import torch.fft

from shared.config.settings import Settings
from shared.logging.logger import get_logger

log = get_logger("models.timesnet")


def fft_period(x: torch.Tensor, top_k: int = 5):
    """
    Identify dominant periods in the series via FFT.
    Returns (period_list, amplitudes).
    """
    xf = torch.fft.rfft(x, dim=1)
    freq_list = abs(xf).mean(dim=0).mean(dim=-1)
    freq_list[0] = 0  # remove DC
    _, top_list = torch.topk(freq_list, top_k)
    top_list = top_list.detach().cpu().numpy()
    period_list = x.shape[1] // top_list
    return period_list, abs(xf).mean(dim=-1)[:, top_list]


class Inception2DBlock(nn.Module):
    """
    2D inception-style convolutional block for capturing multi-scale patterns
    in the reshaped (period × frequency) representation.
    """

    def __init__(self, in_channels: int, out_channels: int):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=1)
        self.conv3 = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)
        self.conv5 = nn.Conv2d(in_channels, out_channels, kernel_size=5, padding=2)
        self.pool = nn.MaxPool2d(kernel_size=3, stride=1, padding=1)
        self.pool_proj = nn.Conv2d(in_channels, out_channels, kernel_size=1)
        self.bn = nn.BatchNorm2d(out_channels * 4)
        self.relu = nn.ReLU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = torch.cat([
            self.conv1(x),
            self.conv3(x),
            self.conv5(x),
            self.pool_proj(self.pool(x)),
        ], dim=1)
        return self.relu(self.bn(out))


class TimesBlock(nn.Module):
    """
    Core block: reshape 1D → 2D, apply 2D convolutions, reshape back.
    """

    def __init__(
        self,
        seq_len: int,
        pred_len: int,
        d_model: int,
        top_k: int = 5,
    ):
        super().__init__()
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.top_k = top_k
        total_len = seq_len + pred_len
        self.conv = nn.Sequential(
            Inception2DBlock(d_model, d_model // 4),
            nn.Conv2d(d_model, d_model, kernel_size=1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, N = x.shape
        period_list, period_weight = fft_period(x, self.top_k)

        res = []
        for period in period_list:
            if period <= 0 or period > T:
                period = T
            # Pad to make divisible
            pad_len = (period - T % period) % period
            if pad_len > 0:
                out = torch.cat([x, x[:, :pad_len, :]], dim=1)
            else:
                out = x

            # Reshape to 2D: (B, N, T//period, period)
            steps = out.shape[1] // period
            out = out.reshape(B, steps, period, N).permute(0, 3, 1, 2)  # (B, N, steps, period)
            out = self.conv(out)   # (B, N, steps, period)
            out = out.permute(0, 2, 3, 1).reshape(B, -1, N)[:, :T, :]  # (B, T, N)
            res.append(out)

        # Weighted sum over periods
        res = torch.stack(res, dim=-1)                           # (B, T, N, top_k)
        period_weight = torch.softmax(
            period_weight[:, :T, :].permute(0, 2, 1),  # (B, top_k, T)
            dim=1,
        ).permute(0, 2, 1).unsqueeze(2)                           # (B, T, 1, top_k)
        res = (res * period_weight).sum(dim=-1)                   # (B, T, N)
        return res + x   # residual connection


class TimesNetModel(nn.Module):
    """
    TimesNet: transforms time series into 2D space for multi-scale
    pattern extraction via 2D convolutions.
    """

    def __init__(
        self,
        seq_len: int = 168,
        pred_len: int = 120,
        d_model: int = 64,
        e_layers: int = 2,
        top_k: int = 5,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.d_model = d_model

        self.enc_embedding = nn.Linear(1, d_model)
        self.encoder = nn.ModuleList([
            TimesBlock(seq_len, pred_len, d_model, top_k)
            for _ in range(e_layers)
        ])
        self.layer_norm = nn.ModuleList([nn.LayerNorm(d_model) for _ in range(e_layers)])
        self.dropout = nn.Dropout(dropout)
        self.projection = nn.Linear(seq_len * d_model, pred_len)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, seq_len, 1)
        enc = self.enc_embedding(x)   # (B, seq_len, d_model)
        for block, norm in zip(self.encoder, self.layer_norm):
            enc = norm(block(enc))
        enc = self.dropout(enc)
        # Flatten and project
        out = enc.reshape(enc.size(0), -1)   # (B, seq_len * d_model)
        return self.projection(out)           # (B, pred_len)


class TimesNetPredictor:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._model: Optional[TimesNetModel] = None

    def _load(self):
        if self._model is not None:
            return
        self._model = TimesNetModel(
            seq_len=self.settings.FORECAST_WINDOW_SIZE,
            pred_len=self.settings.FORECAST_HORIZON,
        ).to(self.device)
        self._model.eval()
        log.info("timesnet.loaded", device=str(self.device))

    def predict(self, x: np.ndarray, horizon: int) -> np.ndarray:
        self._load()
        with torch.no_grad():
            arr = np.asarray(x, dtype=np.float32).flatten()
            tensor = torch.tensor(arr).unsqueeze(0).unsqueeze(-1).to(self.device)  # (1, seq_len, 1)
            out = self._model(tensor)   # (1, pred_len)
            result = out.squeeze(0).cpu().numpy()
            if len(result) >= horizon:
                return result[:horizon]
            return np.pad(result, (0, horizon - len(result)), mode="edge")
