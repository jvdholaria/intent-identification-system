"""
anomaly/detector.py — Multi-algorithm anomaly detection for the ML framework.

Architecture overview
---------------------

Five complementary detectors are available and can be combined into an ensemble:

  ┌──────────────────────────────────────────────────────────────┐
  │  1. IsolationForestDetector  — tree partitioning score       │
  │     Best for: high-dimensional, non-Gaussian distributions   │
  │                                                              │
  │  2. LocalOutlierFactorDetector — density contrast score      │
  │     Best for: local anomalies that global methods miss       │
  │                                                              │
  │  3. StatisticalDetector — Z-score + IQR + CUSUM              │
  │     Best for: interpretable alerts on individual features    │
  │                                                              │
  │  4. AutoencoderDetector — reconstruction error (PyTorch)     │
  │     Best for: complex multi-feature interaction anomalies    │
  │                                                              │
  │  5. ResidualDetector — prediction error vs. threshold        │
  │     Best for: catching anomalies in model target variables   │
  └──────────────────────────────────────────────────────────────┘
                              │
                     EnsembleAnomalyDetector
                  (weighted rank aggregation of scores)
                              │
                      AnomalyResult
              (scores, binary labels, per-feature breakdown,
               severity levels, timestamps)

All detectors follow the same fit / score / detect API so they are
interchangeable and extensible — add a new detector by subclassing
BaseAnomalyDetector and registering it in DETECTOR_REGISTRY.

Fit on TRAINING data only — anomaly thresholds are calibrated using the
empirical contamination rate, so no future information leaks in.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, List, Literal, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.preprocessing import MinMaxScaler

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Result container
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class AnomalyResult:
    """
    Structured output from the anomaly detection pipeline.

    Attributes
    ----------
    scores : (N,) float array
        Ensemble anomaly score in [0, 1]. Higher = more anomalous.
    labels : (N,) int array
        Binary labels: 1 = anomaly, 0 = normal.
    severity : (N,) str array
        Human-readable severity: "normal" | "warning" | "critical".
    per_detector : dict[detector_name → (N,) score array]
        Raw scores from each individual detector.
    feature_contributions : DataFrame, optional
        Per-sample feature anomaly contributions (from StatisticalDetector).
        Shape: (N, n_features). Higher magnitude = more responsible.
    anomaly_indices : (K,) int array
        Row indices where label == 1.
    timestamps : (N,) array, optional
        Timestamps aligned with each prediction row.
    n_anomalies : int
        Total anomalies detected.
    contamination_rate : float
        Fraction of samples flagged as anomalies.
    """
    scores:                np.ndarray
    labels:                np.ndarray
    severity:              np.ndarray
    per_detector:          Dict[str, np.ndarray]
    feature_contributions: Optional[pd.DataFrame] = None
    anomaly_indices:       Optional[np.ndarray]   = None
    timestamps:            Optional[np.ndarray]   = None
    n_anomalies:           int                    = 0
    contamination_rate:    float                  = 0.0

    def to_dataframe(self) -> pd.DataFrame:
        """Return a flat DataFrame for easy downstream consumption."""
        df = pd.DataFrame({
            "anomaly_score":    self.scores,
            "is_anomaly":       self.labels,
            "severity":         self.severity,
        })
        for name, s in self.per_detector.items():
            df[f"score_{name}"] = s
        if self.timestamps is not None:
            df.insert(0, "timestamp", self.timestamps)
        if self.feature_contributions is not None:
            for col in self.feature_contributions.columns:
                df[f"contrib_{col}"] = self.feature_contributions[col].values
        return df

    def summary(self) -> str:
        lines = [
            "═" * 55,
            "  Anomaly Detection Summary",
            "═" * 55,
            f"  Total samples     : {len(self.scores)}",
            f"  Anomalies found   : {self.n_anomalies}",
            f"  Contamination     : {self.contamination_rate:.2%}",
            "",
            "  Severity breakdown:",
            f"    critical : {(self.severity == 'critical').sum()}",
            f"    warning  : {(self.severity == 'warning').sum()}",
            f"    normal   : {(self.severity == 'normal').sum()}",
            "",
            "  Per-detector scores (mean):",
        ]
        for name, s in self.per_detector.items():
            lines.append(f"    {name:<25s}: {s.mean():.4f}")
        lines.append("═" * 55)
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Base class
# ─────────────────────────────────────────────────────────────────────────────

class BaseAnomalyDetector(ABC):
    """
    Common interface for all anomaly detectors.

    Subclasses implement:
      fit(X)         → self
      score(X)       → (N,) float array in [0, 1], higher = more anomalous
    """

    def __init__(self, contamination: float = 0.05, random_state: int = 42):
        self.contamination  = contamination
        self.random_state   = random_state
        self._is_fit        = False
        self._score_scaler  = MinMaxScaler()

    @abstractmethod
    def fit(self, X: np.ndarray) -> "BaseAnomalyDetector":
        ...

    @abstractmethod
    def _raw_score(self, X: np.ndarray) -> np.ndarray:
        """Return raw (unscaled) anomaly scores — larger = more anomalous."""
        ...

    def score(self, X: np.ndarray) -> np.ndarray:
        """Return normalised scores in [0, 1]."""
        raw = self._raw_score(X)
        return self._score_scaler.transform(raw.reshape(-1, 1)).ravel().clip(0, 1)

    def _fit_scaler_on_training(self, X: np.ndarray) -> None:
        """Calibrate the [0,1] normalisation on training scores."""
        raw = self._raw_score(X)
        self._score_scaler.fit(raw.reshape(-1, 1))


# ─────────────────────────────────────────────────────────────────────────────
# 1. Isolation Forest
# ─────────────────────────────────────────────────────────────────────────────

class IsolationForestDetector(BaseAnomalyDetector):
    """
    Isolation Forest anomaly detector.

    How it works: randomly partitions features and measures how quickly a
    sample is isolated — anomalies are isolated faster (shorter path length).

    Strengths:
    - Scales well to high dimensions (O(n log n))
    - No assumption about data distribution
    - Handles correlated features well
    - Native support in scikit-learn, no extra deps

    When to prefer this: high-dimensional data (50+ features), mixed scales,
    moderate-to-large datasets (> 10 k samples).
    """

    def __init__(
        self,
        contamination: float = 0.05,
        n_estimators:  int   = 200,
        max_samples:   int   = 256,
        random_state:  int   = 42,
        n_jobs:        int   = -1,
    ):
        super().__init__(contamination, random_state)
        self._model = IsolationForest(
            n_estimators=n_estimators,
            max_samples=max_samples,
            contamination=contamination,
            random_state=random_state,
            n_jobs=n_jobs,
        )

    def fit(self, X: np.ndarray) -> "IsolationForestDetector":
        self._model.fit(X)
        self._fit_scaler_on_training(X)
        self._is_fit = True
        logger.debug("IsolationForest fit on %d samples.", len(X))
        return self

    def _raw_score(self, X: np.ndarray) -> np.ndarray:
        # decision_function returns negative anomaly score → negate so higher = worse
        return -self._model.decision_function(X)


# ─────────────────────────────────────────────────────────────────────────────
# 2. Local Outlier Factor
# ─────────────────────────────────────────────────────────────────────────────

class LocalOutlierFactorDetector(BaseAnomalyDetector):
    """
    Local Outlier Factor (LOF) detector.

    How it works: compares the local density of a sample to its k-nearest
    neighbours. Samples with much lower density than their neighbours
    receive a high LOF score.

    Strengths:
    - Detects LOCAL anomalies that global methods miss
      (e.g., a point normal globally but anomalous in its cluster)
    - No strong distributional assumptions
    - Naturally handles clusters of different densities

    Limitation: LOF in sklearn cannot score new data incrementally — we
    use novelty=True mode which requires the detector to be trained on
    normal data only (which our temporal train split provides naturally).

    When to prefer this: clustered data, when anomalies are relative to
    local neighbourhood (e.g., sensor drift within a subsystem).
    """

    def __init__(
        self,
        contamination: float = 0.05,
        n_neighbors:   int   = 20,
        metric:        str   = "minkowski",
        n_jobs:        int   = -1,
        random_state:  int   = 42,
    ):
        super().__init__(contamination, random_state)
        self._model = LocalOutlierFactor(
            n_neighbors=n_neighbors,
            contamination=contamination,
            metric=metric,
            novelty=True,   # required for transform/predict on new data
            n_jobs=n_jobs,
        )

    def fit(self, X: np.ndarray) -> "LocalOutlierFactorDetector":
        self._model.fit(X)
        self._fit_scaler_on_training(X)
        self._is_fit = True
        logger.debug("LOF fit on %d samples.", len(X))
        return self

    def _raw_score(self, X: np.ndarray) -> np.ndarray:
        return -self._model.decision_function(X)


# ─────────────────────────────────────────────────────────────────────────────
# 3. Statistical Detector (Z-score + IQR + CUSUM)
# ─────────────────────────────────────────────────────────────────────────────

class StatisticalDetector(BaseAnomalyDetector):
    """
    Interpretable statistical anomaly detector combining three signals:

    Z-score      — flags samples whose features deviate > z_threshold σ
                   from the training mean. Fast, human-readable.

    IQR fence    — flags samples outside [Q1 - k·IQR, Q3 + k·IQR].
                   Robust to outliers in training data.

    CUSUM        — cumulative sum of deviations from target (training mean).
                   Detects persistent subtle drifts that single-sample
                   tests miss. Particularly useful on time-ordered data.

    Strengths:
    - Fully interpretable: outputs per-feature contribution scores.
    - Zero extra dependencies.
    - Very fast at inference (purely vectorised numpy).
    - CUSUM detects gradual sensor drift that Isolation Forest misses.

    When to prefer this: when you need to explain to domain experts
    WHICH sensor/feature is anomalous and by how much.
    """

    def __init__(
        self,
        contamination:  float = 0.05,
        z_threshold:    float = 3.5,
        iqr_multiplier: float = 3.0,
        cusum_slack:    float = 0.5,   # CUSUM slack parameter (in σ units)
        cusum_h:        float = 5.0,   # CUSUM threshold (in σ units)
        random_state:   int   = 42,
    ):
        super().__init__(contamination, random_state)
        self.z_threshold    = z_threshold
        self.iqr_multiplier = iqr_multiplier
        self.cusum_slack    = cusum_slack
        self.cusum_h        = cusum_h

        # Fitted statistics (set in fit)
        self._mean:  Optional[np.ndarray] = None
        self._std:   Optional[np.ndarray] = None
        self._q1:    Optional[np.ndarray] = None
        self._q3:    Optional[np.ndarray] = None
        self._iqr:   Optional[np.ndarray] = None
        self._threshold: Optional[float]  = None

    def fit(self, X: np.ndarray) -> "StatisticalDetector":
        self._mean = np.nanmean(X, axis=0)
        self._std  = np.nanstd(X, axis=0) + 1e-8
        self._q1   = np.nanpercentile(X, 25, axis=0)
        self._q3   = np.nanpercentile(X, 75, axis=0)
        self._iqr  = self._q3 - self._q1 + 1e-8

        # Calibrate threshold from training scores
        train_scores = self._raw_score(X)
        self._threshold = np.percentile(train_scores, 100 * (1 - self.contamination))
        self._fit_scaler_on_training(X)
        self._is_fit = True
        logger.debug(
            "StatisticalDetector fit: threshold=%.3f  n_features=%d",
            self._threshold, X.shape[1]
        )
        return self

    def _raw_score(self, X: np.ndarray) -> np.ndarray:
        # ── Z-score component ─────────────────────────────────────────
        z       = np.abs((X - self._mean) / self._std)
        z_score = z.max(axis=1)   # worst feature per sample

        # ── IQR fence component ───────────────────────────────────────
        lo     = self._q1 - self.iqr_multiplier * self._iqr
        hi     = self._q3 + self.iqr_multiplier * self._iqr
        iqr_viol = np.maximum(0, lo - X) + np.maximum(0, X - hi)
        iqr_score = (iqr_viol / self._iqr).max(axis=1)

        # ── CUSUM component (one-sided, upper bound only) ──────────────
        # Sequential CUSUM over each sample in order of arrival.
        # Measures how much the deviation accumulates above the slack.
        slack    = self.cusum_slack * self._std
        diff     = (X - self._mean) - slack                  # (N, F)
        cusum    = np.maximum.accumulate(np.maximum(0, diff), axis=0)
        cusum_score = (cusum / (self.cusum_h * self._std)).max(axis=1)

        # ── Aggregate ─────────────────────────────────────────────────
        return (z_score + iqr_score + cusum_score) / 3.0

    def feature_contributions(self, X: np.ndarray) -> pd.DataFrame:
        """
        Return per-feature z-scores — shows WHICH features are anomalous.
        Shape: (N, n_features). Larger absolute value = more anomalous.
        """
        z = np.abs((X - self._mean) / self._std)
        return pd.DataFrame(z)


# ─────────────────────────────────────────────────────────────────────────────
# 4. Autoencoder Detector
# ─────────────────────────────────────────────────────────────────────────────

class AutoencoderDetector(BaseAnomalyDetector):
    """
    Reconstruction-error anomaly detector using a PyTorch autoencoder.

    How it works:
    - Train a bottleneck autoencoder on NORMAL data (training set).
    - At inference, compute per-sample reconstruction error (MSE).
    - Anomalies have high error because the model never learned to
      reconstruct their unusual patterns.

    Architecture:
      Encoder: [n_features → hidden → bottleneck]
      Decoder: [bottleneck → hidden → n_features]

    Strengths:
    - Learns complex multi-feature interaction patterns automatically.
    - Reconstruction per feature reveals which features drive the error.
    - Works well on correlated, high-dimensional data.

    When to prefer this: when features have rich non-linear correlations
    that statistical tests cannot capture (e.g., joint sensor relationships).

    Requires PyTorch. Falls back gracefully if not installed.
    """

    def __init__(
        self,
        contamination:  float    = 0.05,
        hidden_dims:    List[int] = None,
        bottleneck_dim: int       = 16,
        epochs:         int       = 50,
        batch_size:     int       = 256,
        lr:             float     = 1e-3,
        device:         str       = "auto",
        random_state:   int       = 42,
    ):
        super().__init__(contamination, random_state)
        self.hidden_dims    = hidden_dims or [64, 32]
        self.bottleneck_dim = bottleneck_dim
        self.epochs         = epochs
        self.batch_size     = batch_size
        self.lr             = lr
        self.device_str     = device
        self._model         = None
        self._threshold_val: Optional[float] = None

    def _get_device(self):
        try:
            import torch
            if self.device_str == "auto":
                return torch.device("cuda" if torch.cuda.is_available() else "cpu")
            return torch.device(self.device_str)
        except ImportError:
            return None

    def _build_model(self, n_features: int):
        try:
            import torch.nn as nn
        except ImportError:
            raise ImportError("PyTorch required for AutoencoderDetector. pip install torch")

        class _AE(nn.Module):
            def __init__(self, n_in, hidden_dims, bottleneck):
                super().__init__()
                # Encoder
                enc = []
                prev = n_in
                for h in hidden_dims:
                    enc += [nn.Linear(prev, h), nn.BatchNorm1d(h), nn.GELU()]
                    prev = h
                enc += [nn.Linear(prev, bottleneck), nn.GELU()]
                self.encoder = nn.Sequential(*enc)

                # Decoder (mirror of encoder)
                dec = []
                prev = bottleneck
                for h in reversed(hidden_dims):
                    dec += [nn.Linear(prev, h), nn.BatchNorm1d(h), nn.GELU()]
                    prev = h
                dec += [nn.Linear(prev, n_in)]
                self.decoder = nn.Sequential(*dec)

            def forward(self, x):
                return self.decoder(self.encoder(x))

        return _AE(n_features, self.hidden_dims, self.bottleneck_dim)

    def fit(self, X: np.ndarray) -> "AutoencoderDetector":
        try:
            import torch
            from torch.utils.data import DataLoader, TensorDataset
        except ImportError:
            logger.warning("PyTorch not available — AutoencoderDetector disabled.")
            self._is_fit = False
            return self

        device = self._get_device()
        self._model = self._build_model(X.shape[1]).to(device)
        opt = torch.optim.Adam(self._model.parameters(), lr=self.lr, weight_decay=1e-5)
        X_t = torch.from_numpy(X.astype(np.float32))
        ds  = TensorDataset(X_t)
        dl  = DataLoader(ds, batch_size=self.batch_size, shuffle=True)

        self._model.train()
        for epoch in range(self.epochs):
            for (batch,) in dl:
                batch = batch.to(device)
                loss  = torch.nn.functional.mse_loss(self._model(batch), batch)
                opt.zero_grad()
                loss.backward()
                opt.step()
            if (epoch + 1) % 10 == 0:
                logger.debug("Autoencoder epoch %d/%d | loss=%.4f", epoch + 1, self.epochs, loss.item())

        # Calibrate threshold on training reconstruction errors
        raw = self._raw_score(X)
        self._threshold_val = np.percentile(raw, 100 * (1 - self.contamination))
        self._fit_scaler_on_training(X)
        self._is_fit = True
        logger.debug("Autoencoder fit: threshold=%.4f", self._threshold_val)
        return self

    @torch.no_grad() if False else lambda f: f   # compatibility guard
    def _raw_score(self, X: np.ndarray) -> np.ndarray:
        if self._model is None:
            return np.zeros(len(X))
        try:
            import torch
        except ImportError:
            return np.zeros(len(X))

        device = self._get_device()
        self._model.eval()
        X_t = torch.from_numpy(X.astype(np.float32)).to(device)
        with torch.no_grad():
            recon = self._model(X_t).cpu().numpy()
        return np.mean((X - recon) ** 2, axis=1)

    def per_feature_error(self, X: np.ndarray) -> pd.DataFrame:
        """Return reconstruction error per feature — shows anomalous dimensions."""
        if self._model is None:
            return pd.DataFrame()
        try:
            import torch
        except ImportError:
            return pd.DataFrame()

        device = self._get_device()
        self._model.eval()
        X_t = torch.from_numpy(X.astype(np.float32)).to(device)
        with torch.no_grad():
            recon = self._model(X_t).cpu().numpy()
        return pd.DataFrame((X - recon) ** 2)


# ─────────────────────────────────────────────────────────────────────────────
# 5. Residual Detector
# ─────────────────────────────────────────────────────────────────────────────

class ResidualDetector:
    """
    Detects anomalies in model PREDICTION RESIDUALS.

    This is fundamentally different from the feature-space detectors above —
    it asks: "is the model's prediction error unusually high for this sample?"

    Use case:
    - Catch anomalies in the target variable space (e.g., abnormal energy surge).
    - Detect concept drift: the model was right during training but the
      system's behaviour has changed.
    - Complement feature-space detectors: a sample can look normal in features
      but produce an anomalously wrong prediction if the relationship shifted.

    How it works:
    - Fit a one-sided threshold on training residuals (per-target).
    - At inference, flag samples where |residual| > threshold.
    - Residual score = max(|residual| / threshold) across targets.
    """

    def __init__(
        self,
        contamination:   float = 0.05,
        per_target:      bool  = True,   # separate threshold per output
    ):
        self.contamination = contamination
        self.per_target    = per_target
        self._thresholds:  Optional[np.ndarray] = None
        self._is_fit       = False

    def fit(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
    ) -> "ResidualDetector":
        """Calibrate thresholds from training residuals."""
        residuals = np.abs(y_true - y_pred)          # (N, T)
        pct       = 100 * (1 - self.contamination)
        if self.per_target:
            self._thresholds = np.percentile(residuals, pct, axis=0)  # (T,)
        else:
            self._thresholds = np.array([np.percentile(residuals, pct)])
        self._is_fit = True
        logger.debug("ResidualDetector fit: thresholds=%s", self._thresholds)
        return self

    def score(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
    ) -> np.ndarray:
        """Return residual anomaly score in [0, ∞). Clipped to [0, 1]."""
        residuals = np.abs(y_true - y_pred)           # (N, T)
        if self._thresholds is not None:
            normed = residuals / (self._thresholds + 1e-8)  # (N, T)
        else:
            normed = residuals
        return np.clip(normed.max(axis=1), 0, 1)

    def detect(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
    ) -> np.ndarray:
        """Return binary labels: 1 = residual anomaly."""
        return (self.score(y_true, y_pred) >= 1.0).astype(int)


# ─────────────────────────────────────────────────────────────────────────────
# Ensemble aggregator
# ─────────────────────────────────────────────────────────────────────────────

class EnsembleAnomalyDetector:
    """
    Combines multiple detector scores into a single robust anomaly score.

    Aggregation strategy: weighted rank averaging.

    Why rank aggregation instead of score averaging?
    - Different detectors produce scores on incompatible scales.
    - Rank averaging is robust: an outlier score from one detector
      doesn't dominate if others disagree.
    - Weights let you tune sensitivity per detector for your domain.

    Parameters
    ----------
    detectors : dict[name → (BaseAnomalyDetector, weight)]
    contamination : float
        Final threshold for binary label conversion.
    severity_thresholds : tuple(float, float)
        (warning_percentile, critical_percentile) of ensemble score.
        E.g. (0.7, 0.9) → top 30% = warning, top 10% = critical.
    """

    def __init__(
        self,
        detectors:            Dict[str, Tuple[BaseAnomalyDetector, float]],
        contamination:        float              = 0.05,
        severity_thresholds:  Tuple[float,float] = (0.7, 0.9),
    ):
        self.detectors           = detectors          # {name: (detector, weight)}
        self.contamination       = contamination
        self.sev_warn, self.sev_crit = severity_thresholds
        self._label_threshold:    Optional[float] = None

    def fit(self, X: np.ndarray) -> "EnsembleAnomalyDetector":
        """Fit every registered detector on the training data."""
        for name, (det, _) in self.detectors.items():
            logger.info("Fitting anomaly detector: %s ...", name)
            det.fit(X)

        # Calibrate final label threshold on training ensemble scores
        train_scores = self._aggregate_scores(X)
        self._label_threshold = np.percentile(
            train_scores, 100 * (1 - self.contamination)
        )
        logger.info(
            "EnsembleAnomalyDetector fit | threshold=%.4f | n_detectors=%d",
            self._label_threshold, len(self.detectors)
        )
        return self

    def detect(
        self,
        X: np.ndarray,
        timestamps: Optional[np.ndarray] = None,
        feature_names: Optional[List[str]] = None,
        stat_detector_key: str = "statistical",
    ) -> AnomalyResult:
        """
        Run all detectors on X and return a full AnomalyResult.

        Parameters
        ----------
        X : (N, F) preprocessed feature array.
        timestamps : optional array of timestamps aligned with X rows.
        feature_names : optional list of feature column names.
        stat_detector_key : key in self.detectors pointing to the
            StatisticalDetector — used to extract feature contributions.
        """
        per_detector: Dict[str, np.ndarray] = {}
        for name, (det, _) in self.detectors.items():
            if det._is_fit:
                per_detector[name] = det.score(X)
            else:
                per_detector[name] = np.zeros(len(X))

        ensemble_scores = self._aggregate_scores(X, per_detector)
        labels          = (ensemble_scores >= self._label_threshold).astype(int)
        severity        = self._assign_severity(ensemble_scores)
        anomaly_idx     = np.where(labels == 1)[0]

        # Feature contributions from statistical detector
        feat_contribs = None
        if stat_detector_key in self.detectors:
            stat_det, _ = self.detectors[stat_detector_key]
            if isinstance(stat_det, StatisticalDetector) and stat_det._is_fit:
                fc = stat_det.feature_contributions(X)
                if feature_names is not None:
                    fc.columns = feature_names[:fc.shape[1]]
                # Only return contributions for flagged samples
                feat_contribs = fc

        result = AnomalyResult(
            scores=ensemble_scores,
            labels=labels,
            severity=severity,
            per_detector=per_detector,
            feature_contributions=feat_contribs,
            anomaly_indices=anomaly_idx,
            timestamps=timestamps,
            n_anomalies=int(labels.sum()),
            contamination_rate=float(labels.mean()),
        )
        logger.info(
            "Anomaly detection: %d / %d flagged (%.1f%%)",
            result.n_anomalies, len(X), result.contamination_rate * 100
        )
        return result

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _aggregate_scores(
        self,
        X: np.ndarray,
        cached: Optional[Dict[str, np.ndarray]] = None,
    ) -> np.ndarray:
        """Weighted rank aggregation across all detectors."""
        N = len(X)
        agg = np.zeros(N)
        total_weight = 0.0

        for name, (det, weight) in self.detectors.items():
            if not det._is_fit:
                continue
            scores = cached[name] if (cached and name in cached) else det.score(X)
            # Convert to ranks (0 = least anomalous, N-1 = most anomalous)
            ranks  = scores.argsort().argsort().astype(float) / max(N - 1, 1)
            agg   += weight * ranks
            total_weight += weight

        if total_weight > 0:
            agg /= total_weight
        return agg

    def _assign_severity(self, scores: np.ndarray) -> np.ndarray:
        """Assign 'normal', 'warning', 'critical' per sample."""
        severity = np.full(len(scores), "normal", dtype=object)
        warn_thr = np.percentile(scores, self.sev_warn * 100)
        crit_thr = np.percentile(scores, self.sev_crit * 100)
        severity[scores >= warn_thr] = "warning"
        severity[scores >= crit_thr] = "critical"
        return severity


# ─────────────────────────────────────────────────────────────────────────────
# High-level pipeline class
# ─────────────────────────────────────────────────────────────────────────────

class AnomalyDetectionPipeline:
    """
    Orchestrates the full anomaly detection lifecycle, integrated with
    the existing MLPipeline.

    This class:
    - Builds and fits an EnsembleAnomalyDetector on TRAINING features.
    - Optionally fits a ResidualDetector using training residuals from
      the predictive model.
    - Exposes detect() and detect_with_residuals() for inference.
    - Can save/load its own state independently of the main pipeline.

    Parameters
    ----------
    config : AnomalyConfig
        Anomaly-specific configuration (from config.py).
    feature_names : list[str]
        Names of the preprocessed feature columns (for interpretability).
    target_names : list[str]
        Names of the prediction targets (for residual detection).

    Usage (within MLPipeline.fit)
    ──────────────────────────────
    >>> ad = AnomalyDetectionPipeline(cfg.anomaly, feat_names, targets)
    >>> ad.fit(X_train, y_train_true, y_train_pred)
    >>> result = ad.detect(X_test)
    >>> result_with_resid = ad.detect_with_residuals(X_test, y_test, y_pred)
    """

    def __init__(
        self,
        config,              # AnomalyConfig dataclass
        feature_names: List[str],
        target_names:  List[str],
    ) -> None:
        self.cfg           = config
        self.feature_names = feature_names
        self.target_names  = target_names
        self._ensemble:  Optional[EnsembleAnomalyDetector] = None
        self._residual:  Optional[ResidualDetector]         = None
        self._is_fit     = False

    def fit(
        self,
        X_train:      np.ndarray,
        y_train_true: Optional[np.ndarray] = None,
        y_train_pred: Optional[np.ndarray] = None,
    ) -> "AnomalyDetectionPipeline":
        """
        Fit all anomaly detectors on training data.

        Parameters
        ----------
        X_train      : (N, F) preprocessed training features.
        y_train_true : (N, T) actual training targets — required for
                       ResidualDetector calibration.
        y_train_pred : (N, T) model predictions on training set — required
                       for ResidualDetector calibration.
        """
        cfg = self.cfg

        # Build detector registry from config
        detectors: Dict[str, Tuple[BaseAnomalyDetector, float]] = {}

        if cfg.use_isolation_forest:
            detectors["isolation_forest"] = (
                IsolationForestDetector(
                    contamination=cfg.contamination,
                    n_estimators=cfg.if_n_estimators,
                ),
                cfg.weights.get("isolation_forest", 1.0),
            )

        if cfg.use_lof:
            detectors["lof"] = (
                LocalOutlierFactorDetector(
                    contamination=cfg.contamination,
                    n_neighbors=cfg.lof_n_neighbors,
                ),
                cfg.weights.get("lof", 1.0),
            )

        if cfg.use_statistical:
            detectors["statistical"] = (
                StatisticalDetector(
                    contamination=cfg.contamination,
                    z_threshold=cfg.z_threshold,
                    iqr_multiplier=cfg.iqr_multiplier,
                    cusum_slack=cfg.cusum_slack,
                    cusum_h=cfg.cusum_h,
                ),
                cfg.weights.get("statistical", 1.0),
            )

        if cfg.use_autoencoder:
            detectors["autoencoder"] = (
                AutoencoderDetector(
                    contamination=cfg.contamination,
                    hidden_dims=cfg.ae_hidden_dims,
                    bottleneck_dim=cfg.ae_bottleneck_dim,
                    epochs=cfg.ae_epochs,
                    batch_size=cfg.ae_batch_size,
                ),
                cfg.weights.get("autoencoder", 1.0),
            )

        if not detectors:
            raise ValueError("No anomaly detectors enabled in AnomalyConfig.")

        self._ensemble = EnsembleAnomalyDetector(
            detectors=detectors,
            contamination=cfg.contamination,
            severity_thresholds=(cfg.severity_warning_pct, cfg.severity_critical_pct),
        )
        self._ensemble.fit(X_train)

        # Residual detector (requires predictions)
        if cfg.use_residual_detection and y_train_true is not None and y_train_pred is not None:
            self._residual = ResidualDetector(contamination=cfg.contamination)
            self._residual.fit(y_train_true, y_train_pred)
            logger.info("ResidualDetector calibrated.")

        self._is_fit = True
        return self

    def detect(
        self,
        X: np.ndarray,
        timestamps: Optional[np.ndarray] = None,
    ) -> AnomalyResult:
        """Feature-space anomaly detection (no ground-truth targets needed)."""
        if not self._is_fit:
            raise RuntimeError("AnomalyDetectionPipeline not fitted.")
        return self._ensemble.detect(X, timestamps=timestamps, feature_names=self.feature_names)

    def detect_with_residuals(
        self,
        X:      np.ndarray,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        timestamps: Optional[np.ndarray] = None,
    ) -> AnomalyResult:
        """
        Combined feature-space + residual anomaly detection.

        A sample is flagged if EITHER:
          (a) its features are anomalous (ensemble score above threshold), OR
          (b) the model's prediction error exceeds the residual threshold.

        This union catches two distinct failure modes:
          - Anomalous input (corrupted sensor, unusual operating condition).
          - Anomalous output despite normal-looking inputs (concept drift).
        """
        feat_result = self.detect(X, timestamps=timestamps)

        if self._residual is not None:
            resid_scores = self._residual.score(y_true, y_pred)
            resid_labels = self._residual.detect(y_true, y_pred)

            # Union of anomaly flags (OR rule)
            combined_labels = np.maximum(feat_result.labels, resid_labels)
            # Average scores from both sources
            combined_scores = np.maximum(feat_result.scores, resid_scores * 0.5)

            feat_result.per_detector["residual"]  = resid_scores
            feat_result.labels                    = combined_labels
            feat_result.scores                    = combined_scores
            feat_result.n_anomalies               = int(combined_labels.sum())
            feat_result.contamination_rate        = float(combined_labels.mean())
            feat_result.anomaly_indices           = np.where(combined_labels == 1)[0]

        return feat_result

    def save(self, path: str) -> None:
        import pickle
        with open(path, "wb") as f:
            pickle.dump({"ensemble": self._ensemble, "residual": self._residual}, f)
        logger.info("AnomalyDetectionPipeline saved to %s", path)

    def load(self, path: str) -> "AnomalyDetectionPipeline":
        import pickle
        with open(path, "rb") as f:
            state = pickle.load(f)
        self._ensemble = state["ensemble"]
        self._residual = state["residual"]
        self._is_fit   = True
        return self
