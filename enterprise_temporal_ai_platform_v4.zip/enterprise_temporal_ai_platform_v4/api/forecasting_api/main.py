"""
Enterprise Temporal AI Platform — Forecast Service
"""

from __future__ import annotations

import time
from contextlib import asynccontextmanager
from typing import AsyncGenerator

import redis.asyncio as aioredis
import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from prometheus_client import Counter, Histogram, make_asgi_app

from shared.config.settings import settings
from shared.logging.logger import configure_logging, get_logger, set_request_context
from routers import forecast, training, inference

# ── Logging ───────────────────────────────────────────────────────────────────
configure_logging(
    service_name="forecast-service",
    log_level=settings.LOG_LEVEL,
    json_output=settings.is_production,
)
log = get_logger("forecast_service")

# ── Prometheus Metrics ────────────────────────────────────────────────────────
REQUEST_COUNT = Counter(
    "forecast_requests_total",
    "Total forecast requests",
    ["tenant_id", "model", "status"],
)
REQUEST_LATENCY = Histogram(
    "forecast_request_latency_seconds",
    "Forecast request latency",
    ["tenant_id", "model"],
    buckets=[0.01, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0],
)
FORECAST_HORIZON = Histogram(
    "forecast_horizon_steps",
    "Distribution of requested forecast horizons",
    buckets=[1, 12, 24, 48, 72, 120, 168, 336, 720],
)


# ── Lifespan ─────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator:
    log.info("forecast_service.startup", env=settings.ENV)

    # Initialise Redis connection pool
    app.state.redis = aioredis.from_url(
        settings.REDIS_URL,
        encoding="utf-8",
        decode_responses=True,
        max_connections=20,
    )
    await app.state.redis.ping()
    log.info("redis.connected", url=settings.REDIS_URL)

    yield

    # Cleanup
    await app.state.redis.aclose()
    log.info("forecast_service.shutdown")


# ── Application Factory ───────────────────────────────────────────────────────
def create_app() -> FastAPI:
    app = FastAPI(
        title="Temporal AI — Forecast Service",
        description=(
            "Multi-step probabilistic and quantile forecasting microservice. "
            "Supports PatchTST, TFT, TimesNet, N-BEATS, GRU and ensemble predictions."
        ),
        version="1.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan,
    )

    # ── CORS ──────────────────────────────────────────────────────────────────
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Request tracing middleware ────────────────────────────────────────────
    @app.middleware("http")
    async def request_context_middleware(request: Request, call_next):
        request_id = request.headers.get("X-Request-ID")
        tenant_id = request.headers.get("X-Tenant-ID")
        user_id = request.headers.get("X-User-ID")
        set_request_context(request_id, tenant_id, user_id)

        start = time.perf_counter()
        response = await call_next(request)
        elapsed = (time.perf_counter() - start) * 1000

        log.info(
            "http.request",
            method=request.method,
            path=request.url.path,
            status=response.status_code,
            elapsed_ms=round(elapsed, 2),
        )
        return response

    # ── Exception handler ────────────────────────────────────────────────────
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        log.error("unhandled_exception", exc=str(exc), path=request.url.path)
        return JSONResponse(
            status_code=500,
            content={"status": "error", "message": str(exc)},
        )

    # ── Routers ───────────────────────────────────────────────────────────────
    app.include_router(forecast.router, prefix="/v1", tags=["Forecasting"])
    app.include_router(training.router, prefix="/v1", tags=["Training"])
    app.include_router(inference.router, prefix="/v1", tags=["Inference"])

    # ── Prometheus metrics endpoint ───────────────────────────────────────────
    metrics_app = make_asgi_app()
    app.mount("/metrics", metrics_app)

    # ── Health ────────────────────────────────────────────────────────────────
    @app.get("/health", tags=["Health"])
    async def health(request: Request):
        redis_ok = False
        try:
            await request.app.state.redis.ping()
            redis_ok = True
        except Exception:
            pass

        return {
            "status": "healthy" if redis_ok else "degraded",
            "service": "forecast-service",
            "version": "1.0.0",
            "dependencies": {
                "redis": "ok" if redis_ok else "unreachable",
            },
        }

    return app


app = create_app()

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=settings.FORECAST_SERVICE_PORT,
        reload=not settings.is_production,
        workers=1 if not settings.is_production else 4,
        log_level=settings.LOG_LEVEL.lower(),
    )
