"""
sample_data_generator.py — Generate a sample long-format telemetry CSV.

Run this to create a test dataset that matches the expected schema:
    python sample_data_generator.py

Output: sample_telemetry.csv (long format, ~30k rows)
"""

import numpy as np
import pandas as pd

SEED       = 42
N_MINUTES  = 10_000         # number of 1-minute intervals
ASSETS     = ["asset_A", "asset_B", "asset_C"]
N_SENSORS  = 4              # telemetry_1 … telemetry_4
OUT_FILE   = "sample_telemetry.csv"

rng = np.random.default_rng(SEED)
timestamps = pd.date_range("2026-01-01", periods=N_MINUTES, freq="1min")

rows = []
for asset_idx, asset in enumerate(ASSETS):
    base = 40 + asset_idx * 5
    for i, ts in enumerate(timestamps):
        row = {"ts": ts, "asset_id": asset}
        for s in range(1, N_SENSORS + 1):
            signal = base + s * 2 + np.sin(i / 60) * 3 + rng.normal(0, 0.5)
            row[f"telemetry_{s}"] = round(signal, 4)
        rows.append(row)

df = pd.DataFrame(rows)
df.to_csv(OUT_FILE, index=False)
print(f"Saved {len(df):,} rows → {OUT_FILE}")
print(f"Columns: {df.columns.tolist()}")
print(df.head(6).to_string(index=False))
