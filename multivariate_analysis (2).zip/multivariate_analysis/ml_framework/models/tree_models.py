"""
tree_models.py — Gradient-boosted and random forest models for multi-output
regression / forecasting.

Architecture choices
--------------------
* LightGBM is the default: it handles missing values natively, supports
  categorical features, and is extremely fast on large datasets.
* XGBoost and scikit-learn RandomForest are available as alternatives.
* Multi-output prediction is handled via two strategies:
    - "direct"  : one independent model per target (fastest, no coupling)
    - "chain"   : RegressorChain — each model uses previous targets as
                  additional features (captures inter-target dependencies)
* Early stopping on a validation set prevents over-fitting.
* The models expose a .predict() method compatible with the rest of the
  pipeline and return (N, n_targets) arrays.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional, Tuple

import numpy as np
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.multioutput import MultiOutputRegressor, RegressorChain

from ..core.config import FrameworkConfig, TreeModelConfig

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Base wrapper
# ---------------------------------------------------------------------------


def _build_base_estimator(cfg: TreeModelConfig) -> BaseEstimator:
    """Instantiate the underlying single-output regressor."""
    if cfg.model_type == "lgbm":
        try:
            import lightgbm as lgb  # type: ignore
        except ImportError:
            raise ImportError("Install lightgbm: pip install lightgbm")

        return lgb.LGBMRegressor(
            n_estimators=cfg.n_estimators,
            max_depth=cfg.max_depth,
            learning_rate=cfg.learning_rate,
            subsample=cfg.subsample,
            colsample_bytree=cfg.colsample_bytree,
            reg_alpha=cfg.reg_alpha,
            reg_lambda=cfg.reg_lambda,
            n_jobs=cfg.n_jobs,
            random_state=42,
            verbose=-1,
        )

    elif cfg.model_type == "xgb":
        try:
            import xgboost as xgb  # type: ignore
        except ImportError:
            raise ImportError("Install xgboost: pip install xgboost")

        return xgb.XGBRegressor(
            n_estimators=cfg.n_estimators,
            max_depth=max(cfg.max_depth, 6),
            learning_rate=cfg.learning_rate,
            subsample=cfg.subsample,
            colsample_bytree=cfg.colsample_bytree,
            reg_alpha=cfg.reg_alpha,
            reg_lambda=cfg.reg_lambda,
            n_jobs=cfg.n_jobs,
            random_state=42,
            verbosity=0,
            early_stopping_rounds=cfg.early_stopping_rounds,
        )

    elif cfg.model_type == "rf":
        from sklearn.ensemble import RandomForestRegressor

        return RandomForestRegressor(
            n_estimators=cfg.n_estimators,
            max_depth=None if cfg.max_depth == -1 else cfg.max_depth,
            max_features="sqrt",
            n_jobs=cfg.n_jobs,
            random_state=42,
        )
    else:
        raise ValueError(f"Unknown model_type: {cfg.model_type}")


# ---------------------------------------------------------------------------
# Multi-output tree regressor
# ---------------------------------------------------------------------------


class MultiOutputTreeRegressor:
    """
    Wraps a single-output tree-based estimator into a multi-output regressor.

    Supports both 'direct' (independent per-target models) and 'chain'
    (outputs used as inputs for subsequent models) strategies.

    Parameters
    ----------
    config : FrameworkConfig

    Usage
    -----
    >>> model = MultiOutputTreeRegressor(cfg)
    >>> model.fit(X_train, y_train, X_val=X_val, y_val=y_val)
    >>> predictions = model.predict(X_test)   # shape (N, n_targets)
    >>> importance  = model.feature_importances(feature_names)
    """

    def __init__(self, config: FrameworkConfig) -> None:
        self.cfg     = config.tree_model
        self._model  = None
        self._targets: List[str] = config.targets
        self._feature_names: List[str] = []

    # ------------------------------------------------------------------
    # Fit
    # ------------------------------------------------------------------

    def fit(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        X_val: Optional[np.ndarray] = None,
        y_val:  Optional[np.ndarray] = None,
        feature_names: Optional[List[str]] = None,
    ) -> "MultiOutputTreeRegressor":
        """
        Fit the multi-output model.

        For LightGBM / XGBoost, validation data enables early stopping.
        For RandomForest, validation data is ignored (no early stopping).
        """
        self._feature_names = feature_names or [f"f{i}" for i in range(X_train.shape[1])]
        base = _build_base_estimator(self.cfg)

        if self.cfg.multi_output_strategy == "chain":
            self._model = RegressorChain(base, order="random", random_state=42)
            # Chain does not forward eval_set; fit without early stopping
            self._model.fit(X_train, y_train)
        else:
            # "direct" — one model per output
            self._model = MultiOutputRegressor(base, n_jobs=1)
            if X_val is not None and hasattr(base, "fit") and self._supports_early_stopping():
                # Manually fit each sub-estimator with eval_set
                self._fit_direct_with_early_stopping(X_train, y_train, X_val, y_val)
            else:
                self._model.fit(X_train, y_train)

        n_outputs = y_train.shape[1] if y_train.ndim > 1 else 1
        logger.info(
            "TreeModel fit: strategy=%s  n_outputs=%d  n_features=%d",
            self.cfg.multi_output_strategy, n_outputs, X_train.shape[1],
        )
        return self

    def _supports_early_stopping(self) -> bool:
        return self.cfg.model_type in ("lgbm", "xgb")

    def _fit_direct_with_early_stopping(
        self,
        X_train, y_train, X_val, y_val
    ) -> None:
        """Fit each target independently with early stopping."""
        import copy
        estimators = []
        for i in range(y_train.shape[1]):
            base = _build_base_estimator(self.cfg)
            fit_kwargs: Dict = {}

            if self.cfg.model_type == "lgbm":
                fit_kwargs = {
                    "eval_set": [(X_val, y_val[:, i])],
                    "callbacks": [
                        __import__("lightgbm").early_stopping(
                            self.cfg.early_stopping_rounds, verbose=False
                        ),
                        __import__("lightgbm").log_evaluation(-1),
                    ],
                }
            elif self.cfg.model_type == "xgb":
                fit_kwargs = {"eval_set": [(X_val, y_val[:, i])], "verbose": False}

            base.fit(X_train, y_train[:, i], **fit_kwargs)
            estimators.append(base)
            logger.debug("Target %d/%d fit complete.", i + 1, y_train.shape[1])

        # Reconstruct MultiOutputRegressor from fitted estimators
        self._model = MultiOutputRegressor(_build_base_estimator(self.cfg))
        self._model.estimators_ = estimators
        self._model.n_outputs_ = y_train.shape[1]

    # ------------------------------------------------------------------
    # Predict
    # ------------------------------------------------------------------

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Return predictions of shape (N, n_targets)."""
        if self._model is None:
            raise RuntimeError("Model not fitted yet. Call .fit() first.")
        preds = self._model.predict(X)
        if preds.ndim == 1:
            preds = preds[:, np.newaxis]
        return preds.astype(np.float32)

    # ------------------------------------------------------------------
    # Feature importance
    # ------------------------------------------------------------------

    def feature_importances(
        self,
        feature_names: Optional[List[str]] = None,
    ) -> Dict[str, np.ndarray]:
        """
        Return per-target feature importance arrays.

        For 'direct' models, importance is retrieved from each sub-estimator.
        For 'chain' models, it's retrieved from each link in the chain.
        """
        names = feature_names or self._feature_names
        result: Dict[str, np.ndarray] = {}

        if self.cfg.multi_output_strategy == "chain":
            estimators = self._model.estimators_
        else:
            estimators = self._model.estimators_

        for i, est in enumerate(estimators):
            target_name = self._targets[i] if i < len(self._targets) else f"target_{i}"
            if hasattr(est, "feature_importances_"):
                imp = est.feature_importances_
                # Chain models add previous targets as extra features
                imp = imp[:len(names)]
                result[target_name] = imp
        return result

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def get_estimators(self) -> List[BaseEstimator]:
        """Access individual sub-estimators (e.g., for SHAP TreeExplainer)."""
        if self.cfg.multi_output_strategy == "chain":
            return list(self._model.estimators_)
        return list(self._model.estimators_)
