"""
Enterprise Temporal AI Platform V4 — Residual Anomaly Detector

V4 changes:
  - Operates on [B, H, T] residuals (actual - forecast)
  - Per-target anomaly scores
  - Fleet-level asset ranking
  - Health score: 0–100 combining residual + correlation + reconstruction
"""

from __future__ import annotations
from typing import Dict, List, Optional, Tuple

import numpy as np
from sklearn.preprocessing import StandardScaler

from shared.logging.logger import get_logger

log = get_logger("anomaly.residual")


# ─────────────────────────────────────────────────────────────────────────────
# Residual Detector
# ─────────────────────────────────────────────────────────────────────────────

class ResidualAnomalyDetector:
    """
    Detects anomalies from forecast residuals.

    Residual shape: [B, H, T]  or  [H, T]  (single sample)

    Anomaly score per sample = mean absolute z-scored residual across H and T.
    """

    def __init__(
        self,
        threshold_sigma: float = 3.0,
        window: int = 50,
    ):
        self.threshold_sigma = threshold_sigma
        self.window = window
        self._scaler = StandardScaler()
        self._fitted = False
        # Rolling buffer for online fitting: [buffer_size, T]
        self._buffer: List[np.ndarray] = []

    def fit(self, residuals: np.ndarray):
        """
        Fit scaler on historical residuals.
        residuals: [N, H, T]  or  [N, T]
        """
        if residuals.ndim == 3:
            N, H, T = residuals.shape
            flat = residuals.reshape(N * H, T)
        else:
            flat = residuals
        self._scaler.fit(flat)
        self._fitted = True
        log.info("residual_detector.fitted", shape=flat.shape)

    def score(self, actual: np.ndarray, forecast: np.ndarray) -> Dict:
        """
        Compute anomaly scores.

        actual:   [B, H, T]
        forecast: [B, H, T]

        Returns:
            {
                "residuals":      [B, H, T],
                "scores":         [B]       — per-sample anomaly score
                "per_target":     [B, T]    — score per target channel
                "is_anomaly":     [B]       — bool
                "threshold":      float
            }
        """
        residuals = actual - forecast           # [B, H, T]
        B, H, T   = residuals.shape

        # z-score residuals per target
        flat = residuals.reshape(B * H, T)      # [B*H, T]

        if self._fitted:
            z = self._scaler.transform(flat)
        else:
            # Online: fit on the fly
            mu  = flat.mean(axis=0, keepdims=True)
            std = flat.std(axis=0, keepdims=True) + 1e-8
            z   = (flat - mu) / std

        z = z.reshape(B, H, T)                  # [B, H, T]

        # Per-target score: mean |z| over horizon
        per_target = np.abs(z).mean(axis=1)     # [B, T]

        # Overall score: mean over all targets
        scores = per_target.mean(axis=-1)        # [B]

        threshold = self.threshold_sigma
        is_anomaly = scores > threshold

        # Update rolling buffer
        for i in range(B):
            self._buffer.append(residuals[i].mean(axis=0))   # [T]
            if len(self._buffer) > self.window:
                self._buffer.pop(0)

        return {
            "residuals":   residuals,
            "scores":      scores,
            "per_target":  per_target,
            "is_anomaly":  is_anomaly,
            "threshold":   threshold,
            "z_scores":    z,
        }


# ─────────────────────────────────────────────────────────────────────────────
# Correlation Detector
# ─────────────────────────────────────────────────────────────────────────────

class CorrelationAnomalyDetector:
    """
    Detects anomalies in feature relationships.
    Compares current correlation matrix to baseline.
    """

    def __init__(self, threshold: float = 0.3):
        self.threshold    = threshold
        self._baseline_corr: Optional[np.ndarray] = None

    def fit(self, X: np.ndarray):
        """
        X: [N, F]  — fit baseline correlation matrix
        """
        self._baseline_corr = np.corrcoef(X.T)
        log.info("correlation_detector.fitted", shape=X.shape)

    def score(self, X: np.ndarray) -> Dict:
        """
        X: [N, F]
        Returns correlation drift score.
        """
        current_corr = np.corrcoef(X.T)

        if self._baseline_corr is None:
            return {"score": 0.0, "drift": 0.0, "is_anomaly": False}

        drift = np.abs(current_corr - self._baseline_corr).mean()
        is_anomaly = drift > self.threshold

        return {
            "score":       float(drift),
            "drift":       float(drift),
            "is_anomaly":  bool(is_anomaly),
            "threshold":   self.threshold,
        }


# ─────────────────────────────────────────────────────────────────────────────
# Health Scorer
# ─────────────────────────────────────────────────────────────────────────────

class AssetHealthScorer:
    """
    Combines residual, correlation, and reconstruction scores into
    a single health score: 0 (critical) → 100 (healthy).

    health = 100 * sigmoid(-combined_score)
    """

    def __init__(
        self,
        residual_weight:       float = 0.5,
        correlation_weight:    float = 0.25,
        reconstruction_weight: float = 0.25,
        sigma_threshold:       float = 3.0,
    ):
        self.w_residual       = residual_weight
        self.w_correlation    = correlation_weight
        self.w_reconstruction = reconstruction_weight
        self.sigma_threshold  = sigma_threshold

    def score(
        self,
        residual_score:       float,
        correlation_score:    float = 0.0,
        reconstruction_score: float = 0.0,
    ) -> float:
        """
        Returns health score: 0–100.
        Higher = healthier.
        """
        combined = (
            self.w_residual       * residual_score +
            self.w_correlation    * correlation_score +
            self.w_reconstruction * reconstruction_score
        )
        # Normalise relative to threshold
        normalised = combined / (self.sigma_threshold + 1e-8)
        # Sigmoid → 0 to 1, then invert (high score = anomalous = low health)
        import math
        health = 100.0 / (1.0 + math.exp(normalised))
        return round(float(health), 2)

    def score_fleet(
        self,
        asset_ids:      List[str],
        residual_scores: np.ndarray,   # [num_assets]
    ) -> List[Dict]:
        """
        Produce ranked fleet health report.
        """
        report = []
        for i, (aid, rs) in enumerate(zip(asset_ids, residual_scores)):
            health = self.score(float(rs))
            report.append({
                "asset_id":      aid,
                "health_score":  health,
                "anomaly_score": float(rs),
                "status":        "critical" if health < 30 else "warning" if health < 60 else "healthy",
            })
        # Sort: most critical first
        report.sort(key=lambda x: x["health_score"])
        return report
