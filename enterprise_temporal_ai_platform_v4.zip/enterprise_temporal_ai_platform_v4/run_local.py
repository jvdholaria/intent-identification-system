#!/usr/bin/env python3
"""
Enterprise Temporal AI Platform — Local Runner
================================================
Single-script entry point to run the full pipeline on a CSV file
without Kubernetes or GCP.

Usage
-----
    python run_local.py --csv data/my_series.csv --target value

    # Specify timestamp and target columns explicitly:
    python run_local.py --csv data/sales.csv --timestamp date --target sales

    # Run specific steps only:
    python run_local.py --csv data/energy.csv --target kwh --steps prepare train forecast anomaly

    # Quick mode (no training — instant forecast using untrained weights):
    python run_local.py --csv data/energy.csv --target kwh --quick

Steps
-----
    prepare   → Load & preprocess CSV, export .npy splits
    train     → Train GRU (fast) or PatchTST / TFT (slower)
    forecast  → Run multi-step probabilistic forecast on test split
    anomaly   → Run hybrid anomaly detection on test split
    drift     → Run drift detection (train vs test distribution)
    report    → Print summary + save results to CSV
    all       → Run all steps (default)
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

import os

os.environ["TORCHINDUCTOR_DISABLE"] = "1"
os.environ["TORCH_COMPILE_DISABLE"] = "1"

from pytorch_lightning.loggers import CSVLogger

import numpy as np
import pandas as pd

# ── Add project root to path ──────────────────────────────────────────────────
ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

os.environ.setdefault("ENV", "development")
os.environ.setdefault("REDIS_URL", "redis://localhost:6379")
os.environ.setdefault("MLFLOW_TRACKING_URI", "http://localhost:5000")
os.environ.setdefault("DATABASE_URL", "sqlite:///./local_temporal.db")
os.environ.setdefault("LLM_BASE_URL", "http://localhost:11434")

from shared.config.settings import settings
from shared.logging.logger import configure_logging, get_logger
from shared.data.csv_loader import CSVLoaderConfig, preview_csv
from shared.data.parallel_csv_loader import ParallelCSVLoader

configure_logging("local-runner", log_level="INFO", json_output=False)
log = get_logger("runner")

RESULTS_DIR = Path("./local_results")



import logging
import structlog

structlog.configure(
    processors=[
        structlog.stdlib.add_logger_name,  # Requires standard library wrapper
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.JSONRenderer()
    ],
    # MUST use LoggerFactory if using stdlib processors!
    logger_factory=structlog.stdlib.LoggerFactory(), 
    wrapper_class=structlog.stdlib.BoundLogger,
)


# ─────────────────────────────────────────────────────────────────────────────
# Step 1 — Prepare
# ─────────────────────────────────────────────────────────────────────────────

def step_prepare(args) -> dict:
    print("\n" + "═" * 60)
    print("  STEP 1 — CSV PREPARATION & PREPROCESSING")
    print("═" * 60)

    # Quick preview first
    preview = preview_csv(args.csv)
    print(f"\n📄 File: {args.csv}")
    print(f"   Shape : {preview['shape'][0]:,} rows × {preview['shape'][1]} cols")
    print(f"   Columns: {preview['columns']}")
    if preview["timestamp_candidates"]:
        print(f"   Timestamp candidates : {preview['timestamp_candidates']}")
    print(f"   Numeric candidates   : {preview['numeric_candidates']}")
    print(f"\n   Sample rows:")
    for row in preview["sample"][:3]:
        print(f"   {row}")

    # Auto-detect target if not specified
    target = args.target
    if target not in preview["columns"]:
        if preview["numeric_candidates"]:
            target = preview["numeric_candidates"][0]
            print(f"\n⚠  Column '{args.target}' not found — using '{target}' instead")
        else:
            raise ValueError(f"No numeric column found. Available: {preview['columns']}")

    # Automatically use ALL numeric columns except target
    if args.features:
        feature_columns = [f.strip() for f in args.features.split(",")]
    else:
        feature_columns = [
            c for c in preview["numeric_candidates"]
            if c != target
        ]

    print(f"\n📊 Using {len(feature_columns)} feature columns")

    config = CSVLoaderConfig(
        timestamp_column=args.timestamp,
        target_column=target,
        feature_columns=feature_columns,
        resample_freq=args.resample,
        interpolation_method="linear",
        max_gap_fill_periods=8,
        normalisation=args.norm,
        train_ratio=0.70,
        val_ratio=0.15,
        window_size=args.window,
        horizon=args.horizon,
        output_dir=str(RESULTS_DIR / "processed"),
    )


    loader = ParallelCSVLoader(config)   # auto-falls back to single-thread for small files
    ds = loader.load(args.csv)

    print(f"\n✅ Preprocessing complete:")
    print(f"   Total points : {len(ds.series):,}")
    print(f"   Train        : {len(ds.train):,} points  ({len(ds.train)/len(ds.series)*100:.0f}%)")
    print(f"   Val          : {len(ds.val):,} points  ({len(ds.val)/len(ds.series)*100:.0f}%)")
    print(f"   Test         : {len(ds.test):,} points  ({len(ds.test)/len(ds.series)*100:.0f}%)")
    print(f"\n   Raw stats (original scale):")
    print(f"     Mean   : {ds.stats['mean']:.4f}")
    print(f"     Std    : {ds.stats['std']:.4f}")
    print(f"     Min    : {ds.stats['min']:.4f}")
    print(f"     Max    : {ds.stats['max']:.4f}")
    print(f"     NaNs   : {ds.stats['null_count']}")

    paths = loader.export_npy(ds)
    print(f"\n💾 Saved processed files:")
    for k, v in paths.items():
        print(f"   {k:12s} → {v}")

    return {"dataset": ds, "loader": loader, "paths": paths, "target": target}


# ─────────────────────────────────────────────────────────────────────────────
# Step 2 — Train
# ─────────────────────────────────────────────────────────────────────────────

def step_train(ctx: dict, args) -> dict:
    print("\n" + "═" * 60)
    print("  STEP 2 — MODEL TRAINING")
    print("═" * 60)

    ds = ctx["dataset"]
    model_type = args.model
    quick = args.quick

    if quick:
        print(f"\n⚡ Quick mode — skipping training, using untrained {model_type} weights")
        print("   (Pass --no-quick to enable training)")
        return {"model": None, "run_id": "quick-mode", "val_loss": None}

    print(f"\n🔧 Training model  : {model_type.upper()}")
    print(f"   Epochs         : {args.epochs}")
    print(f"   Batch size     : {args.batch_size}")
    print(f"   Learning rate  : {args.lr}")
    print(f"   Window size    : {args.window}")
    print(f"   Horizon        : {args.horizon}")
    print(f"   Train samples  : {max(0, len(ds.train) - args.window - args.horizon + 1)}")

    # Check MLflow availability
    mlflow_available = _check_mlflow()

    if mlflow_available:
        print(f"   MLflow URI     : {settings.MLFLOW_TRACKING_URI}")
    else:
        print(f"   MLflow         : ⚠ Not reachable — running without experiment tracking")

    from forecasting.training.trainer import TemporalTrainer, TemporalDatasetBuilder
    from shared.schemas.schemas import ModelType

    # ── NaN / Inf guard before any training ───────────────────────────────────
    for split_name, split_data in [("train", ds.train), ("val", ds.val)]:
        if np.isnan(split_data).any() or np.isinf(split_data).any():
            bad = int(np.isnan(split_data).sum()) + int(np.isinf(split_data).sum())
            raise ValueError(
                f"❌ {split_name} split contains {bad} NaN/Inf values. "
                "Re-run with --norm robust or check CSV for bad rows."
            )
    print(f"   ✅ NaN/Inf check passed on train + val splits")

    # Check minimum samples needed for sliding window
    n_min = args.window + args.horizon
    if len(ds.train) < n_min:
        raise ValueError(
            f"❌ Training split has {len(ds.train)} points but window+horizon={n_min} "
            f"is required. Use --window {len(ds.train)//4} --horizon {len(ds.train)//8}"
        )

    builder = TemporalDatasetBuilder(args.window, args.horizon)
    dataset = builder.build(ds.train)
    val_ds = builder.build(ds.val) if len(ds.val) >= n_min else None

    if val_ds is None:
        print(f"   ⚠  Val split too small for window ({len(ds.val)} < {n_min}) — skipping val")

    import torch
    import pytorch_lightning as pl
    from torch.utils.data import DataLoader
    from forecasting.training.trainer import TemporalLightningModule

    # ── Detect best precision ─────────────────────────────────────────────────
    gpu_available = torch.cuda.is_available()
    if gpu_available:
        precision = "16-mixed"
        print(f"   🎮 GPU detected: {torch.cuda.get_device_name(0)}")
        print(f"   ⚡ Using mixed precision (16-mixed) — expect 1.5–3× speedup")
    else:
        precision = "32"
        print(f"   💻 CPU mode — precision=32")
        print(f"   ⚠  For faster training: pip install torch --index-url https://download.pytorch.org/whl/cu124")

    trainer_obj = TemporalTrainer(settings=settings)
    model_cls, model = trainer_obj._build_model(ModelType(model_type), args.window, args.horizon)
    module = TemporalLightningModule(model, learning_rate=args.lr)

    ckpt_dir = RESULTS_DIR / "checkpoints"
    ckpt_dir.mkdir(parents=True, exist_ok=True)

    checkpoint_cb = pl.callbacks.ModelCheckpoint(
        dirpath=str(ckpt_dir),
        filename=f"{model_type}-best",
        monitor="val/loss" if val_ds else "train/loss",
        save_top_k=1,
        mode="min",
        verbose=False,
    )
    early_stop_cb = pl.callbacks.EarlyStopping(
        monitor="val/loss" if val_ds else "train/loss",
        patience=5,
        mode="min",
        verbose=True,
    )
    lr_monitor = pl.callbacks.LearningRateMonitor(logging_interval="epoch")

    callbacks = [checkpoint_cb, early_stop_cb, lr_monitor]

    loggers = []
    if mlflow_available:
        from pytorch_lightning.loggers import MLFlowLogger
        loggers.append(MLFlowLogger(
            experiment_name=f"local/{ctx['target']}/{model_type}",
            tracking_uri=settings.MLFLOW_TRACKING_URI,
        ))

    # ── Optimal DataLoader settings ───────────────────────────────────────────
    import multiprocessing
    num_workers = min(4, multiprocessing.cpu_count() // 2)
    # persistent_workers requires num_workers > 0
    use_persistent = num_workers > 0

# If your custom loggers aren't available, fall back to a local CSV logger
    if not loggers:
        loggers = CSVLogger(save_dir="local_results/logs/", name="gru_forecast")

    pl_trainer = pl.Trainer(
        max_epochs=args.epochs,
        accelerator="gpu" if gpu_available else "cpu",
        devices=1,
        precision=precision,
        callbacks=callbacks,
        logger=loggers,  # Will now safely point to the CSVLogger
        enable_progress_bar=True,
        log_every_n_steps=5,
        gradient_clip_val=1.0,
        deterministic=False,
    )

    loader_kwargs = dict(
        batch_size=args.batch_size,
        num_workers=num_workers,
        persistent_workers=use_persistent,
        pin_memory=gpu_available,
    )
    train_loader = DataLoader(dataset, shuffle=True, **loader_kwargs)
    val_loaders = [DataLoader(val_ds, **loader_kwargs)] if val_ds else []

    t0 = time.time()
    pl_trainer.fit(module, train_loader, *val_loaders)
    elapsed = time.time() - t0

    # ── Load BEST checkpoint (not final epoch) ────────────────────────────────
    best_ckpt = checkpoint_cb.best_model_path
    if best_ckpt and Path(best_ckpt).exists():
        print(f"\n   📂 Loading best checkpoint: {best_ckpt}")
        loaded = TemporalLightningModule.load_from_checkpoint(best_ckpt, model=model)
        model = loaded.model
    else:
        print(f"   ⚠  Best checkpoint not found — using final epoch weights")

    val_loss = float(pl_trainer.callback_metrics.get(
        "val/loss", pl_trainer.callback_metrics.get("train/loss", float("nan"))
    ))

    # Save final weights too
    final_pt = ckpt_dir / f"{model_type}-final.pt"
    torch.save(model.state_dict(), final_pt)

    print(f"\n✅ Training complete in {elapsed:.1f}s  ({elapsed/args.epochs:.1f}s/epoch avg)")
    print(f"   Val loss  : {val_loss:.4f}")
    print(f"   Stopped   : epoch {pl_trainer.current_epoch + 1} / {args.epochs}")
    print(f"   Best ckpt : {best_ckpt or final_pt}")

    return {
        "model": model,
        "module": module,
        "run_id": "local",
        "val_loss": val_loss,
        "ckpt_path": best_ckpt or str(final_pt),
    }


# ─────────────────────────────────────────────────────────────────────────────
# Step 3 — Forecast
# ─────────────────────────────────────────────────────────────────────────────
def step_forecast(ctx: dict, train_ctx: dict, args) -> dict:

    print("\n" + "═" * 60)
    print("  STEP 3 — MULTI-STEP PROBABILISTIC FORECAST")
    print("═" * 60)

    ds = ctx["dataset"]

    test_series = ds.test

    loader_obj = ctx["loader"]

    # Context window
    if len(test_series) < args.window:

        input_series = np.pad(
            test_series,
            (args.window - len(test_series), 0),
            mode="edge",
        )

    else:

        input_series = test_series[-args.window:]

    print(f"\n📈 Input  : {len(input_series)} points")

    print(f"   Horizon : {args.horizon}")

    print(f"   Model   : {args.model}")

    import asyncio

    from forecasting.inference.engine import ForecastEngine

    from shared.schemas.schemas import ModelType

    engine = ForecastEngine(settings=settings)

    # Inject trained model
    if train_ctx.get("model") is not None:

        predictor = _make_predictor(
            args.model,
            train_ctx["model"],
            settings,
        )

        cache_key = f"default:{args.model}"

        engine._model_cache[cache_key] = predictor

    t0 = time.time()

    result = asyncio.run(
        engine.run(
            series=input_series.tolist(),
            horizon=args.horizon,
            model=ModelType(args.model),
            quantiles=[0.1, 0.5, 0.9],
            tenant_id="local",
        )
    )

    elapsed = time.time() - t0

    # Inverse scale
    forecast_orig = loader_obj.inverse_transform(
        np.array(result["forecast"])
    )

    lower_orig = loader_obj.inverse_transform(
        np.array(result["lower_bound"])
    )

    upper_orig = loader_obj.inverse_transform(
        np.array(result["upper_bound"])
    )

    uncertainty = np.array(
        result["uncertainty"]
    )

    forecast_df = pd.DataFrame({

        "step": range(
            1,
            len(forecast_orig) + 1
        ),

        "forecast": forecast_orig,

        "lower_bound": lower_orig,

        "upper_bound": upper_orig,

        "uncertainty": uncertainty,
    })

    out_path = RESULTS_DIR / "forecast_output.csv"

    forecast_df.to_csv(
        out_path,
        index=False,
    )

    print(f"\n✅ Forecast complete in {elapsed:.2f}s")

    print(f"\n💾 Forecast saved → {out_path}")

    return {
        "forecast_df": forecast_df,
        "result": result,
    }

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from pathlib import Path

def plot_forecast(
    ds,
    loader_obj,
    forecast_df,
    output_dir,
    history_points=1000,
):
    """
    Plot historical + forecasted values.
    """

    output_dir = Path(output_dir)

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    # ---------------------------------------------------------
    # Historical data (DENORMALIZED)
    # ---------------------------------------------------------
    hist_values = ds.series[-history_points:]

    hist_values = loader_obj.inverse_transform(
        hist_values
    )

    hist_ts = pd.to_datetime(
        ds.timestamps[-history_points:]
    )

    # ---------------------------------------------------------
    # Forecast data (already denormalized)
    # ---------------------------------------------------------
    pred = forecast_df["forecast"].values

    lower = forecast_df["lower_bound"].values

    upper = forecast_df["upper_bound"].values

    # ---------------------------------------------------------
    # Infer frequency
    # ---------------------------------------------------------
    inferred_freq = pd.infer_freq(hist_ts)

    if inferred_freq is None:
        inferred_freq = "1min"

    # ---------------------------------------------------------
    # Future timestamps
    # ---------------------------------------------------------
    future_ts = pd.date_range(
        start=hist_ts[-1],
        periods=len(pred) + 1,
        freq=inferred_freq,
    )[1:]

    # ---------------------------------------------------------
    # Plot
    # ---------------------------------------------------------
    plt.figure(figsize=(18, 8))

    plt.plot(
        hist_ts,
        hist_values,
        label="Historical",
        linewidth=2,
    )

    plt.plot(
        future_ts,
        pred,
        label="Forecast",
        linewidth=2,
    )

    plt.fill_between(
        future_ts,
        lower,
        upper,
        alpha=0.3,
        label="Confidence Interval",
    )

    plt.axvline(
        x=hist_ts[-1],
        linestyle="--",
        linewidth=2,
    )

    plt.title("Enterprise Temporal Forecast")

    plt.xlabel("Timestamp")

    plt.ylabel(ds.metadata["target_column"])

    plt.grid(True)

    plt.legend()

    out_path = output_dir / "forecast_plot.png"

    plt.savefig(
        out_path,
        bbox_inches="tight",
    )

    plt.close()

    print(f"\n📈 Forecast plot saved → {out_path}")
# ─────────────────────────────────────────────────────────────────────────────
# Step 4 — Anomaly Detection
# ─────────────────────────────────────────────────────────────────────────────

def step_anomaly(ctx: dict, forecast_ctx: dict, args) -> dict:
    print("\n" + "═" * 60)
    print("  STEP 4 — HYBRID ANOMALY DETECTION")
    print("═" * 60)

    ds = ctx["dataset"]
    loader_obj = ctx["loader"]
    forecast = np.array(forecast_ctx["result"]["forecast"])

    # Align actual vs predicted on the test split
    n = min(len(ds.test), len(forecast))
    actual = ds.test[:n]
    predicted = forecast[:n]

    print(f"\n🔍 Comparing {n} actual vs predicted points")
    print(f"   Residual weight      : {settings.ANOMALY_RESIDUAL_WEIGHT}")
    print(f"   Reconstruction weight: {settings.ANOMALY_RECONSTRUCTION_WEIGHT}")
    print(f"   Drift weight         : {settings.ANOMALY_DRIFT_WEIGHT}")
    print(f"   Threshold sigma      : {settings.ANOMALY_THRESHOLD_SIGMA}σ")

    from anomaly.hybrid.parallel_pipeline import ParallelAnomalyPipeline
    pipeline = ParallelAnomalyPipeline()
    result = pipeline.run(actual=actual.tolist(), predicted=predicted.tolist())

    anomalies = [(i, s) for i, (flag, s) in enumerate(
        zip(result["is_anomaly"], result["final_scores"])
    ) if flag]

    anomaly_rate = len(anomalies) / max(n, 1)

    # Build output dataframe (inverse-transformed)
    actual_orig = loader_obj.inverse_transform(actual)
    pred_orig = loader_obj.inverse_transform(predicted)

    anomaly_df = pd.DataFrame({
        "index": range(n),
        "actual": actual_orig,
        "predicted": pred_orig,
        "residual": actual_orig - pred_orig,
        "anomaly_score": result["final_scores"][:n],
        "is_anomaly": result["is_anomaly"][:n],
    })
    out_path = RESULTS_DIR / "anomaly_output.csv"
    anomaly_df.to_csv(out_path, index=False)

    print(f"\n✅ Anomaly detection complete")
    print(f"   Total points  : {n}")
    print(f"   Anomalies     : {len(anomalies)}")
    print(f"   Anomaly rate  : {anomaly_rate:.2%}")
    print(f"   Threshold     : {result['threshold']:.4f}")

    if anomalies:
        print(f"\n   Top anomalies (by score):")
        top = sorted(anomalies, key=lambda x: x[1], reverse=True)[:5]
        print(f"   {'Index':>7}  {'Score':>10}  {'Actual':>12}  {'Predicted':>12}")
        print("   " + "-" * 46)
        for idx, score in top:
            print(f"   {idx:>7}  {score:>10.4f}  "
                  f"{actual_orig[idx]:>12.4f}  {pred_orig[idx]:>12.4f}")

    print(f"\n💾 Anomaly results → {out_path}")
    return {"anomaly_df": anomaly_df, "anomaly_count": len(anomalies), "anomaly_rate": anomaly_rate}


# ─────────────────────────────────────────────────────────────────────────────
# Step 5 — Drift Detection
# ─────────────────────────────────────────────────────────────────────────────

def step_drift(ctx: dict, args) -> dict:
    print("\n" + "═" * 60)
    print("  STEP 5 — DRIFT DETECTION  (train → test)")
    print("═" * 60)

    ds = ctx["dataset"]
    from anomaly.drift.parallel_drift import ParallelDriftDetector
    from shared.schemas.schemas import DriftType

    detector = ParallelDriftDetector()
    results = detector.detect(
        baseline=ds.train.tolist(),
        current=ds.test.tolist(),
        drift_types=[DriftType.data_drift, DriftType.feature_drift,
                     DriftType.distribution_drift, DriftType.concept_drift],
    )
    score = detector.overall_score(results)
    recommendation = detector.recommendation(score, results)

    print(f"\n{'Drift Type':<25} {'Technique':<28} {'Score':>10}  {'Threshold':>10}  {'Detected':>10}")
    print("─" * 88)
    for r in results:
        status = "⚠  YES" if r.detected else "✓  no"
        print(f"{r.drift_type.value:<25} {r.technique:<28} "
              f"{r.score:>10.4f}  {r.threshold:>10.4f}  {status:>10}")

    print(f"\n   Overall drift score : {score:.4f}")
    print(f"   Recommendation      : {recommendation}")

    return {"results": results, "overall_score": score, "recommendation": recommendation}


# ─────────────────────────────────────────────────────────────────────────────
# Step 6 — Final Report
# ─────────────────────────────────────────────────────────────────────────────

def step_report(ctx: dict, train_ctx: dict, forecast_ctx: dict,
                anomaly_ctx: dict, drift_ctx: dict, args):
    print("\n" + "═" * 60)
    print("  FINAL REPORT")
    print("═" * 60)

    ds = ctx["dataset"]
    report = {
        "csv_file": args.csv,
        "target_column": ctx["target"],
        "dataset": {
            "total_points": int(len(ds.series)),
            "train": int(len(ds.train)),
            "val": int(len(ds.val)),
            "test": int(len(ds.test)),
            "stats": ds.stats,
        },
        "training": {
            "model": args.model,
            "epochs": args.epochs,
            "val_loss": train_ctx.get("val_loss"),
        },
        "forecast": {
            "horizon": args.horizon,
            "mean_forecast": float(np.mean(forecast_ctx["result"]["forecast"])),
            "mean_uncertainty": float(np.mean(forecast_ctx["result"]["uncertainty"])),
        },
        "anomaly": {
            "anomaly_count": anomaly_ctx["anomaly_count"],
            "anomaly_rate": anomaly_ctx["anomaly_rate"],
        },
        "drift": {
            "overall_score": drift_ctx["overall_score"],
            "recommendation": drift_ctx["recommendation"],
        },
    }

    report_path = RESULTS_DIR / "report.json"
    report_path.write_text(json.dumps(report, indent=2))

    freq_minutes = pd.to_timedelta(args.resample).total_seconds() / 60
    total_minutes = args.horizon * freq_minutes

    days = int(total_minutes // (24 * 60))
    hours = int((total_minutes % (24 * 60)) // 60)

    horizon_text = f"{days}d {hours}h"

    print(f"""
┌─────────────────────────────────────────────────────────┐
│              TEMPORAL AI — PIPELINE SUMMARY             │
├─────────────────────────────────────────────────────────┤
│  CSV File    : {args.csv:<42} │
│  Target Col  : {ctx['target']:<42} │
│  Total Points: {len(ds.series):<42,} │
├─────────────────────────────────────────────────────────┤
│  MODEL TRAINING                                         │
│  Model       : {args.model:<42} │
│  Val Loss    : {str(round(train_ctx.get('val_loss') or 0, 4)):<42} │
├─────────────────────────────────────────────────────────┤
│  FORECAST                                               │
│     Horizon     : {args.horizon} steps ({horizon_text}) │
│  Mean pred   : {round(float(np.mean(forecast_ctx['result']['forecast'])), 4):<42} │
├─────────────────────────────────────────────────────────┤
│  ANOMALY DETECTION                                      │
│  Anomalies   : {anomaly_ctx['anomaly_count']:<42} │
│  Rate        : {anomaly_ctx['anomaly_rate']:.2%}{'':<38} │
├─────────────────────────────────────────────────────────┤
│  DRIFT DETECTION                                        │
│  Score       : {drift_ctx['overall_score']:.4f}{'':<37} │
└─────────────────────────────────────────────────────────┘
""")
    print(f"📁 All outputs saved to: {RESULTS_DIR.resolve()}/")
    print(f"   forecast_output.csv")
    print(f"   anomaly_output.csv")
    print(f"   report.json")
    print(f"   processed/train.npy, val.npy, test.npy, full.npy")


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _check_mlflow() -> bool:
    try:
        import httpx
        r = httpx.get(f"{settings.MLFLOW_TRACKING_URI}/health", timeout=2)
        return r.status_code == 200
    except Exception:
        return False


def _make_predictor(model_type: str, model, settings):
    """Wrap a trained nn.Module in the correct Predictor shell."""
    import torch
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device).eval()

    class _InlinePredictor:
        def __init__(self, m):
            self.m = m
            self.device = device

        def predict(self, x, horizon):
            import numpy as np
            with torch.no_grad():
                t = torch.tensor(x, dtype=torch.float32).unsqueeze(0)
                if t.dim() == 2 and hasattr(self.m, 'pred_len'):
                    t = t.unsqueeze(-1)   # (1, W, 1) for seq2seq
                t = t.to(self.device)
                out = self.m(t)
                return out.squeeze(0).cpu().numpy()

    return _InlinePredictor(model)


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Enterprise Temporal AI — Local CSV Runner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    # ── Input ──────────────────────────────────────────────────────────────────
    p.add_argument("--csv", required=True, help="Path to input CSV file")
    p.add_argument("--target", default="value", help="Target column name to forecast")
    p.add_argument("--timestamp", default=None, help="Timestamp column name (auto-detected if omitted)")
    p.add_argument("--features", default="", help="Comma-separated covariate columns")

    # ── Preprocessing ──────────────────────────────────────────────────────────
    p.add_argument("--freq", default=None, help="Resample frequency (pandas offset, e.g. 1H, 15T, 1D)")
    p.add_argument("--norm", default="zscore", choices=["zscore", "minmax", "robust", "none"])
    p.add_argument("--window", type=int, default=168, help="Context window size")
    p.add_argument("--horizon", type=int, default=24, help="Forecast horizon steps")

    # ── Training ───────────────────────────────────────────────────────────────
    p.add_argument("--model", default="gru",
                   choices=["gru", "patchtst", "tft", "timesnet", "nbeats"],
                   help="Model to train and forecast with")
    p.add_argument("--epochs", type=int, default=30)
    p.add_argument("--batch-size", type=int, default=32, dest="batch_size")
    p.add_argument("--lr", type=float, default=1e-3, help="Learning rate")
    p.add_argument("--quick", action="store_true",
                   help="Skip training — use untrained model weights for instant results")

    # ── Steps ──────────────────────────────────────────────────────────────────
    p.add_argument(
        "--steps", nargs="+",
        default=["all"],
        choices=["all", "prepare", "train", "forecast", "anomaly", "drift", "report"],
        help="Which steps to run (default: all)",
    )

    p.add_argument(
        "--forecast-days",
        type=int,
        default=None,
        help="Forecast future days automatically",
    )

    p.add_argument(
        "--resample",
        type=str,
        default="1H",
        help="Resample frequency (1min, 5min, 15min, 1H, 1D)"
    )

    # ── Output ─────────────────────────────────────────────────────────────────
    p.add_argument("--out", default="./local_results", help="Output directory")

    return p


def main():
    parser = build_parser()
    args = parser.parse_args()

    global RESULTS_DIR
    RESULTS_DIR = Path(args.out)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    steps = set(args.steps)
    run_all = "all" in steps

    print("\n🚀 Enterprise Temporal AI Platform — Local Runner")
    print(f"   CSV     : {args.csv}")
    print(f"   Target  : {args.target}")
    print(f"   Model   : {args.model}")
    print(f"   Window  : {args.window}  →  Horizon: {args.horizon}")
    print(f"   Quick   : {args.quick}")
    print(f"   Output  : {RESULTS_DIR.resolve()}")
    
        # Auto-convert days → horizon
    if args.forecast_days is not None:

        # Your telemetry is minute-level
        # ---------------------------------------------------------
        # Auto horizon calculation based on resample frequency
        # ---------------------------------------------------------

        freq = str(args.resample).lower()

        if freq in ["1min", "1m", "min", "t"]:
            steps_per_day = 24 * 60

        elif freq in ["5min", "5m"]:
            steps_per_day = 24 * 12

        elif freq in ["15min", "15m"]:
            steps_per_day = 24 * 4

        elif freq in ["30min", "30m"]:
            steps_per_day = 24 * 2

        elif freq in ["1h", "h", "hour"]:
            steps_per_day = 24

        elif freq in ["1d", "d", "day"]:
            steps_per_day = 1

        else:
            print(f"⚠ Unknown resample freq '{args.resample}'")
            print("⚠ Falling back to hourly assumptions")
            steps_per_day = 24

        args.horizon = args.forecast_days * steps_per_day

        print(
            f"\n🕒 Forecast horizon auto-set:"
            f" {args.forecast_days} days → {args.horizon} steps"
        )
        print(
            f"\n🕒 Forecast horizon auto-set:"
            f" {args.forecast_days} days"
            f" → {args.horizon} steps"
        )

    # ── Run pipeline ──────────────────────────────────────────────────────────
    ctx, train_ctx, forecast_ctx, anomaly_ctx, drift_ctx = {}, {}, {}, {}, {}

    if run_all or "prepare" in steps:
        ctx = step_prepare(args)

    if run_all or "train" in steps:
        if not ctx:
            ctx = step_prepare(args)
        train_ctx = step_train(ctx, args)

    if run_all or "forecast" in steps:
        if not ctx:
            ctx = step_prepare(args)
        if not train_ctx:
            train_ctx = step_train(ctx, args)
        forecast_ctx = step_forecast(ctx, train_ctx, args)

    if run_all or "anomaly" in steps:
        if not forecast_ctx:
            print("⚠  Anomaly step requires forecast step — running forecast first")
            if not ctx:
                ctx = step_prepare(args)
            if not train_ctx:
                train_ctx = step_train(ctx, args)
            forecast_ctx = step_forecast(ctx, train_ctx, args)
        anomaly_ctx = step_anomaly(ctx, forecast_ctx, args)

    if run_all or "drift" in steps:
        if not ctx:
            ctx = step_prepare(args)
        drift_ctx = step_drift(ctx, args)

    if run_all or "report" in steps:
        if all([ctx, train_ctx, forecast_ctx, anomaly_ctx, drift_ctx]):
            step_report(ctx, train_ctx, forecast_ctx, anomaly_ctx, drift_ctx, args)

    if forecast_ctx:
        plot_forecast(
            ds=ctx["dataset"],
            loader_obj=ctx["loader"],
            forecast_df=forecast_ctx["forecast_df"],
            output_dir=RESULTS_DIR,
        )

    print("\n✨ Done.\n")


if __name__ == "__main__":
    main()
