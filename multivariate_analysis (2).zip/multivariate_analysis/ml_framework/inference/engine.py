"""
inference.py — Production inference engine for real-time and batch prediction.

Capabilities
------------
* Real-time (single-sample) prediction with sub-millisecond overhead.
* Batch inference with automatic chunking for memory efficiency.
* Streaming prediction over live data windows.
* Online / incremental retraining hook for concept drift adaptation.
* Model registry pattern: swap models without changing the inference contract.
* Thread-safe prediction serving suitable for REST API backends.
"""

from __future__ import annotations

import logging
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from pandas import DataFrame

from ..core.config import FrameworkConfig
from ..core.preprocessing import PreprocessingPipeline

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Inference result container
# ---------------------------------------------------------------------------

@dataclass
class PredictionResult:
    """Structured result returned by the inference engine."""
    predictions:   np.ndarray               # (n_samples, n_targets)
    target_names:  List[str]
    timestamps:    Optional[np.ndarray]      # wall-clock or data timestamps
    latency_ms:    float = 0.0
    model_version: str  = "v1"
    metadata:      Dict[str, Any] = field(default_factory=dict)

    def to_dataframe(self) -> DataFrame:
        df = DataFrame(self.predictions, columns=self.target_names)
        if self.timestamps is not None:
            df.insert(0, "timestamp", self.timestamps)
        return df


# ---------------------------------------------------------------------------
# Model registry — hot-swappable model store
# ---------------------------------------------------------------------------

class ModelRegistry:
    """
    Thread-safe registry that holds multiple named model versions.

    Supports atomic swapping so a new model can be promoted to 'active'
    without downtime.

    Usage
    -----
    >>> reg = ModelRegistry()
    >>> reg.register("v1", tree_model)
    >>> reg.set_active("v1")
    >>> model = reg.get_active()
    """

    def __init__(self) -> None:
        self._models: Dict[str, Any] = {}
        self._active: Optional[str]  = None
        self._lock   = threading.RLock()

    def register(self, version: str, model: Any) -> None:
        with self._lock:
            self._models[version] = model
            logger.info("Model '%s' registered.", version)

    def set_active(self, version: str) -> None:
        with self._lock:
            if version not in self._models:
                raise KeyError(f"Model '{version}' not found in registry.")
            self._active = version
            logger.info("Active model set to '%s'.", version)

    def get_active(self) -> Tuple[str, Any]:
        with self._lock:
            if self._active is None:
                raise RuntimeError("No active model set.")
            return self._active, self._models[self._active]

    def list_versions(self) -> List[str]:
        with self._lock:
            return list(self._models.keys())


# ---------------------------------------------------------------------------
# Core inference engine
# ---------------------------------------------------------------------------

class InferenceEngine:
    """
    Applies the preprocessing pipeline and dispatches to the active model.

    Supports three prediction modes:
      - batch    : offline inference on a full DataFrame
      - realtime : low-latency inference on a single row / small buffer
      - streaming: continuous prediction over a sliding window buffer

    Parameters
    ----------
    config : FrameworkConfig
    preprocessor : fitted PreprocessingPipeline
    registry : ModelRegistry with at least one active model
    """

    def __init__(
        self,
        config: FrameworkConfig,
        preprocessor: PreprocessingPipeline,
        registry: ModelRegistry,
    ) -> None:
        self.cfg          = config
        self.preprocessor = preprocessor
        self.registry     = registry
        self._targets     = config.targets

    # ------------------------------------------------------------------
    # Batch inference
    # ------------------------------------------------------------------

    def predict_batch(
        self,
        df: DataFrame,
        chunk_size: int = 10_000,
    ) -> PredictionResult:
        """
        Run inference on a DataFrame in memory-efficient chunks.

        Parameters
        ----------
        df : DataFrame — must have the same schema as training data.
        chunk_size : rows per chunk (tune based on available RAM).

        Returns
        -------
        PredictionResult with predictions of shape (N, n_targets).
        """
        t0 = time.perf_counter()
        all_preds = []

        for start in range(0, len(df), chunk_size):
            chunk = df.iloc[start : start + chunk_size]
            X, _, _ = self.preprocessor.transform(chunk)
            _, model = self.registry.get_active()
            preds = model.predict(X)
            all_preds.append(preds)

        predictions  = np.concatenate(all_preds, axis=0)
        latency_ms   = (time.perf_counter() - t0) * 1000

        logger.info(
            "Batch inference: %d samples in %.1f ms (%.1f μs/sample)",
            len(df), latency_ms, latency_ms * 1000 / max(len(df), 1),
        )
        return PredictionResult(
            predictions=predictions,
            target_names=self._targets,
            timestamps=df.index.values if isinstance(df.index, pd.DatetimeIndex) else None,
            latency_ms=latency_ms,
            model_version=self.registry.get_active()[0],
        )

    # ------------------------------------------------------------------
    # Real-time inference (single sample)
    # ------------------------------------------------------------------

    def predict_realtime(
        self,
        row: Dict[str, float],
        timestamp: Optional[pd.Timestamp] = None,
    ) -> PredictionResult:
        """
        Ultra-low-latency single-sample prediction.

        Parameters
        ----------
        row : dict of {feature_name: value}
        timestamp : optional event timestamp

        Returns
        -------
        PredictionResult with predictions of shape (1, n_targets).
        """
        t0 = time.perf_counter()
        df = DataFrame([row])
        if timestamp:
            df.index = pd.DatetimeIndex([timestamp])

        X, _, _ = self.preprocessor.transform(df)
        _, model = self.registry.get_active()
        preds = model.predict(X)

        latency_ms = (time.perf_counter() - t0) * 1000
        return PredictionResult(
            predictions=preds,
            target_names=self._targets,
            timestamps=np.array([timestamp or pd.Timestamp.now()]),
            latency_ms=latency_ms,
            model_version=self.registry.get_active()[0],
        )

    # ------------------------------------------------------------------
    # Streaming inference (sliding window)
    # ------------------------------------------------------------------

    def predict_stream(
        self,
        data_stream,          # iterable of (timestamp, dict) tuples
        on_prediction: Optional[Callable[[PredictionResult], None]] = None,
        flush_interval: int = 1,   # predict every N new rows
    ) -> List[PredictionResult]:
        """
        Consume a streaming data source and emit predictions continuously.

        Parameters
        ----------
        data_stream : iterable yielding (timestamp, dict[feature, value])
        on_prediction : callback called with each PredictionResult
        flush_interval : emit a prediction every N new observations

        Returns
        -------
        list of all PredictionResults emitted during the stream
        """
        buffer: deque = deque(maxlen=self.cfg.temporal.window_size)
        results: List[PredictionResult] = []
        n_since_last = 0

        for ts, row in data_stream:
            buffer.append({"timestamp": ts, **row})
            n_since_last += 1

            if len(buffer) == buffer.maxlen and n_since_last >= flush_interval:
                buf_df = DataFrame(list(buffer)).set_index("timestamp")
                result = self.predict_batch(buf_df)
                # Only return the last prediction (most recent in window)
                last = PredictionResult(
                    predictions=result.predictions[[-1]],
                    target_names=self._targets,
                    timestamps=np.array([ts]),
                    latency_ms=result.latency_ms,
                    model_version=result.model_version,
                )
                results.append(last)
                if on_prediction:
                    on_prediction(last)
                n_since_last = 0

        return results


# ---------------------------------------------------------------------------
# Incremental retraining hook
# ---------------------------------------------------------------------------

class OnlineRetrainer:
    """
    Lightweight wrapper that triggers model retraining when drift is detected.

    This is an opinionated, simple implementation — for production systems,
    integrate with MLflow / Ray / Vertex AI for orchestration.

    Drift detection
    ---------------
    We monitor the rolling mean prediction error on a holdout buffer.
    When it exceeds drift_threshold × baseline_error, retraining is triggered.

    Parameters
    ----------
    engine : InferenceEngine
    train_fn : callable() → new fitted model
        Should return an object with .predict(X) and be registered automatically.
    drift_threshold : float
        Trigger retrain if rolling error / baseline_error > drift_threshold.
    buffer_size : int
        Number of recent (X, y_true) pairs to keep for drift monitoring.
    """

    def __init__(
        self,
        engine: InferenceEngine,
        train_fn: Callable,
        drift_threshold: float = 1.5,
        buffer_size: int = 1000,
    ) -> None:
        self.engine          = engine
        self.train_fn        = train_fn
        self.drift_threshold = drift_threshold
        self._buffer_X:  deque = deque(maxlen=buffer_size)
        self._buffer_y:  deque = deque(maxlen=buffer_size)
        self._baseline_mae: Optional[float] = None
        self._n_retrains: int = 0
        self._lock = threading.Lock()

    def observe(self, X: np.ndarray, y_true: np.ndarray) -> bool:
        """
        Record a new observation with known ground truth.
        Triggers retraining if drift is detected.

        Returns True if retraining was triggered.
        """
        with self._lock:
            self._buffer_X.extend(X.tolist())
            self._buffer_y.extend(y_true.tolist())

            if len(self._buffer_X) < 100:
                return False   # not enough data yet

            # Compute rolling MAE on the buffer
            X_buf = np.array(list(self._buffer_X))
            y_buf = np.array(list(self._buffer_y))
            _, model = self.engine.registry.get_active()
            preds    = model.predict(X_buf)
            mae      = float(np.mean(np.abs(y_buf - preds)))

            if self._baseline_mae is None:
                self._baseline_mae = mae
                return False

            drift_ratio = mae / (self._baseline_mae + 1e-8)
            logger.debug("Drift monitor: MAE=%.4f  baseline=%.4f  ratio=%.2f",
                         mae, self._baseline_mae, drift_ratio)

            if drift_ratio > self.drift_threshold:
                logger.warning(
                    "Drift detected (ratio=%.2f > %.2f). Triggering retrain.",
                    drift_ratio, self.drift_threshold,
                )
                self._retrain()
                return True
        return False

    def _retrain(self) -> None:
        """Call the user-supplied training function and register the new model."""
        new_model = self.train_fn()
        version   = f"v{self._n_retrains + 2}"
        self.engine.registry.register(version, new_model)
        self.engine.registry.set_active(version)
        self._n_retrains += 1
        # Reset baseline after retraining
        self._baseline_mae = None
        logger.info("Retrain complete. Active model promoted to '%s'.", version)
