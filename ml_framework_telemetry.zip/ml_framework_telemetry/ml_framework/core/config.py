"""
config.py — Centralized configuration for the ML framework.

Updated for long-format telemetry schema:
  ts, asset_id, telemetry_1, telemetry_2, ... telemetry_N

Changes from original
---------------------
* TemporalConfig.timestamp_col  : default changed "timestamp" → "ts"
* DataSourceConfig.timestamp_col: default changed "timestamp" → "ts"
* DataSourceConfig.asset_id_col : NEW — identifies the asset/device column
* DataSourceConfig.telemetry_prefix: NEW — auto-detect telemetry columns by prefix
* DataSourceConfig.numerical_cols: empty list now means "auto-detect all
  telemetry_* columns after pivot" instead of "no numeric columns"

Everything else is unchanged from the original.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Literal, Optional, Tuple


# ---------------------------------------------------------------------------
# Data / ingestion
# ---------------------------------------------------------------------------

@dataclass
class TemporalConfig:
    """Controls how multi-frequency, asynchronous time-series are aligned."""
    timestamp_col: str = "ts"            # ← was "timestamp"
    resample_freq: str = "1min"          # pandas offset alias: '1min', '5min', '1H' …
    aggregation_method: str = "mean"     # mean | last | max | min | sum | first
    interpolation_method: str = "linear" # linear | ffill | bfill | cubic | none
    max_gap_fill_periods: int = 10       # never fill gaps larger than this many periods
    window_size: int = 32                # look-back window for sequence models
    horizon: int = 1                     # how many steps ahead to predict
    stride: int = 1                      # stride when sliding the window


@dataclass
class DataSourceConfig:
    """
    Describes a single raw data source in long-format telemetry layout.

    Long-format schema
    ------------------
    The framework now expects each source to have:
      - a timestamp column  (default: "ts")
      - an asset identifier (default: "asset_id")
      - one or more telemetry columns (default prefix: "telemetry_")

    After loading, the pipeline pivots long → wide automatically:
      telemetry_1__asset_A, telemetry_1__asset_B, telemetry_2__asset_A, …

    numerical_cols
    --------------
    Leave empty (default) to auto-detect every column whose name starts
    with `telemetry_prefix` after pivoting. Supply explicit names to
    restrict which channels are used as features.
    """
    name: str
    path: Optional[str] = None           # local file path or URI

    # Timestamp column — updated default to match new schema
    timestamp_col: str = "ts"            # ← was "timestamp"

    # Asset identifier column — NEW field
    asset_id_col: str = "asset_id"       # column that identifies each asset/device

    # Telemetry column auto-detection — NEW field
    # Columns whose names start with this prefix are treated as sensor readings.
    # Used only when numerical_cols is empty.
    telemetry_prefix: str = "telemetry_"

    frequency: Optional[str] = None      # native sampling frequency, e.g. '5s'

    # Feature columns — leave empty to auto-detect all telemetry_* columns
    numerical_cols: List[str] = field(default_factory=list)
    categorical_cols: List[str] = field(default_factory=list)
    target_cols: List[str] = field(default_factory=list)

    # Subsystem / sensor group tag (used for column prefixing after pivot)
    subsystem: str = "sensor"


# ---------------------------------------------------------------------------
# Pre-processing
# ---------------------------------------------------------------------------

@dataclass
class PreprocessingConfig:
    scaler: Literal["standard", "minmax", "robust", "none"] = "robust"
    # categorical encoding strategy
    encoder: Literal["ordinal", "onehot", "target", "none"] = "ordinal"
    # missing value imputation
    imputer: Literal["mean", "median", "knn", "iterative", "none"] = "median"
    knn_neighbors: int = 5
    # dimensionality reduction applied AFTER scaling
    dim_reduction: Literal["pca", "umap", "none"] = "none"
    pca_variance_threshold: float = 0.95   # keep components explaining 95% of variance
    umap_n_components: int = 32
    # automated feature engineering
    auto_feature_engineering: bool = True
    lag_periods: List[int] = field(default_factory=lambda: [1, 3, 6, 12])
    rolling_windows: List[int] = field(default_factory=lambda: [4, 8, 16])
    add_time_features: bool = True         # hour-of-day, day-of-week, etc.


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

@dataclass
class TreeModelConfig:
    model_type: Literal["lgbm", "xgb", "rf"] = "lgbm"
    n_estimators: int = 500
    max_depth: int = -1        # -1 means no limit (LightGBM default)
    learning_rate: float = 0.05
    subsample: float = 0.8
    colsample_bytree: float = 0.8
    reg_alpha: float = 0.1
    reg_lambda: float = 1.0
    early_stopping_rounds: int = 50
    n_jobs: int = -1
    # multi-output strategy: "chain" (regressor chains) or "direct" (separate models)
    multi_output_strategy: Literal["chain", "direct"] = "direct"


@dataclass
class DeepModelConfig:
    architecture: Literal["lstm", "gru", "tcn", "transformer", "hybrid"] = "transformer"
    # Sequence encoder shared across all targets
    hidden_size: int = 128
    num_layers: int = 3
    num_heads: int = 8             # Transformer only
    dropout: float = 0.1
    ff_dim: int = 256              # Transformer feed-forward dim
    # Static branch (non-temporal features)
    static_hidden_sizes: List[int] = field(default_factory=lambda: [64, 64])
    # Shared decoder before target-specific heads
    shared_decoder_sizes: List[int] = field(default_factory=lambda: [128, 64])
    activation: str = "gelu"
    batch_size: int = 256
    max_epochs: int = 100
    learning_rate: float = 1e-3
    weight_decay: float = 1e-4
    patience: int = 15             # early stopping
    gradient_clip: float = 1.0
    use_amp: bool = True           # automatic mixed precision
    device: str = "auto"          # "auto" | "cpu" | "cuda" | "mps"


@dataclass
class EnsembleConfig:
    """Blend tree and deep predictions."""
    use_ensemble: bool = False
    weights: Optional[Dict[str, float]] = None   # {"tree": 0.4, "deep": 0.6}
    stacking: bool = False                        # learn blending weights via meta-model


# ---------------------------------------------------------------------------
# Training / evaluation
# ---------------------------------------------------------------------------

@dataclass
class TrainingConfig:
    test_fraction: float = 0.15
    val_fraction: float = 0.15
    # temporal cross-validation
    n_cv_folds: int = 5
    cv_strategy: Literal["expanding", "sliding"] = "expanding"
    # metrics computed for every target
    metrics: List[str] = field(default_factory=lambda: [
        "mae", "rmse", "mape", "r2", "smape"
    ])
    seed: int = 42


# ---------------------------------------------------------------------------
# Explainability
# ---------------------------------------------------------------------------

@dataclass
class ExplainabilityConfig:
    enabled: bool = True
    backend: Literal["shap", "captum", "both"] = "shap"
    n_background_samples: int = 200     # SHAP background dataset size
    n_explain_samples: int = 50         # local explanations to compute
    plot_top_k_features: int = 20


# ---------------------------------------------------------------------------
# Anomaly detection
# ---------------------------------------------------------------------------

@dataclass
class AnomalyConfig:
    """
    Configuration for the anomaly detection subsystem.

    Detectors
    ---------
    Five detectors can be toggled independently and combined via
    weighted rank aggregation in the ensemble.

      use_isolation_forest   — tree-based, fast, good for high dimensions
      use_lof                — density-based, detects local anomalies
      use_statistical        — Z-score + IQR + CUSUM, fully interpretable
      use_autoencoder        — reconstruction error, needs PyTorch
      use_residual_detection — flags anomalous prediction errors

    Weights
    -------
    'weights' dict controls how much each detector contributes to the
    ensemble score. All detectors default to weight=1.0 (equal voting).
    Increase a weight if that detector is more trusted for your domain.
    Example: {"isolation_forest": 2.0, "statistical": 1.0, "lof": 0.5}

    Severity thresholds
    -------------------
    severity_warning_pct  : samples above this percentile → "warning"
    severity_critical_pct : samples above this percentile → "critical"
    """
    enabled:                bool  = True

    # Which detectors to run
    use_isolation_forest:   bool  = True
    use_lof:                bool  = True
    use_statistical:        bool  = True
    use_autoencoder:        bool  = False   # requires PyTorch; opt-in
    use_residual_detection: bool  = True    # requires a fitted predictive model

    # Shared contamination estimate (fraction of training data expected anomalous)
    contamination:          float = 0.05

    # Ensemble weights — {detector_name: weight}
    weights: Dict[str, float] = field(default_factory=lambda: {
        "isolation_forest": 1.0,
        "lof":              1.0,
        "statistical":      1.0,
        "autoencoder":      1.5,   # slightly higher when enabled
    })

    # Isolation Forest hyperparameters
    if_n_estimators:        int   = 200

    # LOF hyperparameters
    lof_n_neighbors:        int   = 20

    # Statistical detector hyperparameters
    z_threshold:            float = 3.5
    iqr_multiplier:         float = 3.0
    cusum_slack:            float = 0.5    # in σ units
    cusum_h:                float = 5.0   # CUSUM decision threshold in σ

    # Autoencoder hyperparameters
    ae_hidden_dims:         List[int] = field(default_factory=lambda: [64, 32])
    ae_bottleneck_dim:      int   = 16
    ae_epochs:              int   = 50
    ae_batch_size:          int   = 256

    # Severity thresholds (percentile of ensemble score)
    severity_warning_pct:   float = 0.70   # top 30% → warning
    severity_critical_pct:  float = 0.90   # top 10% → critical


# ---------------------------------------------------------------------------
# Master config
# ---------------------------------------------------------------------------

@dataclass
class FrameworkConfig:
    """Single entry-point that drives the entire pipeline."""
    project_name: str = "ml_framework"
    output_dir: str = "./outputs"

    data_sources: List[DataSourceConfig] = field(default_factory=list)
    targets: List[str] = field(default_factory=list)   # post-pivot column names

    temporal: TemporalConfig = field(default_factory=TemporalConfig)
    preprocessing: PreprocessingConfig = field(default_factory=PreprocessingConfig)
    tree_model: TreeModelConfig = field(default_factory=TreeModelConfig)
    deep_model: DeepModelConfig = field(default_factory=DeepModelConfig)
    ensemble: EnsembleConfig = field(default_factory=EnsembleConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)
    explainability: ExplainabilityConfig = field(default_factory=ExplainabilityConfig)
    anomaly: AnomalyConfig = field(default_factory=AnomalyConfig)

    # pipeline mode: "tree" | "deep" | "both" | "ensemble"
    mode: Literal["tree", "deep", "both", "ensemble"] = "both"
    # prediction type: "static" (no temporal structure) or "temporal"
    prediction_type: Literal["static", "temporal"] = "temporal"
