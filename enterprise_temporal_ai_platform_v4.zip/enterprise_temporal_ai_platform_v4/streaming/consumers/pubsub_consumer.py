"""
Enterprise Temporal AI Platform — Pub/Sub Streaming Consumer

Pipeline:
  Pub/Sub → Streaming Consumer → Redis Buffer → Feature Store
         → Inference Service → Anomaly Service → LLM Explanation
         → Alert Engine → Dashboard
"""

from __future__ import annotations

import asyncio
import json
import time
from typing import Any, Dict, Optional

import httpx
import redis.asyncio as aioredis
from google.cloud import pubsub_v1

from shared.config.settings import settings
from shared.logging.logger import configure_logging, get_logger
from shared.schemas.schemas import StreamingEvent, IngestResponse

configure_logging("streaming-consumer", settings.LOG_LEVEL, settings.is_production)
log = get_logger("streaming.consumer")


class RedisStreamBuffer:
    """
    Circular buffer in Redis for incoming time-series events.
    Triggers inference when buffer reaches a configured threshold.
    """

    def __init__(self, redis_client: aioredis.Redis, buffer_size: int = 168):
        self.redis = redis_client
        self.buffer_size = buffer_size

    async def push(self, tenant_id: str, series_id: str, value: float) -> int:
        key = f"{settings.TENANT_NAMESPACE_PREFIX}:{tenant_id}:buffer:{series_id}"
        pipe = self.redis.pipeline()
        pipe.rpush(key, value)
        pipe.ltrim(key, -self.buffer_size, -1)
        pipe.expire(key, settings.REDIS_BUFFER_TTL)
        await pipe.execute()
        return await self.redis.llen(key)

    async def get_series(self, tenant_id: str, series_id: str) -> list[float]:
        key = f"{settings.TENANT_NAMESPACE_PREFIX}:{tenant_id}:buffer:{series_id}"
        raw = await self.redis.lrange(key, 0, -1)
        return [float(v) for v in raw]

    async def buffer_length(self, tenant_id: str, series_id: str) -> int:
        key = f"{settings.TENANT_NAMESPACE_PREFIX}:{tenant_id}:buffer:{series_id}"
        return await self.redis.llen(key)


class TemporalStreamingConsumer:
    """
    Subscribes to a Google Pub/Sub subscription and processes
    incoming time-series events in real time.
    """

    def __init__(
        self,
        project_id: str = None,
        subscription_id: str = None,
        inference_trigger_threshold: int = 120,
    ):
        self.project_id = project_id or settings.GOOGLE_CLOUD_PROJECT
        self.subscription_id = subscription_id or settings.PUBSUB_SUBSCRIPTION
        self.trigger_threshold = inference_trigger_threshold
        self._redis: Optional[aioredis.Redis] = None
        self._http: Optional[httpx.AsyncClient] = None
        self._buffer: Optional[RedisStreamBuffer] = None
        self._running = False

    async def start(self):
        """Initialise connections and begin consuming."""
        self._redis = aioredis.from_url(settings.REDIS_URL, decode_responses=True)
        self._http = httpx.AsyncClient(timeout=10.0)
        self._buffer = RedisStreamBuffer(self._redis)
        self._running = True
        log.info("consumer.started", project=self.project_id, sub=self.subscription_id)
        await self._consume_loop()

    async def stop(self):
        self._running = False
        if self._redis:
            await self._redis.aclose()
        if self._http:
            await self._http.aclose()
        log.info("consumer.stopped")

    async def _consume_loop(self):
        """Main consumption loop using asyncio Pub/Sub subscriber."""
        subscriber = pubsub_v1.SubscriberClient()
        subscription_path = subscriber.subscription_path(self.project_id, self.subscription_id)

        loop = asyncio.get_event_loop()

        def _callback(message: pubsub_v1.types.PubsubMessage):
            """Synchronous callback; schedules async processing."""
            try:
                data = json.loads(message.data.decode("utf-8"))
                event = StreamingEvent(**data)
                asyncio.run_coroutine_threadsafe(
                    self._process_event(event),
                    loop,
                )
                message.ack()
            except Exception as exc:
                log.error("consumer.message_error", exc=str(exc))
                message.nack()

        future = subscriber.subscribe(subscription_path, callback=_callback)
        log.info("consumer.subscribed", path=subscription_path)

        try:
            while self._running:
                await asyncio.sleep(1.0)
        except KeyboardInterrupt:
            future.cancel()
        finally:
            subscriber.close()

    async def _process_event(self, event: StreamingEvent):
        """
        Full streaming pipeline for a single event:
        1. Write to Redis buffer
        2. Enrich with feature store
        3. Trigger inference if threshold reached
        4. Run anomaly detection on the result
        5. Cache result + fire alert if anomaly
        """
        t0 = time.perf_counter()

        # Step 1: Buffer
        buf_len = await self._buffer.push(
            event.tenant_id, event.series_id, event.value
        )

        # Step 2: Always publish to raw events stream
        raw_key = f"{settings.TENANT_NAMESPACE_PREFIX}:{event.tenant_id}:events:{event.series_id}"
        await self._redis.rpush(
            raw_key,
            json.dumps({"ts": event.timestamp.isoformat(), "value": event.value}),
        )
        await self._redis.ltrim(raw_key, -1000, -1)

        trigger_inference = buf_len >= self.trigger_threshold

        if trigger_inference:
            series = await self._buffer.get_series(event.tenant_id, event.series_id)
            await self._trigger_inference(event, series)

        elapsed = (time.perf_counter() - t0) * 1000
        log.info(
            "event.processed",
            tenant=event.tenant_id,
            series=event.series_id,
            buf_len=buf_len,
            trigger=trigger_inference,
            elapsed_ms=round(elapsed, 2),
        )

    async def _trigger_inference(self, event: StreamingEvent, series: list[float]):
        """Call forecast service and then pipe result to anomaly service."""
        # ── Forecast ──────────────────────────────────────────────────────────
        try:
            forecast_payload = {
                "tenant_id": event.tenant_id,
                "user_id": "streaming-consumer",
                "series": series,
                "horizon": settings.FORECAST_HORIZON,
                "model": "ensemble",
            }
            forecast_resp = await self._http.post(
                f"{settings.FORECAST_SERVICE_URL}/v1/forecast",
                json=forecast_payload,
                headers={"X-Tenant-ID": event.tenant_id},
            )
            forecast_resp.raise_for_status()
            forecast_data = forecast_resp.json()

            # Cache latest inference result
            latest_key = (
                f"{settings.TENANT_NAMESPACE_PREFIX}:{event.tenant_id}"
                f":latest:{event.series_id}"
            )
            await self._redis.setex(
                latest_key,
                settings.REDIS_BUFFER_TTL,
                json.dumps(forecast_data),
            )

        except Exception as exc:
            log.error("inference.forecast_failed", exc=str(exc), series=event.series_id)
            return

        # ── Anomaly Detection ─────────────────────────────────────────────────
        try:
            predicted = forecast_data.get("forecast", [])[:len(series)]
            actual = series[-len(predicted):] if predicted else []

            if not actual or not predicted:
                return

            anomaly_payload = {
                "tenant_id": event.tenant_id,
                "user_id": "streaming-consumer",
                "actual": actual,
                "predicted": predicted,
                "return_explanations": True,
            }
            anomaly_resp = await self._http.post(
                f"{settings.ANOMALY_SERVICE_URL}/v1/detect",
                json=anomaly_payload,
                headers={"X-Tenant-ID": event.tenant_id},
            )
            anomaly_resp.raise_for_status()
            anomaly_data = anomaly_resp.json()

            # Fire alert if anomalies detected
            if anomaly_data.get("anomaly_count", 0) > 0:
                await self._fire_alert(event, anomaly_data)

        except Exception as exc:
            log.error("inference.anomaly_failed", exc=str(exc), series=event.series_id)

    async def _fire_alert(self, event: StreamingEvent, anomaly_data: Dict[str, Any]):
        """Push alert to Redis alerts list for the tenant."""
        alert = {
            "tenant_id": event.tenant_id,
            "series_id": event.series_id,
            "timestamp": event.timestamp.isoformat(),
            "anomaly_count": anomaly_data["anomaly_count"],
            "anomaly_rate": anomaly_data["anomaly_rate"],
            "max_score": max(anomaly_data.get("scores", [0])),
            "llm_summary": anomaly_data.get("llm_summary"),
            "severity": _derive_severity(anomaly_data.get("anomaly_rate", 0)),
        }
        alert_key = f"{settings.TENANT_NAMESPACE_PREFIX}:{event.tenant_id}:alerts"
        await self._redis.lpush(alert_key, json.dumps(alert))
        await self._redis.ltrim(alert_key, 0, 999)  # keep last 1000 alerts

        log.info(
            "alert.fired",
            tenant=event.tenant_id,
            series=event.series_id,
            count=anomaly_data["anomaly_count"],
        )


def _derive_severity(anomaly_rate: float) -> str:
    if anomaly_rate > 0.5:
        return "critical"
    if anomaly_rate > 0.2:
        return "high"
    if anomaly_rate > 0.05:
        return "medium"
    return "low"


# ── Entry point ───────────────────────────────────────────────────────────────

async def main():
    consumer = TemporalStreamingConsumer()
    try:
        await consumer.start()
    except KeyboardInterrupt:
        await consumer.stop()


if __name__ == "__main__":
    asyncio.run(main())
