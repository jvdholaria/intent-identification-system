"""
Enterprise Temporal AI Platform — GRU Seq2Seq Predictor

Fallback model for when primary models are unavailable.
Encoder-decoder architecture with attention bridge.
"""

from __future__ import annotations

from typing import Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from shared.config.settings import Settings
from shared.logging.logger import get_logger

log = get_logger("models.gru")


class GRUEncoder(nn.Module):
    def __init__(self, input_size: int, hidden_size: int, num_layers: int, dropout: float):
        super().__init__()
        self.gru = nn.GRU(
            input_size, hidden_size, num_layers,
            batch_first=True, dropout=dropout if num_layers > 1 else 0.0,
        )

    def forward(self, x: torch.Tensor):
        # x: (batch, seq_len, input_size)
        outputs, hidden = self.gru(x)
        return outputs, hidden   # outputs: (batch, seq_len, hidden)


class AttentionBridge(nn.Module):
    """Additive attention (Bahdanau-style) connecting encoder→decoder."""

    def __init__(self, hidden_size: int):
        super().__init__()
        self.w1 = nn.Linear(hidden_size, hidden_size, bias=False)
        self.w2 = nn.Linear(hidden_size, hidden_size, bias=False)
        self.v = nn.Linear(hidden_size, 1, bias=False)

    def forward(
        self,
        decoder_state: torch.Tensor,   # (batch, 1, hidden)
        encoder_outputs: torch.Tensor, # (batch, seq_len, hidden)
    ) -> torch.Tensor:
        score = self.v(
            torch.tanh(self.w1(encoder_outputs) + self.w2(decoder_state))
        )  # (batch, seq_len, 1)
        weights = F.softmax(score, dim=1)             # (batch, seq_len, 1)
        context = (weights * encoder_outputs).sum(1)  # (batch, hidden)
        return context


class GRUDecoder(nn.Module):
    def __init__(self, hidden_size: int, output_size: int, num_layers: int, dropout: float):
        super().__init__()
        self.gru = nn.GRU(
            hidden_size + output_size, hidden_size, num_layers,
            batch_first=True, dropout=dropout if num_layers > 1 else 0.0,
        )
        self.attention = AttentionBridge(hidden_size)
        self.fc = nn.Linear(hidden_size * 2, output_size)
        self.dropout = nn.Dropout(dropout)

    def forward_step(
        self,
        prev_output: torch.Tensor,     # (batch, 1, output_size)
        hidden: torch.Tensor,
        encoder_outputs: torch.Tensor, # (batch, seq_len, hidden)
    ):
        context = self.attention(hidden[-1:].permute(1, 0, 2), encoder_outputs)  # (batch, hidden)
        gru_in = torch.cat([prev_output.squeeze(1), context], dim=-1).unsqueeze(1)
        out, hidden = self.gru(gru_in, hidden)
        pred = self.fc(torch.cat([out.squeeze(1), context], dim=-1))   # (batch, output_size)
        return pred, hidden


class GRUSeq2Seq(nn.Module):
    """
    GRU encoder-decoder with attention, used as the fallback forecasting model.
    """

    def __init__(
        self,
        input_size: int = 1,
        hidden_size: int = 256,
        output_size: int = 1,
        num_layers: int = 2,
        dropout: float = 0.1,
        pred_len: int = 120,
    ):
        super().__init__()
        self.pred_len = pred_len
        self.encoder = GRUEncoder(input_size, hidden_size, num_layers, dropout)
        self.decoder = GRUDecoder(hidden_size, output_size, num_layers, dropout)

    def forward(self, x: torch.Tensor, teacher_forcing_ratio: float = 0.0) -> torch.Tensor:
        # x: (batch, seq_len, 1)
        encoder_outputs, hidden = self.encoder(x)

        preds = []
        decoder_input = x[:, -1:, :]  # last observed value as seed

        for _ in range(self.pred_len):
            pred, hidden = self.decoder.forward_step(decoder_input, hidden, encoder_outputs)
            preds.append(pred)
            decoder_input = pred.unsqueeze(1)

        return torch.stack(preds, dim=1).squeeze(-1)   # (batch, pred_len)


import logging
from typing import Optional

import torch
import torch._dynamo

from shared.config.settings import Settings

log = logging.getLogger(__name__)

# Prevent TorchDynamo from crashing inference
torch._dynamo.config.suppress_errors = True


class GRUPredictor:

    def __init__(self, settings: Settings):

        self.settings = settings

        self.device = torch.device(
            "cuda" if torch.cuda.is_available() else "cpu"
        )

        self._model: Optional[GRUSeq2Seq] = None

    def _supports_triton(self) -> bool:

        if not torch.cuda.is_available():
            return False

        major, minor = torch.cuda.get_device_capability()

        capability = float(f"{major}.{minor}")

        # Triton requires >= 7.0
        return capability >= 7.0

    def _safe_compile(self, model):

        if not self._supports_triton():

            log.warning(
                "GPU does not support Triton "
                "→ using eager execution"
            )

            return model

        try:

            log.info("Enabling torch.compile")

            return torch.compile(model)

        except Exception as e:

            log.warning(
                f"torch.compile failed: {e} "
                "→ falling back to eager execution"
            )

            return model

    def _load(self):
        if self._model is not None:
            return

        self._model = GRUSeq2Seq(
            pred_len=self.settings.FORECAST_HORIZON
        ).to(self.device)

        self._model.eval()

        # GPU optimization
        if torch.cuda.is_available():

            gpu_name = torch.cuda.get_device_name(0).lower()

            # Triton/compile unsupported on MX330 + older GPUs
            unsupported_compile = any(x in gpu_name for x in [
                "mx330",
                "mx250",
                "mx150",
                "gtx 10",
                "gtx 9",
            ])

            if not unsupported_compile:
                try:
                    self._model = torch.compile(self._model)
                    print("✅ torch.compile enabled")
                except Exception as e:
                    print(f"⚠ torch.compile failed: {e}")
            else:
                print("⚠ GPU does not support Triton → using eager execution")

        log.info(f"gru.loaded | device={self.device}")

    def predict(self, x: np.ndarray, horizon: int) -> np.ndarray:
        self._load()
        with torch.no_grad():
            arr = np.asarray(x, dtype=np.float32).flatten()
            # Always shape: (1, seq_len, 1)
            tensor = torch.tensor(arr).unsqueeze(0).unsqueeze(-1).to(self.device)
            out = self._model(tensor)          # (1, pred_len)
            result = out.squeeze(0).cpu().numpy()
            # ── FIX: always trim/pad to exactly `horizon` steps ──────────────
            if len(result) >= horizon:
                return result[:horizon]
            return np.pad(result, (0, horizon - len(result)), mode="edge")
