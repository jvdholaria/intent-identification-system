"""
Enterprise Temporal AI Platform — Distributed Trainer

PyTorch Lightning + DDP + MLflow + Optuna HPO
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Dict, List

import mlflow
import mlflow.pytorch
import numpy as np
import optuna
import pytorch_lightning as pl
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

from forecasting.quantile.loss import CombinedForecastLoss
from shared.config.settings import Settings
from shared.logging.logger import get_logger
from shared.schemas.schemas import ModelType

log = get_logger("forecast.trainer")


# -----------------------------------------------------------------------------
# CUDA PERFORMANCE SETTINGS
# -----------------------------------------------------------------------------

torch.set_float32_matmul_precision("high")

if torch.cuda.is_available():
    torch.backends.cudnn.benchmark = True


# -----------------------------------------------------------------------------
# LIGHTNING MODULE
# -----------------------------------------------------------------------------

class TemporalLightningModule(pl.LightningModule):
    """
    Generic Lightning wrapper for temporal forecasting models.

    Supports:
    - PatchTST
    - TFT
    - GRU Seq2Seq
    - Quantile forecasting
    - Mixed precision
    - DDP
    - MLflow logging
    """

    def __init__(
        self,
        model: nn.Module,
        learning_rate: float = 1e-4,
        quantiles: List[float] | None = None,
    ):
        super().__init__()

        self.model = model
        self.lr = learning_rate

        self.quantiles = quantiles or [0.1, 0.5, 0.9]
        self.loss_fn = CombinedForecastLoss(self.quantiles)

        self.save_hyperparameters(ignore=["model"])

    def forward(self, x: torch.Tensor):
        return self.model(x)

    # -------------------------------------------------------------------------
    # INPUT SHAPE NORMALIZATION
    # -------------------------------------------------------------------------

    def _prepare_input(self, x: torch.Tensor) -> torch.Tensor:
        """
        Normalize model inputs.

        PatchTST expects:
            (B, C, L)

        GRU/TFT expect:
            (B, L, C)
        """

        model_name = self.model.__class__.__name__.lower()

        # ---------------------------------------------------------------------
        # PATCHTST
        # ---------------------------------------------------------------------

        if "patchtst" in model_name:

            # (B, W)
            if x.dim() == 2:
                x = x.unsqueeze(1)

            # (B, W, 1)
            elif x.dim() == 3:
                if x.shape[-1] == 1:
                    x = x.transpose(1, 2).contiguous()

            return x.float()

        # ---------------------------------------------------------------------
        # GRU / TFT
        # ---------------------------------------------------------------------

        else:

            # (B, W)
            if x.dim() == 2:
                x = x.unsqueeze(-1)

            # (B, 1, W)
            elif x.dim() == 3:
                if x.shape[1] == 1:
                    x = x.transpose(1, 2).contiguous()

            return x.float()

    # -------------------------------------------------------------------------
    # SHARED TRAIN / VAL STEP
    # -------------------------------------------------------------------------

    def _shared_step(self, batch, stage: str):

        x, y = batch

        x = self._prepare_input(x)

        pred = self(x)

        # ---------------------------------------------------------------------
        # Convert:
        # (B, H)
        # ->
        # (B, H, Q)
        # ---------------------------------------------------------------------

        if pred.dim() == 2:
            pred = pred.unsqueeze(-1).expand(
                -1,
                -1,
                len(self.quantiles),
            )

        loss = self.loss_fn(pred, y)

        self.log(
            f"{stage}/loss",
            loss,
            prog_bar=True,
            on_step=False,
            on_epoch=True,
            sync_dist=True,
        )

        return loss

    def training_step(self, batch, batch_idx):
        return self._shared_step(batch, "train")

    def validation_step(self, batch, batch_idx):
        return self._shared_step(batch, "val")

    # -------------------------------------------------------------------------
    # OPTIMIZER
    # -------------------------------------------------------------------------

    def configure_optimizers(self):

        optimizer = torch.optim.AdamW(
            self.parameters(),
            lr=self.lr,
            weight_decay=1e-5,
        )

        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer,
            T_max=50,
        )

        return {
            "optimizer": optimizer,
            "lr_scheduler": scheduler,
        }


# -----------------------------------------------------------------------------
# DATASET BUILDER
# -----------------------------------------------------------------------------

class TemporalDatasetBuilder:
    """
    Sliding-window dataset builder.

    Creates:

    x = series[i : i + W]
    y = series[i + W : i + W + H]
    """

    def __init__(self, window_size: int, horizon: int):
        self.W = window_size
        self.H = horizon

    def build(self, series: np.ndarray) -> TensorDataset:

        xs = []
        ys = []

        for i in range(len(series) - self.W - self.H + 1):

            x_seq = series[i : i + self.W]
            y_seq = series[i + self.W : i + self.W + self.H]

            xs.append(x_seq)
            ys.append(y_seq)

        X = torch.tensor(np.array(xs), dtype=torch.float32)

        # PatchTST-friendly:
        # (B, 1, W)

        X = X.unsqueeze(1)

        Y = torch.tensor(np.array(ys), dtype=torch.float32)

        return TensorDataset(X, Y)


# -----------------------------------------------------------------------------
# OPTUNA OBJECTIVE
# -----------------------------------------------------------------------------


def _make_optuna_objective(
    model_cls,
    dataset: TensorDataset,
    settings: Settings,
):

    def objective(trial: optuna.Trial) -> float:

        lr = trial.suggest_float("learning_rate", 1e-5, 1e-2, log=True)
        hidden_size = trial.suggest_int("hidden_size", 64, 256)
        n_layers = trial.suggest_int("n_layers", 1, 3)
        dropout = trial.suggest_float("dropout", 0.0, 0.3)

        model = model_cls(
            seq_len=settings.FORECAST_WINDOW_SIZE,
            pred_len=settings.FORECAST_HORIZON,
            hidden_size=hidden_size,
            num_layers=n_layers,
            dropout=dropout,
        )

        module = TemporalLightningModule(model, lr)

        split = int(len(dataset) * 0.8)

        train_ds, val_ds = torch.utils.data.random_split(
            dataset,
            [split, len(dataset) - split],
        )

        trainer = pl.Trainer(
            max_epochs=5,
            accelerator="gpu" if torch.cuda.is_available() else "cpu",
            devices=1,
            precision="16-mixed" if torch.cuda.is_available() else 32,
            enable_progress_bar=False,
            enable_model_summary=False,
            logger=False,
        )

        num_workers = 4

        loader_train = DataLoader(
            train_ds,
            batch_size=16,
            shuffle=True,
            num_workers=num_workers,
            pin_memory=torch.cuda.is_available(),
            persistent_workers=num_workers > 0,
        )

        loader_val = DataLoader(
            val_ds,
            batch_size=16,
            num_workers=num_workers,
            pin_memory=torch.cuda.is_available(),
            persistent_workers=num_workers > 0,
        )

        trainer.fit(module, loader_train, loader_val)

        val_loss = trainer.callback_metrics.get(
            "val/loss",
            torch.tensor(float("inf")),
        )

        return float(val_loss)

    return objective


# -----------------------------------------------------------------------------
# MAIN TRAINER
# -----------------------------------------------------------------------------

class TemporalTrainer:

    def __init__(self, settings: Settings):
        self.settings = settings

    async def train(
        self,
        dataset_path: str,
        model_type: ModelType,
        run_id: str,
        experiment_name: str,
        epochs: int = 100,
        batch_size: int = 64,
        learning_rate: float = 1e-4,
        horizon: int = 120,
        window_size: int = 168,
        quantiles: List[float] | None = None,
        use_distributed: bool = False,
        run_hpo: bool = False,
        tenant_id: str = "default",
        tags: Dict[str, str] | None = None,
    ):

        await asyncio.get_event_loop().run_in_executor(
            None,
            self._train_sync,
            dataset_path,
            model_type,
            run_id,
            experiment_name,
            epochs,
            batch_size,
            learning_rate,
            horizon,
            window_size,
            quantiles,
            use_distributed,
            run_hpo,
            tenant_id,
            tags or {},
        )

    def _train_sync(
        self,
        dataset_path: str,
        model_type: ModelType,
        run_id: str,
        experiment_name: str,
        epochs: int,
        batch_size: int,
        learning_rate: float,
        horizon: int,
        window_size: int,
        quantiles: List[float] | None,
        use_distributed: bool,
        run_hpo: bool,
        tenant_id: str,
        tags: Dict[str, str],
    ):

        mlflow.set_tracking_uri(self.settings.MLFLOW_TRACKING_URI)
        mlflow.set_experiment(experiment_name)

        # ---------------------------------------------------------------------
        # LOAD DATA
        # ---------------------------------------------------------------------

        data = (
            np.load(dataset_path)
            if dataset_path.endswith(".npy")
            else np.zeros(1000)
        )

        builder = TemporalDatasetBuilder(window_size, horizon)
        dataset = builder.build(data)

        split = int(len(dataset) * 0.8)

        train_ds, val_ds = torch.utils.data.random_split(
            dataset,
            [split, len(dataset) - split],
        )

        # ---------------------------------------------------------------------
        # BUILD MODEL
        # ---------------------------------------------------------------------

        model_cls, model = self._build_model(
            model_type,
            window_size,
            horizon,
        )

        # ---------------------------------------------------------------------
        # HPO
        # ---------------------------------------------------------------------

        best_params: Dict[str, Any] = {}

        if run_hpo and model_cls is not None:

            study = optuna.create_study(
                direction="minimize",
                study_name=f"{self.settings.OPTUNA_STUDY_NAME}/{tenant_id}",
            )

            study.optimize(
                _make_optuna_objective(model_cls, dataset, self.settings),
                n_trials=self.settings.OPTUNA_N_TRIALS,
                timeout=self.settings.OPTUNA_TIMEOUT,
                show_progress_bar=False,
            )

            best_params = study.best_params

            log.info(
                "hpo.complete",
                best_params=best_params,
                tenant=tenant_id,
            )

            learning_rate = best_params.get(
                "learning_rate",
                learning_rate,
            )

        # ---------------------------------------------------------------------
        # TRAIN
        # ---------------------------------------------------------------------

        with mlflow.start_run(run_name=run_id) as run:

            mlflow.set_tags({
                **tags,
                "tenant_id": tenant_id,
                "model_type": model_type.value,
            })

            mlflow.log_params({
                "epochs": epochs,
                "batch_size": batch_size,
                "learning_rate": learning_rate,
                "horizon": horizon,
                "window_size": window_size,
                **best_params,
            })

            module = TemporalLightningModule(
                model,
                learning_rate,
                quantiles,
            )

            strategy = "ddp" if use_distributed else "auto"

            trainer = pl.Trainer(
                max_epochs=epochs,
                accelerator="gpu" if torch.cuda.is_available() else "cpu",
                devices=self.settings.TRAINING_GPUS if use_distributed else 1,
                strategy=strategy,
                precision="16-mixed" if torch.cuda.is_available() else 32,
                accumulate_grad_batches=self.settings.TRAINING_GRADIENT_ACCUMULATION,
                gradient_clip_val=1.0,
                enable_progress_bar=True,
                log_every_n_steps=10,
            )

            num_workers = 4

            loader_train = DataLoader(
                train_ds,
                batch_size=batch_size,
                shuffle=True,
                num_workers=num_workers,
                pin_memory=torch.cuda.is_available(),
                persistent_workers=num_workers > 0,
            )

            loader_val = DataLoader(
                val_ds,
                batch_size=batch_size,
                num_workers=num_workers,
                pin_memory=torch.cuda.is_available(),
                persistent_workers=num_workers > 0,
            )

            t0 = time.time()

            trainer.fit(module, loader_train, loader_val)

            elapsed = time.time() - t0

            val_loss = float(
                trainer.callback_metrics.get("val/loss", 0.0)
            )

            mlflow.log_metrics({
                "val_loss": val_loss,
                "training_time_s": elapsed,
            })

            mlflow.pytorch.log_model(
                model,
                artifact_path="model",
                registered_model_name=f"{model_type.value}_{tenant_id}",
            )

            log.info(
                "training.logged",
                run_id=run.info.run_id,
                val_loss=val_loss,
            )

    # -------------------------------------------------------------------------
    # MODEL FACTORY
    # -------------------------------------------------------------------------

    def _build_model(
        self,
        model_type: ModelType,
        window_size: int,
        horizon: int,
    ):

        if model_type == ModelType.patchtst:

            from forecasting.models.patchtst.model import PatchTSTModel

            model = PatchTSTModel(
                seq_len=window_size,
                pred_len=horizon,
                d_model=64,
                n_heads=4,
                n_layers=2,
                d_ff=128,
                dropout=0.1,
            )

            return PatchTSTModel, model

        if model_type == ModelType.tft:

            from forecasting.models.tft.model import TFTModel

            return TFTModel, TFTModel(
                seq_len=window_size,
                pred_len=horizon,
            )

        from forecasting.models.gru.model import GRUSeq2Seq

        return GRUSeq2Seq, GRUSeq2Seq(pred_len=horizon)
