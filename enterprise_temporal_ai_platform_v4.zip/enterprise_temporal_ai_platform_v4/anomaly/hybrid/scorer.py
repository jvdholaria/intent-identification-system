"""
Enterprise Temporal AI Platform — Hybrid Anomaly Scorer

FINAL_SCORE = 0.5 * residual_score + 0.3 * reconstruction_score + 0.2 * drift_score

Also incorporates Isolation Forest for tabular/feature-space anomaly detection.
"""

from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
from sklearn.ensemble import IsolationForest

from shared.logging.logger import get_logger

log = get_logger("anomaly.hybrid")


class HybridAnomalyScorer:
    """
    Combines three complementary detectors into a single weighted score:

    | Detector            | Weight | Detects                       |
    |---------------------|--------|-------------------------------|
    | Residual            | 0.50   | Forecast deviations           |
    | Reconstruction      | 0.30   | Latent / unknown anomalies    |
    | Drift               | 0.20   | Distribution / concept drift  |
    """

    def __init__(
        self,
        residual_weight: float = 0.5,
        reconstruction_weight: float = 0.3,
        drift_weight: float = 0.2,
    ):
        assert abs(residual_weight + reconstruction_weight + drift_weight - 1.0) < 1e-6, \
            "Weights must sum to 1.0"
        self.w_res = residual_weight
        self.w_rec = reconstruction_weight
        self.w_drift = drift_weight

    def score_point(
        self,
        residual_score: float,
        reconstruction_score: float,
        drift_score: float,
    ) -> float:
        """Compute hybrid score for a single time point."""
        return (
            self.w_res * max(residual_score, 0.0)
            + self.w_rec * max(reconstruction_score, 0.0)
            + self.w_drift * max(drift_score, 0.0)
        )

    def score_batch(
        self,
        residual_scores: List[float],
        reconstruction_scores: List[float],
        drift_scores: List[float],
    ) -> List[float]:
        """
        Compute hybrid scores for a full batch of time points.
        All input lists must have the same length.
        """
        n = len(residual_scores)
        assert len(reconstruction_scores) == n and len(drift_scores) == n

        return [
            round(self.score_point(r, rc, d), 4)
            for r, rc, d in zip(residual_scores, reconstruction_scores, drift_scores)
        ]

    def adaptive_threshold(
        self,
        scores: List[float],
        contamination: float = 0.05,
    ) -> float:
        """
        Compute an adaptive threshold at the (1 - contamination) quantile
        of the score distribution.
        """
        arr = np.array(scores)
        return float(np.quantile(arr, 1.0 - contamination))


class IsolationForestDetector:
    """
    Isolation Forest for feature-space and tabular outlier detection.
    Used as a complementary detector alongside residual and autoencoder methods.
    """

    def __init__(
        self,
        contamination: float = 0.05,
        n_estimators: int = 100,
        random_state: int = 42,
    ):
        self.model = IsolationForest(
            contamination=contamination,
            n_estimators=n_estimators,
            random_state=random_state,
            n_jobs=-1,
        )
        self._fitted = False

    def fit(self, features: np.ndarray) -> "IsolationForestDetector":
        """Fit the model on reference (normal) feature data."""
        self.model.fit(features)
        self._fitted = True
        log.info("isolation_forest.fitted", n_samples=len(features))
        return self

    def score(self, features: np.ndarray) -> List[float]:
        """
        Return anomaly scores in [0, 1].
        Higher = more anomalous.
        """
        if not self._fitted:
            log.warning("isolation_forest.not_fitted — returning zeros")
            return [0.0] * len(features)

        # sklearn returns negative scores; flip and normalise to [0, 1]
        raw = -self.model.score_samples(features)
        min_s, max_s = raw.min(), raw.max()
        if max_s - min_s < 1e-9:
            return [0.0] * len(features)
        normalised = (raw - min_s) / (max_s - min_s)
        return [round(float(s), 4) for s in normalised]

    def predict(self, features: np.ndarray) -> List[bool]:
        """Return True for anomalous samples."""
        if not self._fitted:
            return [False] * len(features)
        preds = self.model.predict(features)  # -1 = anomaly, 1 = normal
        return [p == -1 for p in preds]


class EnsembleAnomalyPipeline:
    """
    Full end-to-end anomaly detection pipeline integrating:
    1. Residual detector
    2. Reconstruction scorer (LSTM / Transformer AE)
    3. Isolation Forest (feature space)
    4. Hybrid scorer
    5. Isolation Forest meta-scoring on hybrid features
    """

    def __init__(
        self,
        residual_weight: float = 0.5,
        reconstruction_weight: float = 0.3,
        drift_weight: float = 0.2,
    ):
        from anomaly.residual.detector import ResidualDetector
        self.residual_detector = ResidualDetector()
        self.hybrid_scorer = HybridAnomalyScorer(residual_weight, reconstruction_weight, drift_weight)
        self.iso_forest = IsolationForestDetector()

    def run(
        self,
        actual: List[float],
        predicted: List[float],
        feature_matrix: Optional[np.ndarray] = None,
        drift_scores: Optional[List[float]] = None,
    ) -> Dict:
        residual_scores = self.residual_detector.score(actual, predicted)

        # Reconstruction scores — zero if AE not loaded
        reconstruction_scores = [0.0] * len(actual)

        # Drift scores
        d_scores = drift_scores or [0.0] * len(actual)

        # Hybrid
        final_scores = self.hybrid_scorer.score_batch(
            residual_scores, reconstruction_scores, d_scores
        )

        # Isolation Forest on feature matrix if provided
        iso_predictions = [False] * len(actual)
        if feature_matrix is not None and len(feature_matrix) == len(actual):
            if not self.iso_forest._fitted:
                self.iso_forest.fit(feature_matrix)
            iso_predictions = self.iso_forest.predict(feature_matrix)

        threshold = self.hybrid_scorer.adaptive_threshold(final_scores)
        is_anomaly = [s > threshold for s in final_scores]

        return {
            "final_scores": final_scores,
            "residual_scores": residual_scores,
            "reconstruction_scores": reconstruction_scores,
            "drift_scores": d_scores,
            "is_anomaly": is_anomaly,
            "iso_forest_anomaly": iso_predictions,
            "threshold": round(threshold, 4),
        }
