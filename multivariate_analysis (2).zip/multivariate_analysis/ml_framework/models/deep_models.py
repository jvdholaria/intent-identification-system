"""
deep_models.py — PyTorch deep-learning models for multi-output time-series.

Architecture overview
---------------------

All models share a common three-section structure:

  ┌─────────────────────────────────────────────────────┐
  │  SEQUENCE ENCODER                                   │
  │  (LSTM | GRU | TCN | Transformer)                  │
  │  Input: (batch, window, n_temporal_features)        │
  │  Output: (batch, hidden_size)                       │
  ├─────────────────────────────────────────────────────┤
  │  STATIC BRANCH  (optional)                         │
  │  MLP over time-invariant features                   │
  │  Input: (batch, n_static_features)                  │
  │  Output: (batch, static_out_size)                   │
  ├─────────────────────────────────────────────────────┤
  │  SHARED DECODER + PER-TARGET HEADS                  │
  │  Fuses sequence + static representations            │
  │  Independent linear heads → one per target          │
  │  Output: (batch, n_targets)                         │
  └─────────────────────────────────────────────────────┘

The 'hybrid' mode feeds static features into the sequence encoder via
a learned context vector (feature-wise gating), so both branches share
parameters early.
"""

from __future__ import annotations

import logging
import math
from typing import List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch.utils.data import DataLoader, Dataset

from ..core.config import DeepModelConfig, FrameworkConfig

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Utility — device selection
# ---------------------------------------------------------------------------

def _select_device(cfg: DeepModelConfig) -> torch.device:
    if cfg.device == "auto":
        if torch.cuda.is_available():
            return torch.device("cuda")
        if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")
    return torch.device(cfg.device)


def _get_activation(name: str) -> nn.Module:
    return {"gelu": nn.GELU(), "relu": nn.ReLU(), "silu": nn.SiLU()}.get(name, nn.GELU())


# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------

class TimeSeriesDataset(Dataset):
    """
    Wraps (X_seq, X_static, y) numpy arrays as a PyTorch Dataset.

    X_seq    : (N, window, temporal_features)
    X_static : (N, static_features) — may be zeros if no static features
    y        : (N, n_targets)
    """

    def __init__(
        self,
        X_seq: np.ndarray,
        y:     np.ndarray,
        X_static: Optional[np.ndarray] = None,
    ) -> None:
        self.X_seq    = torch.from_numpy(X_seq.astype(np.float32))
        self.y        = torch.from_numpy(y.astype(np.float32))
        if X_static is not None:
            self.X_static = torch.from_numpy(X_static.astype(np.float32))
        else:
            self.X_static = torch.zeros(len(X_seq), 1)

    def __len__(self):
        return len(self.X_seq)

    def __getitem__(self, idx):
        return self.X_seq[idx], self.X_static[idx], self.y[idx]


class StaticDataset(Dataset):
    """Flat (non-sequential) dataset for static prediction mode."""

    def __init__(self, X: np.ndarray, y: np.ndarray) -> None:
        self.X = torch.from_numpy(X.astype(np.float32))
        self.y = torch.from_numpy(y.astype(np.float32))

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


# ---------------------------------------------------------------------------
# Sequence encoder building blocks
# ---------------------------------------------------------------------------

class LSTMEncoder(nn.Module):
    def __init__(self, input_size: int, hidden: int, n_layers: int, dropout: float):
        super().__init__()
        self.rnn = nn.LSTM(
            input_size, hidden, n_layers, batch_first=True,
            dropout=dropout if n_layers > 1 else 0.0, bidirectional=False,
        )
        self.out_size = hidden

    def forward(self, x: Tensor) -> Tensor:
        _, (h, _) = self.rnn(x)      # h: (layers, batch, hidden)
        return h[-1]                  # last layer's final hidden state


class GRUEncoder(nn.Module):
    def __init__(self, input_size: int, hidden: int, n_layers: int, dropout: float):
        super().__init__()
        self.rnn = nn.GRU(
            input_size, hidden, n_layers, batch_first=True,
            dropout=dropout if n_layers > 1 else 0.0,
        )
        self.out_size = hidden

    def forward(self, x: Tensor) -> Tensor:
        _, h = self.rnn(x)
        return h[-1]


class CausalConv1d(nn.Module):
    """Single dilated causal convolution layer used in TCN."""

    def __init__(self, in_ch: int, out_ch: int, kernel: int, dilation: int, dropout: float):
        super().__init__()
        pad = (kernel - 1) * dilation
        self.conv = nn.Conv1d(in_ch, out_ch, kernel, dilation=dilation, padding=pad)
        self.drop = nn.Dropout(dropout)
        self.relu = nn.ReLU()
        self.res  = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity()

    def forward(self, x: Tensor) -> Tensor:
        # x: (batch, channels, time)
        out = self.conv(x)[:, :, :x.size(2)]   # remove causal padding tail
        out = self.drop(self.relu(out))
        return out + self.res(x)


class TCNEncoder(nn.Module):
    """Temporal Convolutional Network with exponentially growing dilations."""

    def __init__(self, input_size: int, hidden: int, n_layers: int, dropout: float):
        super().__init__()
        layers = []
        in_ch = input_size
        for i in range(n_layers):
            dilation = 2 ** i
            layers.append(CausalConv1d(in_ch, hidden, kernel=3, dilation=dilation, dropout=dropout))
            in_ch = hidden
        self.network  = nn.Sequential(*layers)
        self.out_size = hidden

    def forward(self, x: Tensor) -> Tensor:
        # x: (batch, time, features) → (batch, features, time)
        x = x.permute(0, 2, 1)
        out = self.network(x)        # (batch, hidden, time)
        return out[:, :, -1]        # last time step


class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 512, dropout: float = 0.1):
        super().__init__()
        self.dropout = nn.Dropout(dropout)
        pe = torch.zeros(max_len, d_model)
        pos = torch.arange(max_len, dtype=torch.float).unsqueeze(1)
        div = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(pos * div)
        pe[:, 1::2] = torch.cos(pos * div)
        self.register_buffer("pe", pe.unsqueeze(0))  # (1, max_len, d_model)

    def forward(self, x: Tensor) -> Tensor:
        x = x + self.pe[:, :x.size(1)]
        return self.dropout(x)


class TransformerEncoder(nn.Module):
    """
    Causal transformer encoder — attends only to past tokens via a
    causal mask, making it safe for autoregressive forecasting.
    """

    def __init__(
        self,
        input_size: int,
        hidden: int,
        n_layers: int,
        n_heads: int,
        ff_dim: int,
        dropout: float,
    ):
        super().__init__()
        self.input_proj = nn.Linear(input_size, hidden)
        self.pos_enc    = PositionalEncoding(hidden, dropout=dropout)
        encoder_layer   = nn.TransformerEncoderLayer(
            d_model=hidden, nhead=n_heads, dim_feedforward=ff_dim,
            dropout=dropout, batch_first=True, activation="gelu",
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        self.out_size    = hidden

    def forward(self, x: Tensor) -> Tensor:
        T = x.size(1)
        mask = nn.Transformer.generate_square_subsequent_mask(T, device=x.device)
        x = self.pos_enc(self.input_proj(x))
        out = self.transformer(x, mask=mask, is_causal=True)
        return out[:, -1, :]        # representation of the last time step


# ---------------------------------------------------------------------------
# Static MLP branch
# ---------------------------------------------------------------------------

class StaticMLP(nn.Module):
    def __init__(self, input_size: int, hidden_sizes: List[int], act: nn.Module, dropout: float):
        super().__init__()
        layers: List[nn.Module] = []
        in_sz = input_size
        for h in hidden_sizes:
            layers += [nn.Linear(in_sz, h), act, nn.Dropout(dropout)]
            in_sz = h
        self.net      = nn.Sequential(*layers)
        self.out_size = in_sz

    def forward(self, x: Tensor) -> Tensor:
        return self.net(x)


# ---------------------------------------------------------------------------
# Shared decoder + per-target heads
# ---------------------------------------------------------------------------

class MultiTargetDecoder(nn.Module):
    """
    Takes the fused sequence + static representation and produces per-target
    predictions through a shared MLP followed by independent linear heads.
    """

    def __init__(
        self,
        input_size: int,
        shared_sizes: List[int],
        n_targets: int,
        act: nn.Module,
        dropout: float,
    ):
        super().__init__()
        layers: List[nn.Module] = []
        in_sz = input_size
        for h in shared_sizes:
            layers += [nn.Linear(in_sz, h), act, nn.Dropout(dropout)]
            in_sz = h
        self.shared = nn.Sequential(*layers)
        # Separate prediction head per target
        self.heads  = nn.ModuleList([nn.Linear(in_sz, 1) for _ in range(n_targets)])

    def forward(self, z: Tensor) -> Tensor:
        shared_repr = self.shared(z)
        preds = torch.cat([head(shared_repr) for head in self.heads], dim=1)
        return preds   # (batch, n_targets)


# ---------------------------------------------------------------------------
# Master multi-output forecasting model
# ---------------------------------------------------------------------------

class MultiOutputForecastingModel(nn.Module):
    """
    Unified PyTorch model supporting LSTM, GRU, TCN, Transformer,
    and Hybrid (temporal + static) architectures.

    Parameters
    ----------
    temporal_input_size : int
        Number of temporal (sequence) features per time step.
    static_input_size : int
        Number of static (non-temporal) features. Set to 0 or 1 if unused.
    n_targets : int
        Number of output variables to predict simultaneously.
    cfg : DeepModelConfig
    """

    def __init__(
        self,
        temporal_input_size: int,
        static_input_size: int,
        n_targets: int,
        cfg: DeepModelConfig,
    ) -> None:
        super().__init__()
        self.cfg = cfg
        act      = _get_activation(cfg.activation)

        # ---- Sequence encoder -------------------------------------------
        arch = cfg.architecture
        encoder_args = dict(
            input_size=temporal_input_size,
            hidden=cfg.hidden_size,
            n_layers=cfg.num_layers,
            dropout=cfg.dropout,
        )
        if arch in ("lstm", "hybrid"):
            self.seq_encoder = LSTMEncoder(**encoder_args)
        elif arch == "gru":
            self.seq_encoder = GRUEncoder(**encoder_args)
        elif arch == "tcn":
            self.seq_encoder = TCNEncoder(**encoder_args)
        elif arch == "transformer":
            self.seq_encoder = TransformerEncoder(
                **encoder_args,
                n_heads=cfg.num_heads,
                ff_dim=cfg.ff_dim,
            )
        else:
            raise ValueError(f"Unknown architecture: {arch}")

        enc_out = self.seq_encoder.out_size

        # ---- Static branch ----------------------------------------------
        self.has_static = static_input_size > 1
        if self.has_static:
            self.static_branch = StaticMLP(
                static_input_size, cfg.static_hidden_sizes, act, cfg.dropout
            )
            static_out = self.static_branch.out_size
        else:
            static_out = 0

        # ---- Gating for Hybrid mode ------------------------------------
        if arch == "hybrid" and self.has_static:
            self.gate = nn.Sequential(
                nn.Linear(static_input_size, temporal_input_size),
                nn.Sigmoid(),
            )

        # ---- Fusion + decoder -------------------------------------------
        fusion_size = enc_out + static_out
        self.decoder = MultiTargetDecoder(
            input_size=fusion_size,
            shared_sizes=cfg.shared_decoder_sizes,
            n_targets=n_targets,
            act=act,
            dropout=cfg.dropout,
        )

    def forward(self, x_seq: Tensor, x_static: Tensor) -> Tensor:
        # Hybrid gating: modulate input features by static context
        if self.cfg.architecture == "hybrid" and self.has_static:
            gate = self.gate(x_static).unsqueeze(1)   # (B, 1, features)
            x_seq = x_seq * gate

        seq_repr = self.seq_encoder(x_seq)

        if self.has_static:
            static_repr = self.static_branch(x_static)
            fused = torch.cat([seq_repr, static_repr], dim=1)
        else:
            fused = seq_repr

        return self.decoder(fused)


# ---------------------------------------------------------------------------
# Trainer wrapper
# ---------------------------------------------------------------------------

class DeepModelTrainer:
    """
    Handles training loop, early stopping, AMP, checkpointing,
    and inference for MultiOutputForecastingModel.

    Usage
    -----
    >>> trainer = DeepModelTrainer(cfg, n_temporal_features, n_static, n_targets)
    >>> trainer.fit(X_seq_train, y_train, X_seq_val, y_val)
    >>> preds = trainer.predict(X_seq_test)
    """

    def __init__(
        self,
        config: FrameworkConfig,
        n_temporal_features: int,
        n_static_features: int,
        n_targets: int,
    ) -> None:
        self.cfg    = config.deep_model
        self.device = _select_device(self.cfg)
        self.model  = MultiOutputForecastingModel(
            temporal_input_size=n_temporal_features,
            static_input_size=n_static_features,
            n_targets=n_targets,
            cfg=self.cfg,
        ).to(self.device)

        logger.info(
            "Deep model on %s | params=%.1fM | arch=%s",
            self.device,
            sum(p.numel() for p in self.model.parameters()) / 1e6,
            self.cfg.architecture,
        )

    # ------------------------------------------------------------------
    # Fit
    # ------------------------------------------------------------------

    def fit(
        self,
        X_seq_train: np.ndarray,
        y_train:     np.ndarray,
        X_seq_val:   np.ndarray,
        y_val:       np.ndarray,
        X_static_train: Optional[np.ndarray] = None,
        X_static_val:   Optional[np.ndarray] = None,
    ) -> "DeepModelTrainer":
        train_ds = TimeSeriesDataset(X_seq_train, y_train, X_static_train)
        val_ds   = TimeSeriesDataset(X_seq_val,   y_val,   X_static_val)

        train_dl = DataLoader(
            train_ds, batch_size=self.cfg.batch_size, shuffle=True, pin_memory=True, num_workers=0
        )
        val_dl = DataLoader(
            val_ds, batch_size=self.cfg.batch_size * 2, shuffle=False, num_workers=0
        )

        optimiser = torch.optim.AdamW(
            self.model.parameters(),
            lr=self.cfg.learning_rate,
            weight_decay=self.cfg.weight_decay,
        )
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimiser, T_max=self.cfg.max_epochs, eta_min=1e-6
        )
        scaler = torch.cuda.amp.GradScaler(enabled=(self.cfg.use_amp and self.device.type == "cuda"))
        criterion = nn.HuberLoss()

        best_val_loss = float("inf")
        patience_cnt  = 0
        best_state    = None

        for epoch in range(1, self.cfg.max_epochs + 1):
            # ---- Train epoch ------------------------------------------
            self.model.train()
            train_loss = 0.0
            for x_seq, x_static, y_batch in train_dl:
                x_seq    = x_seq.to(self.device, non_blocking=True)
                x_static = x_static.to(self.device, non_blocking=True)
                y_batch  = y_batch.to(self.device, non_blocking=True)

                optimiser.zero_grad()
                with torch.cuda.amp.autocast(enabled=(self.cfg.use_amp and self.device.type == "cuda")):
                    preds = self.model(x_seq, x_static)
                    loss  = criterion(preds, y_batch)

                scaler.scale(loss).backward()
                scaler.unscale_(optimiser)
                nn.utils.clip_grad_norm_(self.model.parameters(), self.cfg.gradient_clip)
                scaler.step(optimiser)
                scaler.update()
                train_loss += loss.item()

            # ---- Validation -------------------------------------------
            val_loss = self._evaluate_loss(val_dl, criterion)
            scheduler.step()

            avg_train = train_loss / len(train_dl)
            if epoch % 5 == 0 or epoch == 1:
                logger.info(
                    "Epoch %3d/%d | train_loss=%.4f | val_loss=%.4f | lr=%.2e",
                    epoch, self.cfg.max_epochs, avg_train, val_loss,
                    optimiser.param_groups[0]["lr"],
                )

            # ---- Early stopping ---------------------------------------
            if val_loss < best_val_loss - 1e-5:
                best_val_loss = val_loss
                patience_cnt  = 0
                best_state    = {k: v.cpu().clone() for k, v in self.model.state_dict().items()}
            else:
                patience_cnt += 1
                if patience_cnt >= self.cfg.patience:
                    logger.info("Early stopping at epoch %d.", epoch)
                    break

        # Restore best checkpoint
        if best_state:
            self.model.load_state_dict(best_state)
        return self

    # ------------------------------------------------------------------
    # Predict
    # ------------------------------------------------------------------

    @torch.no_grad()
    def predict(
        self,
        X_seq: np.ndarray,
        X_static: Optional[np.ndarray] = None,
    ) -> np.ndarray:
        self.model.eval()
        ds = TimeSeriesDataset(X_seq, np.zeros((len(X_seq), 1)), X_static)
        dl = DataLoader(ds, batch_size=self.cfg.batch_size * 2, shuffle=False)
        preds = []
        for x_seq, x_static, _ in dl:
            x_seq    = x_seq.to(self.device)
            x_static = x_static.to(self.device)
            preds.append(self.model(x_seq, x_static).cpu().numpy())
        return np.concatenate(preds, axis=0).astype(np.float32)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @torch.no_grad()
    def _evaluate_loss(self, dl: DataLoader, criterion: nn.Module) -> float:
        self.model.eval()
        total = 0.0
        for x_seq, x_static, y_batch in dl:
            x_seq    = x_seq.to(self.device)
            x_static = x_static.to(self.device)
            y_batch  = y_batch.to(self.device)
            preds    = self.model(x_seq, x_static)
            total   += criterion(preds, y_batch).item()
        return total / max(len(dl), 1)

    def save(self, path: str) -> None:
        torch.save({"model_state": self.model.state_dict(), "cfg": self.cfg}, path)
        logger.info("Deep model saved to %s", path)

    def load(self, path: str) -> None:
        ckpt = torch.load(path, map_location=self.device)
        self.model.load_state_dict(ckpt["model_state"])
        logger.info("Deep model loaded from %s", path)
