#!/usr/bin/env python3
"""
Enterprise Temporal AI Platform — Local Setup Script

Installs all required Python packages for running the platform
locally without Docker. Supports CPU-only and GPU environments.

Usage:
    python setup_local.py          # auto-detect GPU
    python setup_local.py --cpu    # force CPU-only install
    python setup_local.py --check  # check what's installed
"""

from __future__ import annotations

import argparse
import subprocess
import sys


# ─────────────────────────────────────────────────────────────────────────────
# Package lists
# ─────────────────────────────────────────────────────────────────────────────

CORE_PACKAGES = [
    # Web framework
    "fastapi>=0.110.0",
    "uvicorn[standard]>=0.29.0",
    "httpx>=0.27.0",
    "pydantic>=2.6.0",
    "pydantic-settings>=2.2.0",

    # Async / caching
    "redis[hiredis]>=5.0.0",

    # Logging & monitoring
    "structlog>=24.1.0",
    "prometheus-client>=0.20.0",

    # Data processing
    "numpy>=1.26.0",
    "pandas>=2.2.0",
    "scipy>=1.12.0",
    "scikit-learn>=1.4.0",

    # ML / training
    "pytorch-lightning>=2.2.0",
    "optuna>=3.6.0",
    "mlflow>=2.11.0",

    # Async tools
    "aiofiles>=23.2.0",
    "celery[redis]>=5.3.0",
]

GPU_TORCH = "torch>=2.2.0"
CPU_TORCH = "torch>=2.2.0 --index-url https://download.pytorch.org/whl/cpu"

OPTIONAL_PACKAGES = [
    # Feature store (heavy GCP deps — skip if not using BigQuery)
    # "feast[redis,gcp]>=0.38.0",

    # Explainability
    "shap>=0.45.0",

    # Streaming (skip if not using GCP Pub/Sub)
    # "google-cloud-pubsub>=2.21.0",

    # Airflow (only if using workflow scheduling)
    # "apache-airflow>=2.9.0",
]

DEV_PACKAGES = [
    "pytest>=8.1.0",
    "pytest-asyncio>=0.23.0",
    "pytest-cov>=5.0.0",
    "fakeredis[aioredis]>=2.21.0",
    "ruff>=0.4.0",
]


def run(cmd: str, check: bool = True) -> int:
    print(f"\n  $ {cmd}")
    result = subprocess.run(cmd, shell=True)
    if check and result.returncode != 0:
        print(f"  ❌ Command failed (exit {result.returncode})")
    return result.returncode


def detect_gpu() -> bool:
    try:
        result = subprocess.run(
            "nvidia-smi --query-gpu=name --format=csv,noheader",
            shell=True, capture_output=True, text=True
        )
        if result.returncode == 0 and result.stdout.strip():
            gpus = result.stdout.strip().split("\n")
            print(f"  🎮 GPU detected: {', '.join(gpus)}")
            return True
    except Exception:
        pass
    print("  💻 No GPU detected — installing CPU-only PyTorch")
    return False


def check_installed():
    import importlib
    checks = {
        "torch": "torch",
        "pytorch_lightning": "pytorch_lightning",
        "fastapi": "fastapi",
        "numpy": "numpy",
        "pandas": "pandas",
        "sklearn": "scikit-learn",
        "mlflow": "mlflow",
        "redis": "redis",
        "structlog": "structlog",
        "optuna": "optuna",
        "scipy": "scipy",
    }
    print("\n  Package status:")
    all_ok = True
    for module, name in checks.items():
        try:
            mod = importlib.import_module(module)
            version = getattr(mod, "__version__", "?")
            print(f"  ✅  {name:<25} {version}")
        except ImportError:
            print(f"  ❌  {name:<25} NOT INSTALLED")
            all_ok = False
    return all_ok


def main():
    parser = argparse.ArgumentParser(description="Temporal AI — Local Setup")
    parser.add_argument("--cpu", action="store_true", help="Force CPU-only install")
    parser.add_argument("--check", action="store_true", help="Check installed packages only")
    parser.add_argument("--dev", action="store_true", help="Also install dev/test packages")
    parser.add_argument("--minimal", action="store_true", help="Install only the bare minimum")
    args = parser.parse_args()

    print("=" * 60)
    print("  Enterprise Temporal AI — Local Setup")
    print("=" * 60)

    if args.check:
        ok = check_installed()
        sys.exit(0 if ok else 1)

    # ── Upgrade pip ───────────────────────────────────────────────────────────
    run(f"{sys.executable} -m pip install --upgrade pip setuptools wheel")

    # ── Install PyTorch ───────────────────────────────────────────────────────
    use_gpu = (not args.cpu) and detect_gpu()
    if use_gpu:
        run(f"{sys.executable} -m pip install {GPU_TORCH}")
    else:
        run(f"{sys.executable} -m pip install {CPU_TORCH}")

    # ── Core packages ─────────────────────────────────────────────────────────
    packages = CORE_PACKAGES if not args.minimal else CORE_PACKAGES[:10]
    pkg_str = " ".join(f'"{p}"' for p in packages)
    run(f"{sys.executable} -m pip install {pkg_str}")

    # ── Dev packages ──────────────────────────────────────────────────────────
    if args.dev:
        dev_str = " ".join(f'"{p}"' for p in DEV_PACKAGES)
        run(f"{sys.executable} -m pip install {dev_str}")

    print("\n" + "=" * 60)
    print("  Verifying installation...")
    print("=" * 60)
    ok = check_installed()

    if ok:
        print("""
✅ Setup complete!

Next steps:
  1. Copy .env.example → .env and edit if needed
  2. Run the platform:
       python run_local.py --csv your_data.csv --target your_column
""")
    else:
        print("\n⚠  Some packages failed — check errors above and retry")
        sys.exit(1)


if __name__ == "__main__":
    main()
