"""
Enterprise Temporal AI Platform — Shared Pydantic Schemas
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, model_validator


# ──────────────────────────────────────────────────────────────────────────────
# Enums
# ──────────────────────────────────────────────────────────────────────────────

class ForecastStrategy(str, Enum):
    seq2seq = "seq2seq"
    direct = "direct"
    recursive = "recursive"


class ModelType(str, Enum):
    patchtst = "patchtst"
    tft = "tft"
    timesnet = "timesnet"
    nbeats = "nbeats"
    transformer = "transformer"
    informer = "informer"
    autoformer = "autoformer"
    fedformer = "fedformer"
    gru = "gru"
    lstm = "lstm"
    ensemble = "ensemble"


class AnomalyMethod(str, Enum):
    residual = "residual"
    autoencoder = "autoencoder"
    isolation_forest = "isolation_forest"
    hybrid = "hybrid"


class DriftType(str, Enum):
    data_drift = "data_drift"
    feature_drift = "feature_drift"
    concept_drift = "concept_drift"
    embedding_drift = "embedding_drift"
    distribution_drift = "distribution_drift"


# ──────────────────────────────────────────────────────────────────────────────
# Base Request / Response
# ──────────────────────────────────────────────────────────────────────────────

class TenantContext(BaseModel):
    """Every request must carry tenant + user context."""
    tenant_id: str = Field(..., description="Tenant identifier for isolation")
    user_id: str = Field(..., description="User identifier for concurrency tracking")
    request_id: Optional[str] = Field(default=None, description="Optional idempotency key")


class BaseResponse(BaseModel):
    status: str = "ok"
    request_id: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    tenant_id: Optional[str] = None


class ErrorResponse(BaseModel):
    status: str = "error"
    code: int
    message: str
    detail: Optional[Any] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# ──────────────────────────────────────────────────────────────────────────────
# Forecasting Schemas
# ──────────────────────────────────────────────────────────────────────────────

class TimeSeriesPoint(BaseModel):
    timestamp: datetime
    value: float
    feature_values: Optional[Dict[str, float]] = None


class ForecastRequest(TenantContext):
    series: List[float] = Field(..., description="Input time series values")
    timestamps: Optional[List[datetime]] = None
    horizon: int = Field(default=120, ge=1, le=720)
    quantiles: List[float] = Field(default=[0.1, 0.5, 0.9])
    model: ModelType = ModelType.ensemble
    strategy: ForecastStrategy = ForecastStrategy.seq2seq
    return_uncertainty: bool = True
    return_quantiles: bool = True
    metadata: Optional[Dict[str, Any]] = None

    @model_validator(mode="after")
    def validate_series_length(self) -> "ForecastRequest":
        if len(self.series) < 2:
            raise ValueError("Series must contain at least 2 data points")
        return self


class QuantileForecast(BaseModel):
    p10: List[float]
    p50: List[float]
    p90: List[float]


class ForecastResponse(BaseResponse):
    forecast: List[float]
    lower_bound: List[float]
    upper_bound: List[float]
    uncertainty: List[float]
    quantiles: QuantileForecast
    model_used: ModelType
    horizon: int
    window_size: int
    forecast_timestamps: Optional[List[datetime]] = None
    shap_values: Optional[List[float]] = None


# ──────────────────────────────────────────────────────────────────────────────
# Anomaly Detection Schemas
# ──────────────────────────────────────────────────────────────────────────────

class AnomalyRequest(TenantContext):
    actual: List[float] = Field(..., description="Observed values")
    predicted: List[float] = Field(..., description="Model-predicted values")
    timestamps: Optional[List[datetime]] = None
    method: AnomalyMethod = AnomalyMethod.hybrid
    threshold_sigma: float = Field(default=3.0, ge=1.0, le=10.0)
    return_explanations: bool = True
    feature_context: Optional[Dict[str, List[float]]] = None

    @model_validator(mode="after")
    def validate_lengths(self) -> "AnomalyRequest":
        if len(self.actual) != len(self.predicted):
            raise ValueError("actual and predicted must have equal length")
        return self


class AnomalyDetail(BaseModel):
    index: int
    timestamp: Optional[datetime] = None
    actual_value: float
    predicted_value: float
    residual: float
    score: float
    is_anomaly: bool
    severity: str   # "low", "medium", "high", "critical"


class AnomalyResponse(BaseResponse):
    anomalies: List[AnomalyDetail]
    scores: List[float]
    residual_scores: List[float]
    reconstruction_scores: Optional[List[float]] = None
    drift_scores: Optional[List[float]] = None
    anomaly_count: int
    anomaly_rate: float
    explanations: Optional[List[str]] = None
    llm_summary: Optional[str] = None


# ──────────────────────────────────────────────────────────────────────────────
# Drift Detection Schemas
# ──────────────────────────────────────────────────────────────────────────────

class DriftRequest(TenantContext):
    baseline: List[float] = Field(..., description="Reference distribution")
    current: List[float] = Field(..., description="Current distribution to compare")
    feature_name: Optional[str] = None
    drift_types: List[DriftType] = Field(
        default=[DriftType.data_drift, DriftType.feature_drift]
    )
    return_details: bool = True


class DriftResult(BaseModel):
    drift_type: DriftType
    detected: bool
    score: float
    threshold: float
    technique: str
    p_value: Optional[float] = None
    detail: Optional[Dict[str, Any]] = None


class DriftResponse(BaseResponse):
    drift_detected: bool
    results: List[DriftResult]
    overall_drift_score: float
    recommendation: Optional[str] = None


# ──────────────────────────────────────────────────────────────────────────────
# Streaming / Ingestion Schemas
# ──────────────────────────────────────────────────────────────────────────────

class StreamingEvent(TenantContext):
    event_type: str
    series_id: str
    timestamp: datetime
    value: float
    feature_values: Optional[Dict[str, float]] = None
    metadata: Optional[Dict[str, Any]] = None


class IngestResponse(BaseResponse):
    series_id: str
    buffered: bool
    buffer_size: int
    trigger_inference: bool


# ──────────────────────────────────────────────────────────────────────────────
# LLM Explanation Schemas
# ──────────────────────────────────────────────────────────────────────────────

class ExplanationRequest(TenantContext):
    anomaly_context: Dict[str, Any]
    feature_attributions: Optional[Dict[str, float]] = None
    residual_stats: Optional[Dict[str, float]] = None
    temporal_pattern: Optional[str] = None
    model_confidence: Optional[float] = None


class ExplanationResponse(BaseResponse):
    summary: str
    root_causes: List[str]
    recommendations: List[str]
    confidence: float
    feature_highlights: Optional[Dict[str, float]] = None


# ──────────────────────────────────────────────────────────────────────────────
# Training Schemas
# ──────────────────────────────────────────────────────────────────────────────

class TrainingRequest(TenantContext):
    dataset_path: str
    model_type: ModelType
    horizon: int = 120
    window_size: int = 168
    epochs: int = 100
    batch_size: int = 64
    learning_rate: float = 1e-4
    quantiles: List[float] = Field(default=[0.1, 0.5, 0.9])
    use_distributed: bool = False
    run_hpo: bool = False
    experiment_name: Optional[str] = None
    tags: Optional[Dict[str, str]] = None


class TrainingResponse(BaseResponse):
    run_id: str
    experiment_id: str
    model_uri: str
    metrics: Dict[str, float]
    best_params: Optional[Dict[str, Any]] = None


# ──────────────────────────────────────────────────────────────────────────────
# Health Check
# ──────────────────────────────────────────────────────────────────────────────

class HealthResponse(BaseModel):
    status: str = "healthy"
    service: str
    version: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    dependencies: Dict[str, str] = Field(default_factory=dict)
