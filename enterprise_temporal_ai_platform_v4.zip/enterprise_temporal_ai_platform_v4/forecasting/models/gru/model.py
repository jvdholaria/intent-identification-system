"""
Enterprise Temporal AI Platform V4 — GRU Seq2Seq (Multivariate + Asset-Aware)

Changes from V3:
  - input_size  = F  (multivariate)
  - output_size = T  (multi-target)
  - Asset embedding injected into encoder initial hidden state
  - Output reshaped to [B, H, T]
"""

from __future__ import annotations
from typing import Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from shared.logging.logger import get_logger

log = get_logger("models.gru")


class GRUEncoder(nn.Module):
    def __init__(self, input_size: int, hidden_size: int, num_layers: int, dropout: float):
        super().__init__()
        self.gru = nn.GRU(
            input_size, hidden_size, num_layers,
            batch_first=True, dropout=dropout if num_layers > 1 else 0.0,
        )

    def forward(self, x: torch.Tensor, h0: Optional[torch.Tensor] = None):
        # x: [B, L, F]
        return self.gru(x, h0)   # outputs: [B, L, H], hidden: [num_layers, B, H]


class AttentionBridge(nn.Module):
    def __init__(self, hidden_size: int):
        super().__init__()
        self.w1 = nn.Linear(hidden_size, hidden_size, bias=False)
        self.w2 = nn.Linear(hidden_size, hidden_size, bias=False)
        self.v  = nn.Linear(hidden_size, 1, bias=False)

    def forward(self, decoder_state: torch.Tensor, encoder_outputs: torch.Tensor) -> torch.Tensor:
        # decoder_state: [B, 1, H],  encoder_outputs: [B, L, H]
        score   = self.v(torch.tanh(self.w1(encoder_outputs) + self.w2(decoder_state)))
        weights = F.softmax(score, dim=1)               # [B, L, 1]
        context = (weights * encoder_outputs).sum(1)    # [B, H]
        return context


class GRUDecoder(nn.Module):
    def __init__(self, hidden_size: int, output_size: int, num_layers: int, dropout: float):
        super().__init__()
        self.gru       = nn.GRU(
            hidden_size + output_size, hidden_size, num_layers,
            batch_first=True, dropout=dropout if num_layers > 1 else 0.0,
        )
        self.attention = AttentionBridge(hidden_size)
        self.fc        = nn.Linear(hidden_size * 2, output_size)
        self.dropout   = nn.Dropout(dropout)

    def forward_step(self, prev_output, hidden, encoder_outputs):
        # prev_output: [B, 1, T]
        context = self.attention(
            hidden[-1:].permute(1, 0, 2), encoder_outputs
        )                                               # [B, H]
        gru_in  = torch.cat([prev_output.squeeze(1), context], dim=-1).unsqueeze(1)
        out, hidden = self.gru(gru_in, hidden)
        pred    = self.fc(torch.cat([out.squeeze(1), context], dim=-1))  # [B, T]
        return pred, hidden


class GRUSeq2Seq(nn.Module):
    """
    V4 GRU encoder-decoder.

    Input contract:
        x:        [B, L, F]
        asset_id: [B]        (optional)

    Output contract:
        forecast: [B, H, T]
    """

    def __init__(
        self,
        input_size:    int   = 1,     # F
        hidden_size:   int   = 256,
        output_size:   int   = 1,     # T
        num_layers:    int   = 2,
        dropout:       float = 0.1,
        pred_len:      int   = 24,
        num_assets:    int   = 1,
        embedding_dim: int   = 16,
    ):
        super().__init__()
        self.pred_len    = pred_len
        self.output_size = output_size

        self.asset_embedding = nn.Embedding(num_assets, embedding_dim)
        # Project asset emb to initialise encoder hidden state
        self.asset_h0_proj   = nn.Linear(embedding_dim, hidden_size * num_layers)
        self.num_layers      = num_layers
        self.hidden_size     = hidden_size

        self.encoder = GRUEncoder(input_size, hidden_size, num_layers, dropout)
        self.decoder = GRUDecoder(hidden_size, output_size, num_layers, dropout)

        log.info(
            "gru.init",
            input_size=input_size, output_size=output_size,
            hidden_size=hidden_size, pred_len=pred_len,
        )

    def forward(
        self,
        x: torch.Tensor,
        asset_id: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        x:        [B, L, F]
        asset_id: [B]
        Returns:  [B, H, T]
        """
        x = x.float()
        B = x.size(0)

        if asset_id is None:
            asset_id = torch.zeros(B, dtype=torch.long, device=x.device)

        # ── Asset-conditioned initial hidden state ───────────────────────────
        a_emb  = self.asset_embedding(asset_id)                           # [B, emb]
        h0_flat = self.asset_h0_proj(a_emb)                               # [B, H*layers]
        h0     = h0_flat.view(B, self.num_layers, self.hidden_size)       # [B, layers, H]
        h0     = h0.permute(1, 0, 2).contiguous()                         # [layers, B, H]

        encoder_outputs, hidden = self.encoder(x, h0)

        # ── Decode ───────────────────────────────────────────────────────────
        preds         = []
        decoder_input = x[:, -1:, :self.output_size]   # seed: last obs of target channels

        for _ in range(self.pred_len):
            pred, hidden = self.decoder.forward_step(decoder_input, hidden, encoder_outputs)
            preds.append(pred)                          # [B, T]
            decoder_input = pred.unsqueeze(1)           # [B, 1, T]

        out = torch.stack(preds, dim=1)                 # [B, H, T]
        return out


# ─────────────────────────────────────────────────────────────────────────────
# Predictor Wrapper
# ─────────────────────────────────────────────────────────────────────────────

class GRUPredictor:

    def __init__(self, settings):
        self.settings = settings
        self.device   = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._model: Optional[GRUSeq2Seq] = None

    def _load(self, input_size=1, output_size=1, num_assets=1):
        if self._model is not None:
            return
        self._model = GRUSeq2Seq(
            input_size=input_size,
            output_size=output_size,
            pred_len=self.settings.FORECAST_HORIZON,
            num_assets=num_assets,
        ).to(self.device)
        self._model.eval()

    def predict(self, x, asset_id: int = 0, horizon: Optional[int] = None):
        self._load()
        arr = np.asarray(x, dtype=np.float32)
        if arr.ndim == 1:
            arr = arr[:, np.newaxis]
        tensor  = torch.tensor(arr).unsqueeze(0).to(self.device)
        aid_t   = torch.tensor([asset_id], dtype=torch.long, device=self.device)
        with torch.no_grad():
            out = self._model(tensor, aid_t)       # [1, H, T]
        result = out.squeeze(0).cpu().numpy()      # [H, T]
        H = horizon or self.settings.FORECAST_HORIZON
        if result.shape[0] >= H:
            return result[:H]
        pad = H - result.shape[0]
        return np.pad(result, ((0, pad), (0, 0)), mode="edge")
