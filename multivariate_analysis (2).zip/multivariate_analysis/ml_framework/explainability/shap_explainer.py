"""
explainability.py — SHAP-based global and local explanations for both
tree-based and deep learning models.

Why SHAP?
---------
SHAP (SHapley Additive exPlanations) provides a unified, game-theory-grounded
framework for attributing model predictions to input features. Key advantages:

  * Consistency: the same API works for tree models (TreeExplainer, exact O(TLD))
    and neural nets (GradientExplainer / DeepExplainer, approximate).
  * Additivity: SHAP values sum to the prediction, enabling debugging.
  * Local explanations: per-sample attributions reveal why a specific
    prediction was made — critical for anomaly investigation.
  * Global explanations: mean |SHAP| summarises feature importance across
    the dataset — guides feature selection and engineering.

How to use insights
-------------------
* High global SHAP → feature is generally predictive; prioritise monitoring.
* High local SHAP  → this feature drove *this* prediction; inspect for anomalies.
* Sign of SHAP     → positive = pushed prediction up; negative = pushed it down.
* Interaction plots between top-2 features reveal non-linear coupling.
* Waterfall charts help explain a single prediction to domain experts.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from ..core.config import ExplainabilityConfig, FrameworkConfig

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# SHAP tree explainer
# ---------------------------------------------------------------------------

class TreeSHAPExplainer:
    """
    Global and local SHAP explanations for tree-based models.

    Uses shap.TreeExplainer which computes *exact* Shapley values in
    polynomial time — no approximation needed for gradient-boosted trees.

    Parameters
    ----------
    estimators : list[fitted sklearn-compatible estimator]
        One fitted estimator per target (from MultiOutputTreeRegressor).
    feature_names : list[str]
    target_names : list[str]
    cfg : ExplainabilityConfig
    """

    def __init__(
        self,
        estimators: list,
        feature_names: List[str],
        target_names: List[str],
        cfg: ExplainabilityConfig,
    ) -> None:
        try:
            import shap  # type: ignore
            self._shap = shap
        except ImportError:
            raise ImportError("Install shap: pip install shap")

        self.estimators    = estimators
        self.feature_names = feature_names
        self.target_names  = target_names
        self.cfg           = cfg
        self._explainers   = {}

    def _get_explainer(self, idx: int):
        if idx not in self._explainers:
            est = self.estimators[idx]
            # TreeExplainer accepts LightGBM, XGBoost, and sklearn trees
            self._explainers[idx] = self._shap.TreeExplainer(
                est,
                feature_names=self.feature_names,
            )
        return self._explainers[idx]

    def compute_global_importance(
        self,
        X: np.ndarray,
        n_samples: Optional[int] = None,
    ) -> Dict[str, pd.DataFrame]:
        """
        Compute mean |SHAP| importance for each target.

        Returns
        -------
        dict[target_name → DataFrame(feature, importance)]
        """
        n = n_samples or self.cfg.n_background_samples
        idx = np.random.choice(len(X), min(n, len(X)), replace=False)
        X_bg = X[idx]

        results: Dict[str, pd.DataFrame] = {}
        for i, name in enumerate(self.target_names):
            explainer   = self._get_explainer(i)
            shap_values = explainer.shap_values(X_bg)
            if isinstance(shap_values, list):   # some models return list
                shap_values = shap_values[0]

            importance = np.abs(shap_values).mean(axis=0)

            # Guard: SHAP may return more/fewer values than stored feature names
            # (e.g. chain models augment features internally). Align safely.
            n = min(len(self.feature_names), len(importance))
            df = pd.DataFrame({
                "feature":    self.feature_names[:n],
                "importance": importance[:n],
            }).sort_values("importance", ascending=False)
            results[name] = df
            logger.debug("SHAP global importance computed for target '%s'.", name)

        return results

    def compute_local_explanations(
        self,
        X: np.ndarray,
        sample_indices: Optional[List[int]] = None,
    ) -> Dict[str, np.ndarray]:
        """
        Compute per-sample SHAP values.

        Parameters
        ----------
        X : (N, F) array
        sample_indices : optional list of row indices to explain

        Returns
        -------
        dict[target_name → (n_samples, n_features) SHAP array]
        """
        n = self.cfg.n_explain_samples
        idx = sample_indices or list(
            np.random.choice(len(X), min(n, len(X)), replace=False)
        )
        X_explain = X[idx]

        results: Dict[str, np.ndarray] = {}
        for i, name in enumerate(self.target_names):
            explainer   = self._get_explainer(i)
            shap_values = explainer.shap_values(X_explain)
            if isinstance(shap_values, list):
                shap_values = shap_values[0]
            results[name] = shap_values
        return results

    def plot_summary(
        self,
        X: np.ndarray,
        target_idx: int = 0,
        save_path: Optional[str] = None,
    ) -> None:
        """Beeswarm summary plot — shows distribution of SHAP values per feature."""
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            logger.warning("matplotlib not available; skipping plot.")
            return

        n  = self.cfg.n_background_samples
        bg = X[np.random.choice(len(X), min(n, len(X)), replace=False)]

        explainer   = self._get_explainer(target_idx)
        shap_values = explainer.shap_values(bg)
        if isinstance(shap_values, list):
            shap_values = shap_values[0]

        target_name = self.target_names[target_idx]
        self._shap.summary_plot(
            shap_values,
            bg,
            feature_names=self.feature_names,
            show=False,
            max_display=self.cfg.plot_top_k_features,
        )
        plt.title(f"SHAP Summary — {target_name}")

        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches="tight")
            logger.info("SHAP summary plot saved to %s", save_path)
        else:
            plt.show()
        plt.close()

    def waterfall(
        self,
        X: np.ndarray,
        sample_idx: int,
        target_idx: int = 0,
        save_path: Optional[str] = None,
    ) -> None:
        """Waterfall chart for a single prediction — ideal for debugging."""
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            return

        explainer = self._get_explainer(target_idx)
        exp = explainer(X[sample_idx : sample_idx + 1])
        self._shap.waterfall_plot(exp[0], show=False, max_display=15)
        plt.title(f"SHAP Waterfall — sample {sample_idx} — {self.target_names[target_idx]}")

        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches="tight")
        else:
            plt.show()
        plt.close()


# ---------------------------------------------------------------------------
# SHAP deep learning explainer (GradientExplainer)
# ---------------------------------------------------------------------------

class DeepSHAPExplainer:
    """
    SHAP explanations for PyTorch models via GradientExplainer.

    GradientExplainer uses a modified backpropagation (Expected Gradients)
    to approximate Shapley values — fully differentiable, works for any
    architecture.

    Parameters
    ----------
    model : trained MultiOutputForecastingModel (PyTorch Module)
    background_data : (n_bg, window, features) numpy array
        Representative background samples used as the 'reference' distribution.
    feature_names : list[str]
    target_names : list[str]
    cfg : ExplainabilityConfig
    device : torch.device
    """

    def __init__(
        self,
        model,
        background_data: np.ndarray,
        feature_names: List[str],
        target_names: List[str],
        cfg: ExplainabilityConfig,
        device,
    ) -> None:
        try:
            import shap  # type: ignore
            self._shap = shap
        except ImportError:
            raise ImportError("Install shap: pip install shap")
        try:
            import torch
            self._torch = torch
        except ImportError:
            raise ImportError("Install torch: pip install torch")

        self.model         = model
        self.feature_names = feature_names
        self.target_names  = target_names
        self.cfg           = cfg
        self.device        = device

        n_bg = min(cfg.n_background_samples, len(background_data))
        idx  = np.random.choice(len(background_data), n_bg, replace=False)
        bg   = background_data[idx]

        # GradientExplainer takes the model + background tensor
        self._bg_tensor = torch.from_numpy(bg).float().to(device)
        self._explainer = shap.GradientExplainer(model, self._bg_tensor)

    def compute_shap_values(
        self,
        X: np.ndarray,
        target_idx: int = 0,
    ) -> np.ndarray:
        """
        Compute SHAP values for the given samples.

        For sequence inputs (N, W, F), SHAP values have the same shape
        and capture the attribution across time AND features jointly.

        Returns
        -------
        shap_values : (N, W, F) array for the specified target
        """
        import torch

        n = self.cfg.n_explain_samples
        idx = np.random.choice(len(X), min(n, len(X)), replace=False)
        X_t = torch.from_numpy(X[idx]).float().to(self.device)

        # GradientExplainer returns a list of arrays, one per output
        shap_values = self._explainer.shap_values(X_t)

        if isinstance(shap_values, list):
            return shap_values[target_idx]
        return shap_values

    def feature_attribution_over_time(
        self,
        shap_values: np.ndarray,
    ) -> pd.DataFrame:
        """
        Collapse time dimension → mean |SHAP| per feature across all time steps.

        Useful for identifying which features matter most, regardless of when.

        Parameters
        ----------
        shap_values : (N, W, F)

        Returns
        -------
        DataFrame(feature, mean_abs_shap)
        """
        # Mean over samples and time steps
        importance = np.abs(shap_values).mean(axis=(0, 1))  # (F,)
        df = pd.DataFrame({
            "feature": self.feature_names[:len(importance)],
            "importance": importance,
        }).sort_values("importance", ascending=False)
        return df

    def time_step_attribution(
        self,
        shap_values: np.ndarray,
    ) -> pd.DataFrame:
        """
        Collapse feature dimension → mean |SHAP| per time step.

        Shows WHICH part of the look-back window the model relies on most —
        useful for diagnosing lag sensitivity.

        Parameters
        ----------
        shap_values : (N, W, F)

        Returns
        -------
        DataFrame(time_step, mean_abs_shap)  — step 0 is oldest
        """
        importance = np.abs(shap_values).mean(axis=(0, 2))  # (W,)
        W = len(importance)
        df = pd.DataFrame({
            "time_step": list(range(-W + 1, 1)),   # negative → past
            "importance": importance,
        })
        return df


# ---------------------------------------------------------------------------
# High-level explainability orchestrator
# ---------------------------------------------------------------------------

class ExplainabilityPipeline:
    """
    Unified entry point that routes to tree or deep SHAP explainers
    depending on which models are present.

    Usage
    -----
    >>> exp = ExplainabilityPipeline(cfg, feature_names, target_names)
    >>> exp.explain_tree(estimators, X_test)
    >>> exp.explain_deep(deep_trainer.model, X_seq_test)
    >>> report = exp.generate_report(output_dir="./outputs/shap")
    """

    def __init__(
        self,
        config: FrameworkConfig,
        feature_names: List[str],
        target_names: List[str],
    ) -> None:
        self.cfg           = config.explainability
        self.feature_names = feature_names
        self.target_names  = target_names
        self._tree_exp: Optional[TreeSHAPExplainer]  = None
        self._deep_exp: Optional[DeepSHAPExplainer]  = None
        self._tree_global: Optional[Dict]            = None
        self._deep_global: Optional[pd.DataFrame]    = None

    def explain_tree(
        self,
        estimators: list,
        X: np.ndarray,
    ) -> Dict[str, pd.DataFrame]:
        """Compute and cache global SHAP importances for tree models."""
        self._tree_exp = TreeSHAPExplainer(
            estimators, self.feature_names, self.target_names, self.cfg
        )
        self._tree_global = self._tree_exp.compute_global_importance(X)
        logger.info("Tree SHAP explanations ready.")
        return self._tree_global

    def explain_deep(
        self,
        model,
        X_seq: np.ndarray,
        device,
        target_idx: int = 0,
    ) -> pd.DataFrame:
        """Compute and cache feature attributions for the deep model."""
        self._deep_exp = DeepSHAPExplainer(
            model=model,
            background_data=X_seq,
            feature_names=self.feature_names,
            target_names=self.target_names,
            cfg=self.cfg,
            device=device,
        )
        shap_vals = self._deep_exp.compute_shap_values(X_seq, target_idx=target_idx)
        self._deep_global = self._deep_exp.feature_attribution_over_time(shap_vals)
        logger.info("Deep SHAP explanations ready.")
        return self._deep_global

    def generate_report(self, output_dir: str) -> None:
        """Save all computed SHAP artefacts to output_dir."""
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)

        if self._tree_global:
            for target, df in self._tree_global.items():
                path = out / f"tree_shap_{target}.csv"
                df.to_csv(path, index=False)
                logger.info("Saved %s", path)

        if self._deep_global is not None:
            path = out / "deep_shap_feature_importance.csv"
            self._deep_global.to_csv(path, index=False)
            logger.info("Saved %s", path)

        logger.info("SHAP report saved to %s", output_dir)

    # ------------------------------------------------------------------
    # Interpretation guidance (printed to log for domain experts)
    # ------------------------------------------------------------------

    @staticmethod
    def interpretation_guide() -> str:
        return """
==================================================================
             SHAP INTERPRETATION GUIDE
==================================================================
Global importance  (mean |SHAP|)
  -> High value: feature consistently drives predictions.
  -> Low value : feature adds little signal; consider pruning.

Local explanation  (per-sample SHAP)
  + positive SHAP -> pushed prediction HIGHER than baseline.
  - negative SHAP -> pushed prediction LOWER than baseline.

Time-step attribution (deep models)
  -> Spike at step -1: model mainly uses the last observation.
  -> Spread across steps: long-range temporal dependency exists.

Debugging workflow
  1. Inspect samples where error is largest.
  2. Run waterfall chart -- which feature drove the error?
  3. Check that feature for data quality issues (gaps, spikes).
  4. If spurious feature has high global SHAP -> investigate
     whether it is a proxy for the target (leakage risk).
==================================================================
        """

