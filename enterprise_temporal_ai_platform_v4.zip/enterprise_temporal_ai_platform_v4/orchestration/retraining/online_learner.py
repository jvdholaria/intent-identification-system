"""
Enterprise Temporal AI Platform — Online Learning

Implements:
- Streaming fine-tuning (mini-batch gradient updates on live data)
- Incremental learning with elastic weight consolidation (EWC)
- Drift-triggered retraining scheduler
- Scheduled retraining via cron-like triggers
"""

from __future__ import annotations

import asyncio
import time
from collections import deque
from typing import Deque, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn

from shared.config.settings import settings
from shared.logging.logger import get_logger

log = get_logger("orchestration.online_learning")


# ─────────────────────────────────────────────────────────────────────────────
# Streaming Fine-Tuner
# ─────────────────────────────────────────────────────────────────────────────

class StreamingFineTuner:
    """
    Continuously fine-tunes a model on an incoming stream of (x, y) pairs.

    Uses a sliding replay buffer to prevent catastrophic forgetting
    and only performs updates when enough new samples have arrived.
    """

    def __init__(
        self,
        model: nn.Module,
        loss_fn: nn.Module,
        learning_rate: float = 1e-5,
        buffer_size: int = 512,
        update_every_n: int = 64,
        max_steps_per_update: int = 5,
        device: Optional[str] = None,
    ):
        self.model = model
        self.loss_fn = loss_fn
        self.lr = learning_rate
        self.buffer: Deque[Tuple[np.ndarray, np.ndarray]] = deque(maxlen=buffer_size)
        self.update_every = update_every_n
        self.max_steps = max_steps_per_update
        self.device = torch.device(
            device or ("cuda" if torch.cuda.is_available() else "cpu")
        )
        self.model.to(self.device)
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(), lr=self.lr, weight_decay=1e-5
        )
        self._new_samples = 0
        self._total_updates = 0

    def push(self, x: np.ndarray, y: np.ndarray) -> bool:
        """
        Push a new (input, target) pair into the buffer.
        Returns True if a model update was triggered.
        """
        self.buffer.append((x, y))
        self._new_samples += 1

        if self._new_samples >= self.update_every:
            self._perform_update()
            self._new_samples = 0
            return True
        return False

    def _perform_update(self):
        """Mini-batch gradient update from replay buffer."""
        if len(self.buffer) < self.update_every:
            return

        self.model.train()
        indices = np.random.choice(len(self.buffer), self.update_every, replace=False)
        batch = [self.buffer[i] for i in indices]
        xs = torch.tensor(
            np.stack([b[0] for b in batch]), dtype=torch.float32
        ).to(self.device)
        ys = torch.tensor(
            np.stack([b[1] for b in batch]), dtype=torch.float32
        ).to(self.device)

        total_loss = 0.0
        for _ in range(self.max_steps):
            self.optimizer.zero_grad()
            preds = self.model(xs.unsqueeze(-1) if xs.dim() == 2 else xs)
            # Expand preds if needed for quantile loss
            if preds.dim() == 2 and hasattr(self.loss_fn, "quantiles"):
                preds = preds.unsqueeze(-1).expand(-1, -1, len(self.loss_fn.quantiles))
            loss = self.loss_fn(preds, ys)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            self.optimizer.step()
            total_loss += float(loss)

        avg_loss = total_loss / self.max_steps
        self._total_updates += 1
        self.model.eval()
        log.info(
            "online.update",
            update_n=self._total_updates,
            avg_loss=round(avg_loss, 4),
            buffer_size=len(self.buffer),
        )

    def get_stats(self) -> Dict:
        return {
            "buffer_size": len(self.buffer),
            "total_updates": self._total_updates,
            "pending_samples": self._new_samples,
        }


# ─────────────────────────────────────────────────────────────────────────────
# Elastic Weight Consolidation (EWC) — prevents catastrophic forgetting
# ─────────────────────────────────────────────────────────────────────────────

class EWCRegulariser:
    """
    Adds an EWC penalty term to the loss to preserve important weights
    learned on previous data. Essential for continual/incremental learning.

    L_EWC = L_task + λ/2 * Σ F_i * (θ_i - θ*_i)²

    where F_i are the Fisher information diagonal estimates and θ*_i are
    the optimal weights from the previous task.
    """

    def __init__(self, model: nn.Module, lambda_: float = 1000.0):
        self.model = model
        self.lambda_ = lambda_
        self._fisher: Optional[Dict[str, torch.Tensor]] = None
        self._optimal_params: Optional[Dict[str, torch.Tensor]] = None

    def consolidate(
        self,
        dataloader: torch.utils.data.DataLoader,
        loss_fn: nn.Module,
        device: str = "cpu",
    ):
        """
        Compute and store Fisher information diagonal and current parameters.
        Call after completing training on a task before introducing new data.
        """
        log.info("ewc.consolidation.start")
        self.model.eval()
        fisher: Dict[str, torch.Tensor] = {
            n: torch.zeros_like(p)
            for n, p in self.model.named_parameters()
            if p.requires_grad
        }

        for x, y in dataloader:
            x, y = x.to(device), y.to(device)
            self.model.zero_grad()
            output = self.model(x.unsqueeze(-1) if x.dim() == 2 else x)
            if output.dim() == 2:
                output = output.unsqueeze(-1).expand(-1, -1, 3)
            loss = loss_fn(output, y)
            loss.backward()
            for n, p in self.model.named_parameters():
                if p.requires_grad and p.grad is not None:
                    fisher[n] += p.grad.data.clone() ** 2

        n_batches = len(dataloader)
        self._fisher = {n: f / n_batches for n, f in fisher.items()}
        self._optimal_params = {
            n: p.data.clone()
            for n, p in self.model.named_parameters()
            if p.requires_grad
        }
        log.info("ewc.consolidation.done")

    def penalty(self) -> torch.Tensor:
        """Compute EWC regularisation penalty term."""
        if self._fisher is None or self._optimal_params is None:
            return torch.tensor(0.0)
        penalty = torch.tensor(0.0)
        for n, p in self.model.named_parameters():
            if n in self._fisher:
                penalty += (
                    self._fisher[n] * (p - self._optimal_params[n]) ** 2
                ).sum()
        return self.lambda_ / 2.0 * penalty


# ─────────────────────────────────────────────────────────────────────────────
# Drift-Triggered Retraining Scheduler
# ─────────────────────────────────────────────────────────────────────────────

class RetrainingScheduler:
    """
    Monitors drift signals and performance degradation from Redis
    and schedules retraining jobs accordingly.

    Triggers retraining when:
    1. Drift score exceeds threshold
    2. Validation loss degrades by > degradation_pct
    3. Scheduled interval has elapsed (weekly)
    """

    def __init__(
        self,
        drift_threshold: float = 0.4,
        degradation_pct: float = 0.2,
        check_interval_s: int = 300,  # 5 minutes
    ):
        self.drift_threshold = drift_threshold
        self.degradation_pct = degradation_pct
        self.check_interval_s = check_interval_s
        self._baseline_loss: Optional[float] = None
        self._last_retrain_ts: float = 0.0
        self._weekly_interval_s: float = 7 * 24 * 3600

    async def run(self, tenant_id: str, redis_url: str):
        """
        Async monitoring loop. Runs indefinitely, checking every
        check_interval_s seconds.
        """
        import redis.asyncio as aioredis
        r = await aioredis.from_url(redis_url, decode_responses=True)
        log.info("retraining_scheduler.started", tenant=tenant_id)

        while True:
            try:
                trigger, reason = await self._check_triggers(r, tenant_id)
                if trigger:
                    await self._dispatch_retrain(tenant_id, reason)
            except Exception as exc:
                log.error("scheduler.check_failed", exc=str(exc))
            await asyncio.sleep(self.check_interval_s)

    async def _check_triggers(
        self,
        redis,
        tenant_id: str,
    ) -> Tuple[bool, str]:
        """Return (should_retrain, reason)."""
        # ── Drift check ───────────────────────────────────────────────────────
        drift_key = f"temporal:tenant:{tenant_id}:drift:latest"
        raw = await redis.get(drift_key)
        if raw:
            drift_score = float(raw)
            if drift_score > self.drift_threshold:
                log.warning(
                    "scheduler.drift_trigger",
                    tenant=tenant_id,
                    score=drift_score,
                )
                return True, f"drift_score={drift_score:.3f} > threshold={self.drift_threshold}"

        # ── Performance degradation check ─────────────────────────────────────
        loss_key = f"temporal:tenant:{tenant_id}:val_loss:latest"
        raw_loss = await redis.get(loss_key)
        if raw_loss and self._baseline_loss is not None:
            current_loss = float(raw_loss)
            if current_loss > self._baseline_loss * (1 + self.degradation_pct):
                return True, f"val_loss_degraded={current_loss:.4f} baseline={self._baseline_loss:.4f}"
            if self._baseline_loss is None:
                self._baseline_loss = current_loss

        # ── Weekly schedule check ─────────────────────────────────────────────
        if time.time() - self._last_retrain_ts > self._weekly_interval_s:
            return True, "scheduled_weekly"

        return False, ""

    async def _dispatch_retrain(self, tenant_id: str, reason: str):
        """Publish retraining job to Redis queue for Celery workers."""
        import redis.asyncio as aioredis
        import json
        r = await aioredis.from_url(settings.REDIS_URL, decode_responses=True)
        job = json.dumps({
            "tenant_id": tenant_id,
            "reason": reason,
            "triggered_at": time.time(),
        })
        await r.lpush(f"temporal:tenant:{tenant_id}:retrain_queue", job)
        self._last_retrain_ts = time.time()
        log.info("scheduler.retrain_dispatched", tenant=tenant_id, reason=reason)
