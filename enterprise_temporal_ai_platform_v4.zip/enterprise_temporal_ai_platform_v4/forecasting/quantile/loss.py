"""
Enterprise Temporal AI Platform — Quantile Loss

Implements pinball / quantile loss for P10/P50/P90 training.
"""

from __future__ import annotations

from typing import List

import torch
import torch.nn as nn


class QuantileLoss(nn.Module):
    """
    Pinball (quantile) loss supporting multiple quantile levels.

    For quantile q and error e = y - y_hat:
        L(q, e) = max(q * e, (q - 1) * e)
    """

    def __init__(self, quantiles: List[float] = None):
        super().__init__()
        self.quantiles = quantiles or [0.1, 0.5, 0.9]

    def forward(
        self,
        preds: torch.Tensor,   # (batch, horizon, num_quantiles)
        target: torch.Tensor,  # (batch, horizon)
    ) -> torch.Tensor:
        losses = []
        for i, q in enumerate(self.quantiles):
            errors = target - preds[:, :, i]  # (batch, horizon)
            loss = torch.max((q - 1) * errors, q * errors)   # (batch, horizon)
            losses.append(loss.unsqueeze(2))
        # losses: list of (batch, horizon, 1)
        all_losses = torch.cat(losses, dim=2)   # (batch, horizon, num_quantiles)
        return torch.mean(torch.sum(all_losses, dim=2))


class WeightedQuantileLoss(nn.Module):
    """
    Quantile loss with custom per-quantile weights.
    Useful to penalise under/over-forecasting asymmetrically.
    """

    def __init__(
        self,
        quantiles: List[float] = None,
        weights: List[float] = None,
    ):
        super().__init__()
        self.quantiles = quantiles or [0.1, 0.5, 0.9]
        self.weights = weights or [1.0] * len(self.quantiles)
        assert len(self.quantiles) == len(self.weights)

    def forward(self, preds: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        losses = []
        for i, (q, w) in enumerate(zip(self.quantiles, self.weights)):
            errors = target - preds[:, :, i]
            loss = w * torch.max((q - 1) * errors, q * errors)
            losses.append(loss.unsqueeze(2))
        return torch.mean(torch.sum(torch.cat(losses, dim=2), dim=2))


class CombinedForecastLoss(nn.Module):
    """
    Combines MSE (point estimate) with quantile loss for joint training.

    total_loss = alpha * MSE(p50, target) + (1 - alpha) * QuantileLoss(all_quantiles, target)
    """

    def __init__(
        self,
        quantiles: List[float] = None,
        alpha: float = 0.5,
    ):
        super().__init__()
        self.quantile_loss = QuantileLoss(quantiles or [0.1, 0.5, 0.9])
        self.alpha = alpha
        self.mse = nn.MSELoss()

    def forward(
        self,
        preds: torch.Tensor,   # (batch, horizon, num_quantiles)
        target: torch.Tensor,  # (batch, horizon)
    ) -> torch.Tensor:
        # p50 is the median quantile (index 1 in [0.1, 0.5, 0.9])
        p50_idx = len(self.quantile_loss.quantiles) // 2
        point_loss = self.mse(preds[:, :, p50_idx], target)
        q_loss = self.quantile_loss(preds, target)
        return self.alpha * point_loss + (1 - self.alpha) * q_loss
