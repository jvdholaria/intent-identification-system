"""
pipeline.py — Master orchestrator that wires together all subsystems.

Separation of concerns
-----------------------
  DataIngestionPipeline  → raw data to aligned DataFrame
  PreprocessingPipeline  → DataFrame to (X, y) numpy arrays
  MultiOutputTreeRegressor / DeepModelTrainer → training
  ModelEvaluator         → metrics + leakage audit
  ExplainabilityPipeline → SHAP analysis
  InferenceEngine        → serving

The MLPipeline class provides a clean high-level API:

  pipeline = MLPipeline(config)
  pipeline.fit(source_dfs)           # full train / val / test cycle
  result   = pipeline.predict(new_df)  # inference on new data
  pipeline.save("./checkpoint")        # serialise all state
  pipeline.load("./checkpoint")        # restore from disk
"""

from __future__ import annotations

import json
import logging
import os
import pickle
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from .core.config import FrameworkConfig
from .core.data_ingestion import DataIngestionPipeline, TemporalSplitter
from .core.preprocessing import PreprocessingPipeline
from .evaluation.metrics import ModelEvaluator, audit_temporal_leakage
from .explainability.shap_explainer import ExplainabilityPipeline
from .inference.engine import InferenceEngine, ModelRegistry, PredictionResult
from .models.tree_models import MultiOutputTreeRegressor
from .anomaly.detector import AnomalyDetectionPipeline, AnomalyResult

logger = logging.getLogger(__name__)


class MLPipeline:
    """
    End-to-end multi-input, multi-output machine learning pipeline.

    Modes
    -----
    "tree"     : gradient-boosted / random forest models only
    "deep"     : PyTorch sequence models only
    "both"     : train both, report separate metrics
    "ensemble" : blend tree and deep predictions

    Prediction types
    ----------------
    "static"   : flat features → targets (no temporal structure)
    "temporal" : sliding window sequences → targets

    Parameters
    ----------
    config : FrameworkConfig
        Master configuration driving every subsystem.

    Usage
    -----
    >>> cfg      = FrameworkConfig(targets=["y1", "y2"], mode="tree")
    >>> pipeline = MLPipeline(cfg)
    >>> pipeline.fit({"sensors": df_sensors, "logs": df_logs})
    >>> result   = pipeline.predict(new_df)
    >>> print(result.to_dataframe())
    """

    def __init__(self, config: FrameworkConfig) -> None:
        self.cfg     = config
        self.targets = config.targets

        # Sub-systems (populated during fit)
        self._ingestion:      Optional[DataIngestionPipeline]    = None
        self._splitter:       Optional[TemporalSplitter]         = None
        self._preprocessor:   Optional[PreprocessingPipeline]    = None
        self._tree_model:     Optional[MultiOutputTreeRegressor] = None
        self._deep_trainer    = None
        self._evaluator:      Optional[ModelEvaluator]           = None
        self._explainer:      Optional[ExplainabilityPipeline]   = None
        self._registry:       Optional[ModelRegistry]            = None
        self._engine:         Optional[InferenceEngine]          = None
        self._anomaly:        Optional[AnomalyDetectionPipeline] = None
        self._is_fit:          bool                              = False

        # Evaluation reports accumulated during training
        self.eval_reports: Dict[str, pd.DataFrame] = {}

    # ------------------------------------------------------------------
    # Fit
    # ------------------------------------------------------------------

    def fit(
        self,
        source_dfs: Optional[Dict[str, pd.DataFrame]] = None,
        merged_df:  Optional[pd.DataFrame] = None,
    ) -> "MLPipeline":
        """
        Train the full pipeline.

        Provide either `source_dfs` (dict of raw DataFrames per source name)
        or `merged_df` (pre-merged single DataFrame on the common time grid).
        """
        logger.info("═══ MLPipeline.fit() — mode=%s ═══", self.cfg.mode)

        # ── 1. Ingest & align ────────────────────────────────────────────
        self._ingestion = DataIngestionPipeline(self.cfg)
        self._splitter  = TemporalSplitter(self.cfg)

        if merged_df is None:
            merged_df = self._ingestion.run(source_dfs)

        # ── 2. Temporal split ────────────────────────────────────────────
        train_df, val_df, test_df = self._splitter.split(merged_df)
        logger.info("Split sizes — train=%d  val=%d  test=%d",
                    len(train_df), len(val_df), len(test_df))

        # ── 3. Preprocess ────────────────────────────────────────────────
        self._preprocessor = PreprocessingPipeline(self.cfg, self.targets)
        X_train, y_train, feat_names = self._preprocessor.fit_transform(train_df)
        X_val,   y_val,   _          = self._preprocessor.transform(val_df)
        X_test,  y_test,  _          = self._preprocessor.transform(test_df)

        # Leakage audit — timestamps
        if isinstance(merged_df.index, pd.DatetimeIndex):
            audit_temporal_leakage(
                train_df.index.values,
                val_df.index.values,
                test_df.index.values,
            )

        # ── 4. Train models ──────────────────────────────────────────────
        mode = self.cfg.mode

        if mode in ("tree", "both", "ensemble"):
            self._fit_tree(X_train, y_train, X_val, y_val, feat_names)
            tree_preds = self._tree_model.predict(X_test)
            self.eval_reports["tree_test"] = self._evaluate(
                y_test, tree_preds, prefix="tree_test_", feat_names=feat_names
            )

        if mode in ("deep", "both", "ensemble"):
            self._fit_deep(
                train_df, val_df, test_df,
                X_train, y_train, X_val, y_val, X_test, y_test, feat_names
            )

        if mode == "ensemble":
            self._fit_ensemble(X_test, y_test)

        # ── 5. Set up inference engine ───────────────────────────────────
        self._registry = ModelRegistry()
        active_model   = self._tree_model if mode in ("tree", "both", "ensemble") else None
        if active_model:
            self._registry.register("v1_tree", active_model)
            self._registry.set_active("v1_tree")

        self._engine = InferenceEngine(self.cfg, self._preprocessor, self._registry)

        # ── 6. Explainability ────────────────────────────────────────────
        if self.cfg.explainability.enabled:
            self._run_explainability(X_test, feat_names)

        # ── 7. Anomaly detection ─────────────────────────────────────────
        if self.cfg.anomaly.enabled:
            self._fit_anomaly_detection(X_train, y_train, X_test, y_test, feat_names)

        self._is_fit = True
        logger.info("═══ MLPipeline.fit() complete ═══")
        self._print_summary()
        return self

    # ------------------------------------------------------------------
    # Internal training helpers
    # ------------------------------------------------------------------

    def _fit_tree(self, X_tr, y_tr, X_vl, y_vl, feat_names):
        logger.info("── Training tree model ──")
        self._tree_model = MultiOutputTreeRegressor(self.cfg)
        self._tree_model.fit(
            X_tr, y_tr,
            X_val=X_vl, y_val=y_vl,
            feature_names=feat_names,
        )

    def _fit_deep(self, train_df, val_df, test_df,
                  X_tr, y_tr, X_vl, y_vl, X_ts, y_ts, feat_names):
        logger.info("── Training deep model ──")
        try:
            from .models.deep_models import DeepModelTrainer
        except ImportError:
            logger.warning("PyTorch not available; skipping deep model.")
            return

        if self.cfg.prediction_type == "temporal":
            # Build sequences for deep model
            X_seq_tr, y_seq_tr, _, _ = self._ingestion.build_sequences(train_df, self.targets)
            X_seq_vl, y_seq_vl, _, _ = self._ingestion.build_sequences(val_df,   self.targets)
            X_seq_ts, y_seq_ts, _, _ = self._ingestion.build_sequences(test_df,  self.targets)

            # Apply scaler to sequences
            X_seq_tr = self._preprocessor.transform_sequences(X_seq_tr)
            X_seq_vl = self._preprocessor.transform_sequences(X_seq_vl)
            X_seq_ts = self._preprocessor.transform_sequences(X_seq_ts)

            n_temporal = X_seq_tr.shape[2]
            n_static   = 1
        else:
            # Treat flat X as single-step sequences
            X_seq_tr = X_tr[:, np.newaxis, :]
            X_seq_vl = X_vl[:, np.newaxis, :]
            X_seq_ts = X_ts[:, np.newaxis, :]
            y_seq_tr, y_seq_vl, y_seq_ts = y_tr, y_vl, y_ts
            n_temporal = X_seq_tr.shape[2]
            n_static   = 1

        self._deep_trainer = DeepModelTrainer(
            config=self.cfg,
            n_temporal_features=n_temporal,
            n_static_features=n_static,
            n_targets=len(self.targets),
        )
        self._deep_trainer.fit(X_seq_tr, y_seq_tr, X_seq_vl, y_seq_vl)

        deep_preds = self._deep_trainer.predict(X_seq_ts)
        self.eval_reports["deep_test"] = self._evaluate(
            y_seq_ts, deep_preds, prefix="deep_test_", feat_names=feat_names
        )

    def _fit_ensemble(self, X_test, y_test):
        """Blend tree and deep predictions via configured weights."""
        ecfg = self.cfg.ensemble
        if "tree_test" not in self.eval_reports or "deep_test" not in self.eval_reports:
            logger.warning("Cannot build ensemble — one model missing.")
            return

        w_tree = ecfg.weights.get("tree", 0.5) if ecfg.weights else 0.5
        w_deep = 1.0 - w_tree

        tree_preds = self._tree_model.predict(X_test)
        deep_len   = min(len(tree_preds), len(self._deep_trainer.predict(
            X_test[:, np.newaxis, :]
        )))
        deep_preds = self._deep_trainer.predict(X_test[:deep_len, np.newaxis, :])
        tree_preds = tree_preds[:deep_len]
        y_test_ens = y_test[:deep_len]

        ensemble_preds = w_tree * tree_preds + w_deep * deep_preds
        self.eval_reports["ensemble_test"] = self._evaluate(
            y_test_ens, ensemble_preds, prefix="ensemble_test_"
        )

    def _evaluate(self, y_true, y_pred, prefix="", feat_names=None):
        if self._evaluator is None:
            self._evaluator = ModelEvaluator(
                self.cfg.training.metrics, self.targets
            )
        return self._evaluator.evaluate(y_true, y_pred, prefix=prefix)

    def _run_explainability(self, X_test, feat_names):
        logger.info("── Running SHAP explainability ──")
        self._explainer = ExplainabilityPipeline(
            self.cfg, feat_names, self.targets
        )
        out_dir = os.path.join(self.cfg.output_dir, "shap")

        if self._tree_model is not None:
            estimators = self._tree_model.get_estimators()
            self._explainer.explain_tree(estimators, X_test)

        self._explainer.generate_report(out_dir)
        print(ExplainabilityPipeline.interpretation_guide())

    def _fit_anomaly_detection(
        self,
        X_train:  np.ndarray,
        y_train:  np.ndarray,
        X_test:   np.ndarray,
        y_test:   np.ndarray,
        feat_names: list,
    ) -> None:
        """
        Fit the anomaly detection pipeline on training features and,
        if a predictive model exists, calibrate the residual detector
        using training-set predictions.

        Called automatically at the end of fit() when anomaly.enabled=True.
        """
        logger.info("── Fitting anomaly detection ──")
        self._anomaly = AnomalyDetectionPipeline(
            config=self.cfg.anomaly,
            feature_names=feat_names,
            target_names=self.targets,
        )

        # Obtain training predictions for residual detector calibration
        y_train_pred = None
        if self._tree_model is not None:
            y_train_pred = self._tree_model.predict(X_train)

        self._anomaly.fit(
            X_train=X_train,
            y_train_true=y_train if y_train_pred is not None else None,
            y_train_pred=y_train_pred,
        )

        # Run detection on test set and log summary
        if y_train_pred is not None and self.cfg.anomaly.use_residual_detection:
            y_test_pred = self._tree_model.predict(X_test)
            ad_result   = self._anomaly.detect_with_residuals(X_test, y_test, y_test_pred)
        else:
            ad_result = self._anomaly.detect(X_test)

        print("\n" + ad_result.summary())

        # Optionally save anomaly report
        out_dir = os.path.join(self.cfg.output_dir, "anomaly")
        os.makedirs(out_dir, exist_ok=True)
        ad_result.to_dataframe().to_csv(
            os.path.join(out_dir, "test_anomaly_report.csv"), index=False
        )
        logger.info("Anomaly report saved to %s/test_anomaly_report.csv", out_dir)

    def _print_summary(self):
        print("\n" + "═" * 60)
        print("  MLPipeline Training Summary")
        print("═" * 60)
        for report_name, df in self.eval_reports.items():
            print(f"\n  [{report_name}]")
            print(df.to_string())
        print("═" * 60 + "\n")

    # ------------------------------------------------------------------
    # Anomaly detection (public API)
    # ------------------------------------------------------------------

    def detect_anomalies(
        self,
        df: pd.DataFrame,
        include_residuals: bool = False,
        chunk_size: int = 10_000,
    ) -> "AnomalyResult":
        """
        Run anomaly detection on new data.

        Parameters
        ----------
        df : DataFrame
            New data with the same schema as training.
        include_residuals : bool
            If True and a predictive model is available, also flag samples
            whose prediction error is anomalously high. This requires the
            target columns to be present in df.
        chunk_size : int
            Rows per preprocessing chunk for large DataFrames.

        Returns
        -------
        AnomalyResult
            Contains anomaly scores, binary labels, severity levels,
            per-detector scores, and per-feature contributions.

        Example
        -------
        >>> result = pipeline.detect_anomalies(new_df)
        >>> print(result.summary())
        >>> df_out = result.to_dataframe()
        >>> # Inspect the worst anomalies
        >>> critical = df_out[df_out["severity"] == "critical"]
        """
        if not self._is_fit:
            raise RuntimeError("Pipeline not fitted. Call .fit() first.")
        if self._anomaly is None:
            raise RuntimeError(
                "Anomaly detection not enabled. Set anomaly.enabled=True in config."
            )

        # Preprocess in chunks, then concatenate X arrays
        X_chunks, ts_chunks, y_chunks = [], [], []
        for start in range(0, len(df), chunk_size):
            chunk = df.iloc[start : start + chunk_size]
            X_c, y_c, _ = self._preprocessor.transform(chunk)
            X_chunks.append(X_c)
            y_chunks.append(y_c)
            if isinstance(df.index, pd.DatetimeIndex):
                ts_chunks.append(chunk.index.values)

        X  = np.concatenate(X_chunks, axis=0)
        ts = np.concatenate(ts_chunks) if ts_chunks else None

        if include_residuals and self._tree_model is not None:
            y_true = np.concatenate(y_chunks, axis=0)
            y_pred = self._tree_model.predict(X)
            result = self._anomaly.detect_with_residuals(X, y_true, y_pred, timestamps=ts)
        else:
            result = self._anomaly.detect(X, timestamps=ts)

        return result

    # ------------------------------------------------------------------
    # Predict
    # ------------------------------------------------------------------

    def predict(
        self,
        df: pd.DataFrame,
        chunk_size: int = 10_000,
    ) -> PredictionResult:
        """
        Run batch inference on new data.

        Parameters
        ----------
        df : DataFrame with the same schema as training data.

        Returns
        -------
        PredictionResult
        """
        if not self._is_fit:
            raise RuntimeError("Pipeline not fitted. Call .fit() first.")
        return self._engine.predict_batch(df, chunk_size=chunk_size)

    def predict_realtime(self, row: Dict[str, float], **kwargs) -> PredictionResult:
        """Single-sample real-time prediction."""
        if not self._is_fit:
            raise RuntimeError("Pipeline not fitted. Call .fit() first.")
        return self._engine.predict_realtime(row, **kwargs)

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def save(self, directory: str) -> None:
        """Serialise all pipeline state to directory."""
        out = Path(directory)
        out.mkdir(parents=True, exist_ok=True)

        # Config
        with open(out / "config.json", "w") as f:
            # Simple JSON dump — extend with dataclasses-json for full support
            f.write(json.dumps(self.cfg.__dict__, default=str, indent=2))

        # Preprocessor
        with open(out / "preprocessor.pkl", "wb") as f:
            pickle.dump(self._preprocessor, f)

        # Tree model
        if self._tree_model is not None:
            with open(out / "tree_model.pkl", "wb") as f:
                pickle.dump(self._tree_model, f)

        # Deep model
        if self._deep_trainer is not None:
            self._deep_trainer.save(str(out / "deep_model.pt"))

        # Anomaly detection pipeline
        if self._anomaly is not None:
            self._anomaly.save(str(out / "anomaly_pipeline.pkl"))

        logger.info("Pipeline saved to %s", directory)

    def load(self, directory: str) -> "MLPipeline":
        """Restore pipeline from directory."""
        out = Path(directory)

        with open(out / "preprocessor.pkl", "rb") as f:
            self._preprocessor = pickle.load(f)

        if (out / "tree_model.pkl").exists():
            with open(out / "tree_model.pkl", "rb") as f:
                self._tree_model = pickle.load(f)
            self._registry = ModelRegistry()
            self._registry.register("v1_tree", self._tree_model)
            self._registry.set_active("v1_tree")
            self._engine = InferenceEngine(self.cfg, self._preprocessor, self._registry)

        if (out / "anomaly_pipeline.pkl").exists():
            self._anomaly = AnomalyDetectionPipeline(
                self.cfg.anomaly, [], self.targets
            ).load(str(out / "anomaly_pipeline.pkl"))

        self._is_fit = True
        logger.info("Pipeline loaded from %s", directory)
        return self
