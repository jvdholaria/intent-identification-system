"""
Enterprise Temporal AI Platform V4 — TFT (Multivariate + Asset-Aware)

Changes from V3:
  - num_dynamic_vars = F  (multivariate input)
  - Asset id used as static context variable via nn.Embedding
  - Output: [B, H, T]
"""

from __future__ import annotations
from typing import Optional

import numpy as np
import torch
import torch.nn as nn

from shared.logging.logger import get_logger

log = get_logger("models.tft")


class GatedResidualNetwork(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, dropout=0.1):
        super().__init__()
        self.fc1  = nn.Linear(input_dim, hidden_dim)
        self.fc2  = nn.Linear(hidden_dim, output_dim)
        self.gate = nn.Linear(hidden_dim, output_dim)
        self.skip = nn.Linear(input_dim, output_dim) if input_dim != output_dim else nn.Identity()
        self.norm = nn.LayerNorm(output_dim)
        self.drop = nn.Dropout(dropout)
        self.elu  = nn.ELU()
        self.sig  = nn.Sigmoid()

    def forward(self, x):
        h    = self.elu(self.fc1(x))
        eta  = self.fc2(self.drop(h))
        gate = self.sig(self.gate(h))
        return self.norm(gate * eta + self.skip(x))


class VariableSelectionNetwork(nn.Module):
    def __init__(self, num_vars, d_model, dropout=0.1):
        super().__init__()
        self.grns        = nn.ModuleList([GatedResidualNetwork(d_model, d_model, d_model, dropout) for _ in range(num_vars)])
        self.softmax_grn = GatedResidualNetwork(num_vars * d_model, d_model, num_vars, dropout)
        self.softmax     = nn.Softmax(dim=-1)

    def forward(self, x):
        # x: [B, L, num_vars, d_model]
        processed = torch.stack([self.grns[i](x[..., i, :]) for i in range(len(self.grns))], dim=-2)
        flat      = x.reshape(x.size(0), x.size(1), -1)
        weights   = self.softmax(self.softmax_grn(flat))               # [B, L, num_vars]
        out       = (weights.unsqueeze(-1) * processed).sum(dim=-2)   # [B, L, d_model]
        return out


class TFTModel(nn.Module):
    """
    V4 TFT: multi-asset, multivariate.

    Input:
        x:        [B, L, F]
        asset_id: [B]

    Output:
        forecast: [B, H, T]
    """

    def __init__(
        self,
        seq_len:           int   = 168,
        pred_len:          int   = 24,
        d_model:           int   = 128,
        n_heads:           int   = 4,
        num_layers:        int   = 2,
        dropout:           float = 0.1,
        num_dynamic_vars:  int   = 1,   # F
        num_targets:       int   = 1,   # T
        num_assets:        int   = 1,
        embedding_dim:     int   = 16,
    ):
        super().__init__()

        self.pred_len    = pred_len
        self.num_targets = num_targets
        self.d_model     = d_model

        # ── Asset embedding as static context ────────────────────────────────
        self.asset_embedding = nn.Embedding(num_assets, embedding_dim)
        self.static_grn      = GatedResidualNetwork(embedding_dim, d_model, d_model, dropout)

        # ── Input projection: project each dynamic variable to d_model ───────
        self.input_projections = nn.ModuleList([
            nn.Linear(1, d_model) for _ in range(num_dynamic_vars)
        ])

        # ── Variable selection ────────────────────────────────────────────────
        self.vsn = VariableSelectionNetwork(num_dynamic_vars, d_model, dropout)

        # ── LSTM encoder ─────────────────────────────────────────────────────
        self.lstm_encoder = nn.LSTM(d_model, d_model, num_layers=num_layers,
                                    batch_first=True, dropout=dropout if num_layers > 1 else 0.0)

        # ── Interpretable multi-head attention ───────────────────────────────
        self.attn = nn.MultiheadAttention(d_model, n_heads, dropout=dropout, batch_first=True)
        self.attn_norm = nn.LayerNorm(d_model)

        # ── Output GRN + per-target heads ────────────────────────────────────
        self.output_grn = GatedResidualNetwork(d_model, d_model, d_model, dropout)
        self.forecast_heads = nn.ModuleList([
            nn.Linear(d_model * seq_len, pred_len) for _ in range(num_targets)
        ])

        log.info("tft.init", seq_len=seq_len, pred_len=pred_len,
                 num_dynamic_vars=num_dynamic_vars, num_targets=num_targets)

    def forward(self, x: torch.Tensor, asset_id: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        x:        [B, L, F]
        asset_id: [B]
        Returns:  [B, H, T]
        """
        x = x.float()
        B, L, F = x.shape

        if asset_id is None:
            asset_id = torch.zeros(B, dtype=torch.long, device=x.device)

        # ── Static context from asset embedding ──────────────────────────────
        static = self.static_grn(self.asset_embedding(asset_id))   # [B, d_model]
        static_ctx = static.unsqueeze(1).expand(-1, L, -1)         # [B, L, d_model]

        # ── Project each variable independently ──────────────────────────────
        var_projections = []
        for i, proj in enumerate(self.input_projections):
            ch = x[:, :, i:i+1]          # [B, L, 1]
            var_projections.append(proj(ch))   # [B, L, d_model]
        var_stack = torch.stack(var_projections, dim=-2)   # [B, L, F, d_model]

        # ── Variable selection ────────────────────────────────────────────────
        selected = self.vsn(var_stack)         # [B, L, d_model]
        selected = selected + static_ctx       # inject static context

        # ── LSTM encoder ─────────────────────────────────────────────────────
        lstm_out, _ = self.lstm_encoder(selected)   # [B, L, d_model]

        # ── Attention ────────────────────────────────────────────────────────
        attn_out, _ = self.attn(lstm_out, lstm_out, lstm_out)
        attn_out    = self.attn_norm(lstm_out + attn_out)

        # ── Output GRN ───────────────────────────────────────────────────────
        out = self.output_grn(attn_out)            # [B, L, d_model]

        # ── Per-target forecast heads ─────────────────────────────────────────
        flat = out.reshape(B, -1)                  # [B, L * d_model]
        forecasts = [head(flat) for head in self.forecast_heads]   # T × [B, H]
        result = torch.stack(forecasts, dim=-1)    # [B, H, T]
        return result


class TFTPredictor:
    def __init__(self, settings):
        self.settings = settings
        self.device   = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._model: Optional[TFTModel] = None

    def _load(self, num_dynamic_vars=1, num_targets=1, num_assets=1):
        if self._model is not None:
            return
        self._model = TFTModel(
            seq_len=self.settings.FORECAST_WINDOW_SIZE,
            pred_len=self.settings.FORECAST_HORIZON,
            num_dynamic_vars=num_dynamic_vars,
            num_targets=num_targets,
            num_assets=num_assets,
        ).to(self.device)
        self._model.eval()

    def predict(self, x, asset_id: int = 0, horizon=None):
        self._load()
        arr = np.asarray(x, dtype=np.float32)
        if arr.ndim == 1:
            arr = arr[:, np.newaxis]
        tensor = torch.tensor(arr).unsqueeze(0).to(self.device)
        aid_t  = torch.tensor([asset_id], dtype=torch.long, device=self.device)
        with torch.no_grad():
            out = self._model(tensor, aid_t)   # [1, H, T]
        result = out.squeeze(0).cpu().numpy()
        H = horizon or self.settings.FORECAST_HORIZON
        return result[:H] if result.shape[0] >= H else np.pad(result, ((0, H - result.shape[0]), (0, 0)), mode="edge")
