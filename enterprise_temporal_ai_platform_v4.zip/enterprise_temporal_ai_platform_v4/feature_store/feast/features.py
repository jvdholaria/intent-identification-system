"""
Enterprise Temporal AI Platform — Feast Feature Definitions

Registers all features for:
- lag features
- rolling statistics
- seasonality features
- anomaly features
- uncertainty metrics
- embeddings
"""

from __future__ import annotations

from datetime import timedelta

from feast import (
    BigQuerySource,
    Entity,
    Feature,
    FeatureService,
    FeatureView,
    Field,
    FileSource,
    RequestSource,
    ValueType,
)
from feast.types import Float32, Float64, Int64, String


# ─────────────────────────────────────────────────────────────────────────────
# Entities
# ─────────────────────────────────────────────────────────────────────────────

series_entity = Entity(
    name="series_id",
    value_type=ValueType.STRING,
    description="Unique time-series identifier",
)

tenant_entity = Entity(
    name="tenant_id",
    value_type=ValueType.STRING,
    description="Tenant identifier for multi-tenancy isolation",
)


# ─────────────────────────────────────────────────────────────────────────────
# Data Sources
# ─────────────────────────────────────────────────────────────────────────────

lag_features_source = BigQuerySource(
    name="lag_features_source",
    table="temporal_ai_features.lag_features",
    timestamp_field="event_timestamp",
    created_timestamp_column="created_timestamp",
)

rolling_stats_source = BigQuerySource(
    name="rolling_stats_source",
    table="temporal_ai_features.rolling_stats",
    timestamp_field="event_timestamp",
    created_timestamp_column="created_timestamp",
)

anomaly_features_source = BigQuerySource(
    name="anomaly_features_source",
    table="temporal_ai_features.anomaly_features",
    timestamp_field="event_timestamp",
    created_timestamp_column="created_timestamp",
)


# ─────────────────────────────────────────────────────────────────────────────
# Feature Views
# ─────────────────────────────────────────────────────────────────────────────

lag_features_view = FeatureView(
    name="lag_features",
    entities=[series_entity],
    ttl=timedelta(days=30),
    schema=[
        Field(name="lag_1h", dtype=Float32),
        Field(name="lag_6h", dtype=Float32),
        Field(name="lag_12h", dtype=Float32),
        Field(name="lag_24h", dtype=Float32),
        Field(name="lag_48h", dtype=Float32),
        Field(name="lag_168h", dtype=Float32),   # 1 week
        Field(name="lag_336h", dtype=Float32),   # 2 weeks
    ],
    source=lag_features_source,
    tags={"team": "temporal-ai", "layer": "features"},
)

rolling_stats_view = FeatureView(
    name="rolling_stats",
    entities=[series_entity],
    ttl=timedelta(days=30),
    schema=[
        # Rolling means
        Field(name="rolling_mean_1h", dtype=Float32),
        Field(name="rolling_mean_6h", dtype=Float32),
        Field(name="rolling_mean_24h", dtype=Float32),
        Field(name="rolling_mean_168h", dtype=Float32),
        # Rolling std
        Field(name="rolling_std_1h", dtype=Float32),
        Field(name="rolling_std_6h", dtype=Float32),
        Field(name="rolling_std_24h", dtype=Float32),
        # Rolling min/max
        Field(name="rolling_min_24h", dtype=Float32),
        Field(name="rolling_max_24h", dtype=Float32),
        # Rolling quantiles
        Field(name="rolling_p10_24h", dtype=Float32),
        Field(name="rolling_p90_24h", dtype=Float32),
    ],
    source=rolling_stats_source,
    tags={"team": "temporal-ai", "layer": "features"},
)

seasonality_view = FeatureView(
    name="seasonality_features",
    entities=[series_entity],
    ttl=timedelta(days=30),
    schema=[
        Field(name="hour_of_day", dtype=Float32),
        Field(name="day_of_week", dtype=Float32),
        Field(name="week_of_year", dtype=Float32),
        Field(name="month", dtype=Float32),
        Field(name="is_weekend", dtype=Float32),
        Field(name="is_business_hour", dtype=Float32),
        # Fourier features for periodicity
        Field(name="sin_hour", dtype=Float32),
        Field(name="cos_hour", dtype=Float32),
        Field(name="sin_day", dtype=Float32),
        Field(name="cos_day", dtype=Float32),
        Field(name="sin_week", dtype=Float32),
        Field(name="cos_week", dtype=Float32),
    ],
    source=rolling_stats_source,
    tags={"team": "temporal-ai", "layer": "features"},
)

anomaly_features_view = FeatureView(
    name="anomaly_features",
    entities=[series_entity],
    ttl=timedelta(days=14),
    schema=[
        Field(name="anomaly_score_latest", dtype=Float32),
        Field(name="anomaly_rate_24h", dtype=Float32),
        Field(name="residual_mean_24h", dtype=Float32),
        Field(name="residual_std_24h", dtype=Float32),
        Field(name="reconstruction_error_latest", dtype=Float32),
        Field(name="drift_score_latest", dtype=Float32),
        Field(name="uncertainty_width_latest", dtype=Float32),
    ],
    source=anomaly_features_source,
    tags={"team": "temporal-ai", "layer": "anomaly"},
)


# ─────────────────────────────────────────────────────────────────────────────
# Feature Services (logical groupings for model serving)
# ─────────────────────────────────────────────────────────────────────────────

forecasting_feature_service = FeatureService(
    name="forecasting_features",
    features=[
        lag_features_view,
        rolling_stats_view,
        seasonality_view,
    ],
    description="All features required for multi-step forecasting",
)

anomaly_feature_service = FeatureService(
    name="anomaly_features",
    features=[
        rolling_stats_view,
        anomaly_features_view,
        seasonality_view,
    ],
    description="All features for hybrid anomaly detection",
)
