"""
Enterprise Temporal AI Platform — LLM Anomaly Explainer

Generates natural-language root-cause analysis and summaries
using open-source LLMs (Mistral, Llama) served via Ollama.

Workflow:
  Anomaly → Feature Attribution → Residual Analysis
    → Temporal Pattern Analysis → LLM Explanation Generator
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

import httpx

from shared.config.settings import Settings
from shared.logging.logger import get_logger

log = get_logger("llm.explainer")

# ── Prompt Template ───────────────────────────────────────────────────────────

ANOMALY_EXPLANATION_PROMPT = """You are an expert AI system monitoring analyst.
Analyse the following anomaly detection context and produce a concise, actionable explanation.

## Anomaly Context
{context_json}

## Instructions
- Identify the most likely root causes (max 3-4 bullet points)
- Explain what changed in terms a non-technical operator can understand
- Suggest concrete remediation steps
- Rate overall severity: LOW / MEDIUM / HIGH / CRITICAL

## Output Format (JSON only, no markdown)
{{
  "summary": "<one-sentence summary>",
  "root_causes": ["<cause 1>", "<cause 2>", "..."],
  "recommendations": ["<action 1>", "<action 2>", "..."],
  "severity": "<LOW|MEDIUM|HIGH|CRITICAL>",
  "confidence": <0.0-1.0>
}}"""


class LLMAnomalyExplainer:
    """
    Calls a locally-served Ollama instance (Mistral or Llama)
    to generate natural-language anomaly explanations.

    Falls back to a structured rule-based explanation if LLM is unavailable.
    """

    def __init__(self, settings: Settings):
        self.base_url = settings.LLM_BASE_URL
        self.model = settings.LLM_MODEL
        self.max_tokens = settings.LLM_MAX_TOKENS
        self.temperature = settings.LLM_TEMPERATURE
        self._client = httpx.AsyncClient(timeout=30.0)

    async def explain(
        self,
        anomaly_context: Dict[str, Any],
        feature_attributions: Optional[Dict[str, float]] = None,
        residual_stats: Optional[Dict[str, float]] = None,
    ) -> str:
        """
        Generate a natural-language explanation for the detected anomaly.
        Returns plain-text summary string.
        """
        enriched_context = {
            **anomaly_context,
            "feature_attributions": feature_attributions or {},
            "residual_stats": residual_stats or {},
        }

        prompt = ANOMALY_EXPLANATION_PROMPT.format(
            context_json=json.dumps(enriched_context, indent=2)
        )

        try:
            response = await self._call_ollama(prompt)
            parsed = json.loads(response)
            return self._format_response(parsed)
        except (httpx.ConnectError, httpx.TimeoutException):
            log.warning("llm.ollama_unreachable — using rule-based fallback")
            return self._rule_based_explanation(anomaly_context, feature_attributions)
        except json.JSONDecodeError:
            log.warning("llm.json_parse_failed — returning raw response")
            return response
        except Exception as exc:
            log.error("llm.explain_failed", exc=str(exc))
            return self._rule_based_explanation(anomaly_context, feature_attributions)

    async def explain_structured(
        self,
        anomaly_context: Dict[str, Any],
        feature_attributions: Optional[Dict[str, float]] = None,
    ) -> Dict[str, Any]:
        """Return the full structured explanation dict."""
        enriched_context = {
            **anomaly_context,
            "feature_attributions": feature_attributions or {},
        }
        prompt = ANOMALY_EXPLANATION_PROMPT.format(
            context_json=json.dumps(enriched_context, indent=2)
        )
        try:
            response = await self._call_ollama(prompt)
            return json.loads(response)
        except Exception as exc:
            log.warning("llm.structured_explain_failed", exc=str(exc))
            return {
                "summary": "Anomaly detected — LLM explanation unavailable",
                "root_causes": ["LLM service unreachable"],
                "recommendations": ["Check LLM service health", "Review anomaly scores manually"],
                "severity": "UNKNOWN",
                "confidence": 0.0,
            }

    async def _call_ollama(self, prompt: str) -> str:
        """POST to Ollama /api/generate and return the response text."""
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": self.temperature,
                "num_predict": self.max_tokens,
            },
        }
        resp = await self._client.post(
            f"{self.base_url}/api/generate",
            json=payload,
        )
        resp.raise_for_status()
        data = resp.json()
        return data.get("response", "")

    @staticmethod
    def _format_response(parsed: Dict[str, Any]) -> str:
        """Convert structured LLM response to a readable summary string."""
        parts = [f"Summary: {parsed.get('summary', 'N/A')}"]
        causes = parsed.get("root_causes", [])
        if causes:
            parts.append("Root Causes:")
            for c in causes:
                parts.append(f"  - {c}")
        recs = parsed.get("recommendations", [])
        if recs:
            parts.append("Recommendations:")
            for r in recs:
                parts.append(f"  - {r}")
        parts.append(
            f"Severity: {parsed.get('severity', 'UNKNOWN')}  "
            f"(confidence: {parsed.get('confidence', 0):.0%})"
        )
        return "\n".join(parts)

    @staticmethod
    def _rule_based_explanation(
        context: Dict[str, Any],
        feature_attributions: Optional[Dict[str, float]] = None,
    ) -> str:
        """Fallback explanation generated without LLM."""
        rate = context.get("anomaly_rate", 0)
        max_score = context.get("max_score", 0)

        severity = "LOW"
        if max_score > 3.0:
            severity = "HIGH"
        elif max_score > 2.0:
            severity = "MEDIUM"

        top_features: List[str] = []
        if feature_attributions:
            sorted_f = sorted(feature_attributions.items(), key=lambda x: abs(x[1]), reverse=True)
            top_features = [f[0] for f in sorted_f[:3]]

        lines = [
            f"Anomaly detected (rate={rate:.1%}, max_score={max_score:.2f}, severity={severity}).",
            "Root Causes (rule-based):",
            f"  - Anomaly score exceeded normal operating range (score={max_score:.2f})",
        ]
        if top_features:
            lines.append(f"  - Key contributing features: {', '.join(top_features)}")

        lines += [
            "Recommendations:",
            "  - Review recent data ingestion for quality issues",
            "  - Check upstream system metrics for outages or spikes",
            "  - Consider triggering model retraining if drift is confirmed",
        ]
        return "\n".join(lines)

    async def close(self):
        await self._client.aclose()
