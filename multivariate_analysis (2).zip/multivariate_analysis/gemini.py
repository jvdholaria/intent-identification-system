
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler, OneHotEncoder, RobustScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import TimeSeriesSplit
from sklearn.impute import SimpleImputer
import shap
import warnings
from typing import List, Dict, Tuple, Union, Optional

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

# -----------------------------------------------------------------------------
# 1. Data Ingestion & Alignment Strategy (The Core Scalability Component)
# -----------------------------------------------------------------------------
class AsyncDataAligner:
    """
    Handles the unification of heterogeneous, multi-frequency data sources.
    
    Strategy:
    1. Define a 'heartbeat' frequency (e.g., '1Min', '10s').
    2. Create a unified time grid.
    3. Reindex each source to this grid using Forward Fill (ffill) to simulate 
       'last known state' (crucial for real-time realism and avoiding leakage).
    """
    def __init__(self, heartbeat_freq: str = '1Min', aggregation_method: str = 'last'):
        self.heartbeat_freq = heartbeat_freq
        self.agg_method = aggregation_method

    def align(self, 
              data_sources: Dict[str, pd.DataFrame], 
              time_col: str = 'timestamp') -> pd.DataFrame:
        """
        Args:
            data_sources: Dict of {source_name: DataFrame}. 
                          DFs must have a datetime column or index.
        """
        print(f"Aligning {len(data_sources)} asynchronous sources to {self.heartbeat_freq} grid...")
        
        # 1. Find global time bounds
        min_times = []
        max_times = []
        
        cleaned_sources = {}
        
        for name, df in data_sources.items():
            df = df.copy()
            if time_col in df.columns:
                df[time_col] = pd.to_datetime(df[time_col])
                df = df.set_index(time_col)
            
            # Remove duplicate indices if any
            df = df[~df.index.duplicated(keep='last')]
            df = df.sort_index()
            
            cleaned_sources[name] = df
            min_times.append(df.index.min())
            max_times.append(df.index.max())

        global_start = min(min_times)
        global_end = max(max_times)
        
        # 2. Create the unified grid
        grid = pd.date_range(start=global_start, end=global_end, freq=self.heartbeat_freq)
        unified_df = pd.DataFrame(index=grid)
        
        # 3. Merge and resample
        for name, df in cleaned_sources.items():
            # Rename columns to avoid collisions
            df.columns = [f"{name}_{c}" for c in df.columns]
            
            # Resample to grid, forward fill valid constraints (limit fill for gap detection?)
            # We use ffill() because in a system, a sensor value persists until updated.
            reindexed = df.reindex(grid, method='ffill')
            
            unified_df = pd.concat([unified_df, reindexed], axis=1)

        # 4. Handle remaining NaNs (e.g. before first sensor reading)
        # Drop initial rows where sensors haven't started reporting
        unified_df = unified_df.dropna(how='all') 
        
        print(f"Alignment complete. Unified shape: {unified_df.shape}")
        return unified_df

# -----------------------------------------------------------------------------
# 2. Preprocessing & Windowing
# -----------------------------------------------------------------------------
class SystemPreprocessor:
    """
    Wraps sklearn pipelines to handle scaling and encoding robustly.
    Separates Static (metadata) from Temporal (time-series) features.
    """
    def __init__(self, 
                 temporal_cols: List[str], 
                 static_cols: List[str], 
                 target_cols: List[str]):
        self.temporal_cols = temporal_cols
        self.static_cols = static_cols
        self.target_cols = target_cols
        
        self.temporal_scaler = Pipeline([
            ('imputer', SimpleImputer(strategy='mean')), # Or 'median' for outliers
            ('scaler', RobustScaler()) # RobustScaler handles outliers better than StandardScaler
        ])
        
        self.static_pipeline = Pipeline([
            ('imputer', SimpleImputer(strategy='most_frequent')),
            ('scaler', StandardScaler()) # Or OneHotEncoder if categorical
        ])
        
        self.target_scaler = StandardScaler() # Normalize targets for better DL convergence

    def fit_transform(self, df: pd.DataFrame):
        # Split data
        X_temp = df[self.temporal_cols].values
        
        # If static cols missing, create dummy
        if self.static_cols:
            X_static = df[self.static_cols].values
            X_static = self.static_pipeline.fit_transform(X_static)
        else:
            X_static = np.zeros((len(df), 0))
            
        y = df[self.target_cols].values
        
        X_temp = self.temporal_scaler.fit_transform(X_temp)
        y = self.target_scaler.fit_transform(y)
        
        return X_temp, X_static, y

    def transform(self, df: pd.DataFrame):
        X_temp = self.temporal_scaler.transform(df[self.temporal_cols].values)
        if self.static_cols:
            X_static = self.static_pipeline.transform(df[self.static_cols].values)
        else:
            X_static = np.zeros((len(df), 0))
        y = None
        if all(col in df.columns for col in self.target_cols):
             y = self.target_scaler.transform(df[self.target_cols].values)
        return X_temp, X_static, y

    def inverse_transform_targets(self, y_pred):
        return self.target_scaler.inverse_transform(y_pred)

def create_sequences(X_temp, X_static, y, time_steps=30, forecast_horizon=1):
    """
    Converts array data into (Samples, TimeSteps, Features) format for LSTM/GRU.
    """
    Xs_temp, Xs_static, ys = [], [], []
    for i in range(len(X_temp) - time_steps - forecast_horizon + 1):
        Xs_temp.append(X_temp[i:(i + time_steps)])
        # Static features are constant, take the row at prediction time
        Xs_static.append(X_static[i + time_steps - 1]) 
        ys.append(y[i + time_steps + forecast_horizon - 1])
        
    return np.array(Xs_temp), np.array(Xs_static), np.array(ys)

# -----------------------------------------------------------------------------
# 3. Hybrid Neural Network Architecture
# -----------------------------------------------------------------------------
class HybridMultiOutputModel(nn.Module):
    """
    A Shared-Representation Architecture.
    
    1. Temporal Branch: Processes time-series history (LSTM/GRU/Transformer).
    2. Static Branch: Processes system metadata.
    3. Fusion Layer: Concatenates representations.
    4. Multi-Headed Output: Predicts multiple targets simultaneously.
    """
    def __init__(self, 
                 n_temporal_features, 
                 n_static_features, 
                 n_outputs, 
                 hidden_dim=64, 
                 n_layers=2, 
                 dropout=0.2):
        super(HybridMultiOutputModel, self).__init__()
        
        # Temporal Branch (LSTM)
        self.lstm = nn.LSTM(
            input_size=n_temporal_features,
            hidden_size=hidden_dim,
            num_layers=n_layers,
            batch_first=True,
            dropout=dropout
        )
        
        # Static Branch (Dense)
        self.static_fc = nn.Sequential(
            nn.Linear(n_static_features, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout)
        ) if n_static_features > 0 else None
        
        # Fusion Dimension
        fusion_dim = hidden_dim + (hidden_dim // 2 if n_static_features > 0 else 0)
        
        # Head (Shared layers)
        self.fc_shared = nn.Sequential(
            nn.Linear(fusion_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # Output Layer (Linear for Regression)
        self.output_layer = nn.Linear(hidden_dim, n_outputs)

    def forward(self, x_temp, x_static):
        # x_temp: [Batch, TimeSteps, Features]
        # x_static: [Batch, Features]
        
        # LSTM output: [Batch, TimeSteps, Hidden]
        # We take the last time step: out[:, -1, :]
        lstm_out, _ = self.lstm(x_temp)
        temp_embedding = lstm_out[:, -1, :]
        
        combined = temp_embedding
        
        if self.static_fc is not None:
            static_embedding = self.static_fc(x_static)
            combined = torch.cat((temp_embedding, static_embedding), dim=1)
        
        shared = self.fc_shared(combined)
        return self.output_layer(shared)

# -----------------------------------------------------------------------------
# 4. Production Trainer (Scalable & Modular)
# -----------------------------------------------------------------------------
class ProductionTrainer:
    def __init__(self, model, criterion, optimizer, device='cpu'):
        self.model = model.to(device)
        self.criterion = criterion
        self.optimizer = optimizer
        self.device = device
        self.history = {'train_loss': [], 'val_loss': []}

    def train_epoch(self, dataloader):
        self.model.train()
        total_loss = 0
        for batch_temp, batch_static, batch_y in dataloader:
            batch_temp = batch_temp.float().to(self.device)
            batch_static = batch_static.float().to(self.device)
            batch_y = batch_y.float().to(self.device)
            
            self.optimizer.zero_grad()
            outputs = self.model(batch_temp, batch_static)
            loss = self.criterion(outputs, batch_y)
            loss.backward()
            self.optimizer.step()
            total_loss += loss.item()
        return total_loss / len(dataloader)

    def evaluate(self, dataloader):
        self.model.eval()
        total_loss = 0
        with torch.no_grad():
            for batch_temp, batch_static, batch_y in dataloader:
                batch_temp = batch_temp.float().to(self.device)
                batch_static = batch_static.float().to(self.device)
                batch_y = batch_y.float().to(self.device)
                
                outputs = self.model(batch_temp, batch_static)
                loss = self.criterion(outputs, batch_y)
                total_loss += loss.item()
        return total_loss / len(dataloader)

    def fit(self, train_loader, val_loader, epochs=50, patience=5):
        best_val_loss = float('inf')
        patience_counter = 0
        
        print(f"Starting training on {self.device}...")
        for epoch in range(epochs):
            train_loss = self.train_epoch(train_loader)
            val_loss = self.evaluate(val_loader)
            
            self.history['train_loss'].append(train_loss)
            self.history['val_loss'].append(val_loss)
            
            print(f"Epoch {epoch+1}/{epochs} - Train Loss: {train_loss:.4f} - Val Loss: {val_loss:.4f}")
            
            # Early Stopping Check
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                patience_counter = 0
                torch.save(self.model.state_dict(), 'best_model.pth')
            else:
                patience_counter += 1
                if patience_counter >= patience:
                    print("Early stopping triggered.")
                    break
        
        # Load best model
        self.model.load_state_dict(torch.load('best_model.pth'))

# -----------------------------------------------------------------------------
# 5. Explainability (SHAP)
# -----------------------------------------------------------------------------
def explain_model(model, train_loader, device='cpu'):
    """
    Uses SHAP DeepExplainer. 
    Note: SHAP for sequential models handles 3D inputs by summarizing.
    """
    model.eval()
    
    # Get a batch of background data
    batch_temp, batch_static, _ = next(iter(train_loader))
    batch_temp = batch_temp.float().to(device)
    batch_static = batch_static.float().to(device)
    
    # We need a custom wrapper because DeepExplainer expects a single input tensor
    # usually, or we pass a list. 
    # For hybrid inputs, we need to treat them carefully.
    # Below is a simplified approach focusing on the Temporal features importance
    
    # Background samples (limit to 100 for speed)
    background_temp = batch_temp[:100]
    background_static = batch_static[:100]

    print("\n--- SHAP Interpretability ---")
    print("Generating SHAP values (this may take time for LSTMs)...")
    
    # Define a wrapper to handle the two-input forward pass for SHAP
    # SHAP DeepExplainer works best with single inputs, or list inputs.
    # Here we demonstrate the concept.
    
    # (Implementation detail: DeepExplainer with PyTorch LSTM is complex 
    # and sometimes version-sensitive. In production, use KernelExplainer 
    # or GradientExplainer if Deep fails).
    
    try:
        e = shap.DeepExplainer(model, [background_temp, background_static])
        shap_values = e.shap_values([background_temp[:5], background_static[:5]]) # Explain 5 samples
        print("SHAP values calculated successfully.")
        print(f"Shape of temporal SHAP values: {np.array(shap_values[0]).shape}")
        # Use shap.summary_plot(shap_values[0], ...) in a notebook
    except Exception as e:
        print(f"SHAP Explainer skipped (common in non-interactive/complex LSTM contexts): {e}")

# -----------------------------------------------------------------------------
# 6. Usage Example / Integration
# -----------------------------------------------------------------------------
def run_pipeline():
    # --- A. Mock Heterogeneous Data ---
    # Source 1: High frequency Sensor (every 1 min)
    idx1 = pd.date_range("2023-01-01", periods=1000, freq="1Min")
    df_sensor = pd.DataFrame({
        "timestamp": idx1,
        "temperature": np.random.normal(20, 2, 1000).cumsum(),
        "vibration": np.random.normal(0, 1, 1000)
    })
    
    # Source 2: Low frequency Event Log (irregular)
    idx2 = pd.to_datetime(["2023-01-01 00:05", "2023-01-01 00:25", "2023-01-01 01:00"])
    df_events = pd.DataFrame({
        "timestamp": idx2,
        "error_code": [0, 1, 0], # Categorical
        "maintenance_flag": [0, 0, 1]
    })
    
    # Source 3: Static System Metadata (merged later or broadcasted)
    # In this design, we treat static data as inputs to the static branch
    # Here we assume these are joined to the temporal data or passed separately
    
    # --- B. Alignment ---
    aligner = AsyncDataAligner(heartbeat_freq='5Min') # Downsample to 5 min for stability
    df_unified = aligner.align({
        'sensor': df_sensor, 
        'events': df_events
    })
    
    # Add dummy target (e.g., predict temperature 3 steps ahead, and a system health score)
    df_unified['target_temp_future'] = df_unified['sensor_temperature'].shift(-3)
    df_unified['target_health_score'] = np.random.rand(len(df_unified)) # Dummy
    df_unified = df_unified.dropna()
    
    # --- C. Preprocessing ---
    print("\n--- Preprocessing ---")
    temporal_features = ['sensor_temperature', 'sensor_vibration', 'events_error_code', 'events_maintenance_flag']
    static_features = [] # Example: could be ['machine_id_encoded']
    target_features = ['target_temp_future', 'target_health_score']
    
    preprocessor = SystemPreprocessor(temporal_features, static_features, target_features)
    X_temp_norm, X_static_norm, y_norm = preprocessor.fit_transform(df_unified)
    
    # --- D. Sequence Creation ---
    TIME_STEPS = 12 # Look back 1 hour (5min * 12)
    X_seq, X_static_seq, y_seq = create_sequences(X_temp_norm, X_static_norm, y_norm, time_steps=TIME_STEPS)
    
    # --- E. Train/Test Split (Time-based!) ---
    split_idx = int(len(X_seq) * 0.8)
    X_train_t, X_val_t = X_seq[:split_idx], X_seq[split_idx:]
    X_train_s, X_val_s = X_static_seq[:split_idx], X_static_seq[split_idx:]
    y_train, y_val = y_seq[:split_idx], y_seq[split_idx:]
    
    # PyTorch Datasets
    class SystemDataset(Dataset):
        def __init__(self, xt, xs, y):
            self.xt, self.xs, self.y = xt, xs, y
        def __len__(self): return len(self.xt)
        def __getitem__(self, i): return self.xt[i], self.xs[i], self.y[i]
        
    train_loader = DataLoader(SystemDataset(X_train_t, X_train_s, y_train), batch_size=32, shuffle=False) # Shuffle=False is safer for debugging time series, but True is ok for LSTM if windows are independent
    val_loader = DataLoader(SystemDataset(X_val_t, X_val_s, y_val), batch_size=32)
    
    # --- F. Modeling ---
    print("\n--- Initializing Model ---")
    model = HybridMultiOutputModel(
        n_temporal_features=X_train_t.shape[2],
        n_static_features=X_train_s.shape[1],
        n_outputs=y_train.shape[1]
    )
    
    trainer = ProductionTrainer(
        model, 
        criterion=nn.MSELoss(), 
        optimizer=optim.Adam(model.parameters(), lr=0.001)
    )
    
    trainer.fit(train_loader, val_loader, epochs=5)
    
    # --- G. Inference Example ---
    preds = model(torch.tensor(X_val_t[:5]).float(), torch.tensor(X_val_s[:5]).float())
    real_scale_preds = preprocessor.inverse_transform_targets(preds.detach().numpy())
    print("\nSample Predictions (Original Scale):")
    print(real_scale_preds)
    
    # --- H. Explainability ---
    explain_model(model, train_loader)

if __name__ == "__main__":
    run_pipeline()