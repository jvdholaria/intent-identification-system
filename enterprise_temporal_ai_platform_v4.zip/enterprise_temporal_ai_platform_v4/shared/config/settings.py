"""
Enterprise Temporal AI Platform — Shared Configuration
"""

from __future__ import annotations

import os
from functools import lru_cache
from typing import List, Literal, Optional

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings


class TemporalConfig:
    """Core temporal forecasting configuration."""
    resample_freq: str = "1H"
    aggregation_method: str = "mean"
    interpolation_method: str = "linear"
    max_gap_fill_periods: int = 8
    window_size: int = 168          # 7 days of hourly data
    horizon: int = 120              # 5 days of hourly forecast
    multi_step: bool = True
    forecast_strategy: str = "seq2seq"


class Settings(BaseSettings):
    # ── Environment ─────────────────────────────────────────────────
    ENV: Literal["development", "staging", "production"] = "development"
    DEBUG: bool = False
    LOG_LEVEL: str = "INFO"

    # ── Service Ports ────────────────────────────────────────────────
    GATEWAY_PORT: int = 8000
    FORECAST_SERVICE_PORT: int = 8001
    ANOMALY_SERVICE_PORT: int = 8002
    DRIFT_SERVICE_PORT: int = 8003
    LLM_SERVICE_PORT: int = 8004

    # ── Service URLs ─────────────────────────────────────────────────
    FORECAST_SERVICE_URL: str = "http://forecast-service:8001"
    ANOMALY_SERVICE_URL: str = "http://anomaly-service:8002"
    DRIFT_SERVICE_URL: str = "http://drift-service:8003"
    LLM_SERVICE_URL: str = "http://llm-service:8004"

    # ── Database ─────────────────────────────────────────────────────
    DATABASE_URL: str = "postgresql://temporal:temporal@postgres:5432/temporal_ai"
    DATABASE_POOL_SIZE: int = 10
    DATABASE_MAX_OVERFLOW: int = 20

    # ── Redis ────────────────────────────────────────────────────────
    REDIS_URL: str = "redis://redis:6379"
    REDIS_DB: int = 0
    REDIS_BUFFER_TTL: int = 3600        # 1 hour in seconds
    REDIS_QUEUE_KEY: str = "temporal:inference:queue"
    REDIS_CACHE_KEY_PREFIX: str = "temporal:cache"

    # ── MLflow ───────────────────────────────────────────────────────
    MLFLOW_TRACKING_URI: str = "http://mlflow:5000"
    MLFLOW_DEFAULT_EXPERIMENT: str = "enterprise-temporal-ai"
    MLFLOW_ARTIFACT_ROOT: str = "/mlflow/artifacts"

    # ── Feast Feature Store ──────────────────────────────────────────
    FEAST_REPO_PATH: str = "./feature_store/feast"
    FEAST_ONLINE_STORE_URL: str = "redis://redis:6379"

    # ── GCP / Pub/Sub ────────────────────────────────────────────────
    GOOGLE_CLOUD_PROJECT: str = "temporal-ai-project"
    PUBSUB_TOPIC: str = "temporal-ingest"
    PUBSUB_SUBSCRIPTION: str = "temporal-subscription"
    BIGQUERY_DATASET: str = "temporal_ai_features"

    # ── Forecasting ──────────────────────────────────────────────────
    FORECAST_WINDOW_SIZE: int = 168
    FORECAST_HORIZON: int = 120
    FORECAST_RESAMPLE_FREQ: str = "1H"
    FORECAST_MAX_GAP_FILL: int = 8
    FORECAST_QUANTILES: List[float] = Field(default=[0.1, 0.5, 0.9])

    # ── Ensemble Weights ─────────────────────────────────────────────
    ENSEMBLE_WEIGHT_PATCHTST: float = 0.35
    ENSEMBLE_WEIGHT_TFT: float = 0.30
    ENSEMBLE_WEIGHT_TIMESNET: float = 0.15
    ENSEMBLE_WEIGHT_NBEATS: float = 0.10
    ENSEMBLE_WEIGHT_GRU: float = 0.10

    # ── Anomaly Detection ────────────────────────────────────────────
    ANOMALY_RESIDUAL_WEIGHT: float = 0.5
    ANOMALY_RECONSTRUCTION_WEIGHT: float = 0.3
    ANOMALY_DRIFT_WEIGHT: float = 0.2
    ANOMALY_THRESHOLD_SIGMA: float = 3.0
    ANOMALY_WINDOW_SIZE: int = 168

    # ── Drift Detection ──────────────────────────────────────────────
    DRIFT_PSI_THRESHOLD: float = 0.2
    DRIFT_KS_PVALUE_THRESHOLD: float = 0.05
    DRIFT_WASSERSTEIN_THRESHOLD: float = 0.1
    DRIFT_COSINE_THRESHOLD: float = 0.15

    # ── LLM Explainability ───────────────────────────────────────────
    LLM_MODEL: str = "mistral"
    LLM_BASE_URL: str = "http://ollama:11434"
    LLM_MAX_TOKENS: int = 512
    LLM_TEMPERATURE: float = 0.1

    # ── Training ─────────────────────────────────────────────────────
    TRAINING_GPUS: int = 2
    TRAINING_PRECISION: str = "16-mixed"
    TRAINING_MAX_EPOCHS: int = 100
    TRAINING_BATCH_SIZE: int = 64
    TRAINING_LEARNING_RATE: float = 1e-4
    TRAINING_GRADIENT_ACCUMULATION: int = 4

    # ── Ray Cluster ──────────────────────────────────────────────────
    RAY_ADDRESS: str = "auto"
    RAY_NUM_CPUS: Optional[int] = None
    RAY_NUM_GPUS: Optional[int] = None

    # ── Optuna HPO ───────────────────────────────────────────────────
    OPTUNA_N_TRIALS: int = 50
    OPTUNA_TIMEOUT: int = 3600
    OPTUNA_STUDY_NAME: str = "temporal-hpo"

    # ── Multi-Tenancy ────────────────────────────────────────────────
    MULTI_TENANT_ENABLED: bool = True
    TENANT_NAMESPACE_PREFIX: str = "temporal:tenant"

    # ── Celery ───────────────────────────────────────────────────────
    CELERY_BROKER_URL: str = "redis://redis:6379/1"
    CELERY_RESULT_BACKEND: str = "redis://redis:6379/2"

    @field_validator("FORECAST_QUANTILES", mode="before")
    @classmethod
    def parse_quantiles(cls, v):
        if isinstance(v, str):
            return [float(x) for x in v.split(",")]
        return v

    @property
    def is_production(self) -> bool:
        return self.ENV == "production"

    @property
    def redis_namespace(self) -> str:
        return self.TENANT_NAMESPACE_PREFIX

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    """Return cached settings singleton."""
    return Settings()


settings = get_settings()
