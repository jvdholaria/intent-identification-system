"""
Enterprise Temporal AI Platform — Autoencoder Anomaly Detectors

LSTM Autoencoder and Transformer Autoencoder for reconstruction-based
detection of latent-space and unknown anomalies.
"""

from __future__ import annotations

from typing import List, Optional

import numpy as np
import torch
import torch.nn as nn

from shared.logging.logger import get_logger

log = get_logger("anomaly.autoencoder")


# ─────────────────────────────────────────────────────────────────────────────
# LSTM Autoencoder
# ─────────────────────────────────────────────────────────────────────────────

class LSTMEncoder(nn.Module):
    def __init__(self, input_size: int, hidden_size: int, num_layers: int, dropout: float):
        super().__init__()
        self.lstm = nn.LSTM(
            input_size, hidden_size, num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )

    def forward(self, x: torch.Tensor):
        _, (h, c) = self.lstm(x)
        return h, c     # final hidden state used as latent code


class LSTMDecoder(nn.Module):
    def __init__(self, hidden_size: int, output_size: int, seq_len: int, num_layers: int, dropout: float):
        super().__init__()
        self.seq_len = seq_len
        self.lstm = nn.LSTM(
            hidden_size, hidden_size, num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, h: torch.Tensor, c: torch.Tensor) -> torch.Tensor:
        # Repeat latent state across all time steps
        batch = h.shape[1]
        dec_in = h[-1].unsqueeze(1).repeat(1, self.seq_len, 1)  # (B, seq, H)
        out, _ = self.lstm(dec_in, (h, c))
        return self.fc(out)   # (B, seq, output_size)


class LSTMAutoencoder(nn.Module):
    """
    LSTM Autoencoder for detecting unknown and latent-space anomalies
    via reconstruction error.
    """

    def __init__(
        self,
        seq_len: int = 168,
        input_size: int = 1,
        hidden_size: int = 128,
        num_layers: int = 2,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.encoder = LSTMEncoder(input_size, hidden_size, num_layers, dropout)
        self.decoder = LSTMDecoder(hidden_size, input_size, seq_len, num_layers, dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h, c = self.encoder(x)
        recon = self.decoder(h, c)
        return recon


# ─────────────────────────────────────────────────────────────────────────────
# Transformer Autoencoder
# ─────────────────────────────────────────────────────────────────────────────

class TransformerAutoencoder(nn.Module):
    """
    Transformer-based sequence autoencoder.
    Encodes the series into a compressed representation and reconstructs it.
    High reconstruction error signals anomaly.
    """

    def __init__(
        self,
        seq_len: int = 168,
        input_size: int = 1,
        d_model: int = 64,
        n_heads: int = 4,
        num_encoder_layers: int = 2,
        num_decoder_layers: int = 2,
        d_ff: int = 128,
        dropout: float = 0.1,
        bottleneck_factor: int = 4,
    ):
        super().__init__()
        self.seq_len = seq_len
        self.d_model = d_model

        self.input_proj = nn.Linear(input_size, d_model)
        self.pos_enc = nn.Parameter(torch.randn(1, seq_len, d_model) * 0.02)

        encoder_layer = nn.TransformerEncoderLayer(d_model, n_heads, d_ff, dropout, batch_first=True)
        self.encoder = nn.TransformerEncoder(encoder_layer, num_encoder_layers)

        # Bottleneck compression
        bottleneck_dim = max(d_model // bottleneck_factor, 8)
        self.compress = nn.Linear(d_model, bottleneck_dim)
        self.expand = nn.Linear(bottleneck_dim, d_model)

        decoder_layer = nn.TransformerDecoderLayer(d_model, n_heads, d_ff, dropout, batch_first=True)
        self.decoder = nn.TransformerDecoder(decoder_layer, num_decoder_layers)

        self.output_proj = nn.Linear(d_model, input_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, seq_len, input_size)
        emb = self.input_proj(x) + self.pos_enc       # (B, seq_len, d_model)
        enc = self.encoder(emb)                        # (B, seq_len, d_model)

        # Bottleneck
        latent = self.compress(enc)                    # (B, seq_len, bottleneck_dim)
        expanded = self.expand(latent)                 # (B, seq_len, d_model)

        dec = self.decoder(emb, expanded)              # (B, seq_len, d_model)
        return self.output_proj(dec)                   # (B, seq_len, input_size)


# ─────────────────────────────────────────────────────────────────────────────
# Reconstruction Scorer
# ─────────────────────────────────────────────────────────────────────────────

class ReconstructionScorer:
    """
    Wraps an autoencoder model and produces per-point reconstruction scores.
    Can use either LSTMAutoencoder or TransformerAutoencoder.
    """

    def __init__(
        self,
        model: Optional[nn.Module] = None,
        seq_len: int = 168,
        use_transformer: bool = False,
        device: Optional[str] = None,
    ):
        self.seq_len = seq_len
        self.device = torch.device(
            device or ("cuda" if torch.cuda.is_available() else "cpu")
        )

        if model is not None:
            self.model = model.to(self.device)
        elif use_transformer:
            self.model = TransformerAutoencoder(seq_len=seq_len).to(self.device)
        else:
            self.model = LSTMAutoencoder(seq_len=seq_len).to(self.device)

        self.model.eval()
        log.info("reconstruction_scorer.ready", model_type=type(self.model).__name__)

    def score(self, series: List[float]) -> List[float]:
        """
        Produce per-window reconstruction error scores.
        Returns a score list of the same length as `series`.
        """
        arr = np.array(series, dtype=np.float32)
        scores = np.zeros(len(arr), dtype=np.float32)

        if len(arr) < self.seq_len:
            arr = np.pad(arr, (self.seq_len - len(arr), 0), mode="edge")

        with torch.no_grad():
            for i in range(len(series)):
                start = max(0, len(arr) - len(series) + i - self.seq_len + 1)
                window = arr[start : start + self.seq_len]
                if len(window) < self.seq_len:
                    window = np.pad(window, (self.seq_len - len(window), 0), mode="edge")

                x = torch.tensor(window, dtype=torch.float32).unsqueeze(0).unsqueeze(-1).to(self.device)
                recon = self.model(x)
                mse = float(torch.mean((x - recon) ** 2).cpu())
                scores[i] = mse

        # Normalise to [0, inf) z-score
        mu, sigma = scores.mean(), scores.std()
        if sigma < 1e-9:
            sigma = 1.0
        normalised = (scores - mu) / sigma
        return [round(float(s), 4) for s in normalised]
