"""
Enterprise Temporal AI Platform — Training Router
"""

from __future__ import annotations

import uuid
from fastapi import APIRouter, BackgroundTasks, HTTPException

from shared.config.settings import settings
from shared.logging.logger import get_logger
from shared.schemas.schemas import TrainingRequest, TrainingResponse

log = get_logger("forecast.training_router")
router = APIRouter()


@router.post("/train", response_model=TrainingResponse, summary="Launch model training job")
async def train(
    req: TrainingRequest,
    background_tasks: BackgroundTasks,
) -> TrainingResponse:
    """
    Launch a distributed training job for the specified model.

    - Supports single-GPU and multi-GPU DDP via PyTorch Lightning.
    - Optionally runs Optuna HPO before training.
    - All runs tracked in MLflow under the tenant's experiment.
    """
    run_id = str(uuid.uuid4())
    experiment_name = (
        req.experiment_name
        or f"{settings.MLFLOW_DEFAULT_EXPERIMENT}/{req.tenant_id}/{req.model_type.value}"
    )

    log.info(
        "training.submitted",
        run_id=run_id,
        tenant=req.tenant_id,
        model=req.model_type.value,
        epochs=req.epochs,
        hpo=req.run_hpo,
    )

    background_tasks.add_task(
        _run_training_job,
        req=req,
        run_id=run_id,
        experiment_name=experiment_name,
    )

    return TrainingResponse(
        request_id=run_id,
        tenant_id=req.tenant_id,
        run_id=run_id,
        experiment_id=experiment_name,
        model_uri=f"mlflow:/{experiment_name}/{run_id}/model",
        metrics={},
    )


@router.get("/train/{run_id}/status", summary="Get training job status")
async def training_status(run_id: str):
    """Poll MLflow for the status of a training run."""
    try:
        import mlflow
        mlflow.set_tracking_uri(settings.MLFLOW_TRACKING_URI)
        client = mlflow.tracking.MlflowClient()
        run = client.get_run(run_id)
        return {
            "run_id": run_id,
            "status": run.info.status,
            "metrics": run.data.metrics,
            "params": run.data.params,
            "tags": run.data.tags,
        }
    except Exception as exc:
        raise HTTPException(status_code=404, detail=f"Run not found: {exc}")


# ── Background training job ───────────────────────────────────────────────────

async def _run_training_job(req: TrainingRequest, run_id: str, experiment_name: str):
    """Dispatched as a background task — calls into the training layer."""
    try:
        from forecasting.training.trainer import TemporalTrainer
        trainer = TemporalTrainer(settings=settings)
        await trainer.train(
            dataset_path=req.dataset_path,
            model_type=req.model_type,
            run_id=run_id,
            experiment_name=experiment_name,
            epochs=req.epochs,
            batch_size=req.batch_size,
            learning_rate=req.learning_rate,
            horizon=req.horizon,
            window_size=req.window_size,
            quantiles=req.quantiles,
            use_distributed=req.use_distributed,
            run_hpo=req.run_hpo,
            tenant_id=req.tenant_id,
            tags=req.tags or {},
        )
        log.info("training.complete", run_id=run_id, tenant=req.tenant_id)
    except Exception as exc:
        log.error("training.failed", run_id=run_id, exc=str(exc))
