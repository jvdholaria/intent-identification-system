"""
Unit tests — Forecasting Model Forward Passes
"""

import pytest
import numpy as np
import torch


# ─────────────────────────────────────────────────────────────────────────────
# PatchTST
# ─────────────────────────────────────────────────────────────────────────────

class TestPatchTST:
    def test_forward_shape(self):
        from forecasting.models.patchtst.model import PatchTSTModel
        model = PatchTSTModel(seq_len=168, pred_len=120, d_model=64, n_heads=4, n_layers=2)
        model.eval()
        x = torch.randn(4, 168)
        with torch.no_grad():
            out = model(x)
        assert out.shape == (4, 120), f"Expected (4,120), got {out.shape}"

    def test_output_finite(self):
        from forecasting.models.patchtst.model import PatchTSTModel
        model = PatchTSTModel(seq_len=168, pred_len=120)
        model.eval()
        x = torch.randn(2, 168)
        with torch.no_grad():
            out = model(x)
        assert torch.isfinite(out).all()

    def test_predictor_output_length(self):
        from forecasting.models.patchtst.model import PatchTSTPredictor
        from shared.config.settings import settings
        predictor = PatchTSTPredictor(settings)
        x = np.random.randn(168).astype(np.float32)
        out = predictor.predict(x, 120)
        assert len(out) == 120


# ─────────────────────────────────────────────────────────────────────────────
# GRU Seq2Seq
# ─────────────────────────────────────────────────────────────────────────────

class TestGRUSeq2Seq:
    def test_forward_shape(self):
        from forecasting.models.gru.model import GRUSeq2Seq
        model = GRUSeq2Seq(input_size=1, hidden_size=64, pred_len=24)
        model.eval()
        x = torch.randn(4, 48, 1)
        with torch.no_grad():
            out = model(x)
        assert out.shape == (4, 24)

    def test_predictor_output_length(self):
        from forecasting.models.gru.model import GRUPredictor
        from shared.config.settings import settings
        predictor = GRUPredictor(settings)
        x = np.random.randn(168).astype(np.float32)
        out = predictor.predict(x, 120)
        assert len(out) == 120

    def test_output_is_numpy(self):
        from forecasting.models.gru.model import GRUPredictor
        from shared.config.settings import settings
        predictor = GRUPredictor(settings)
        x = np.random.randn(168).astype(np.float32)
        out = predictor.predict(x, 24)
        assert isinstance(out, np.ndarray)


# ─────────────────────────────────────────────────────────────────────────────
# TFT
# ─────────────────────────────────────────────────────────────────────────────

class TestTFT:
    def test_forward_shape(self):
        from forecasting.models.tft.model import TFTModel
        model = TFTModel(seq_len=48, pred_len=24, d_model=32, n_heads=2, num_layers=1)
        model.eval()
        x = torch.randn(2, 48, 1)
        with torch.no_grad():
            out = model(x)
        assert out.shape == (2, 24)

    def test_grn_output_shape(self):
        from forecasting.models.tft.model import GatedResidualNetwork
        grn = GatedResidualNetwork(input_dim=32, hidden_dim=64, output_dim=32)
        x = torch.randn(4, 10, 32)
        out = grn(x)
        assert out.shape == (4, 10, 32)


# ─────────────────────────────────────────────────────────────────────────────
# N-BEATS
# ─────────────────────────────────────────────────────────────────────────────

class TestNBEATS:
    def test_forward_generic(self):
        from forecasting.models.nbeats.model import NBEATSModel
        model = NBEATSModel(seq_len=48, pred_len=24, use_interpretable=False)
        model.eval()
        x = torch.randn(2, 48)
        with torch.no_grad():
            out = model(x)
        assert out.shape == (2, 24)

    def test_forward_interpretable(self):
        from forecasting.models.nbeats.model import NBEATSModel
        model = NBEATSModel(seq_len=48, pred_len=24, use_interpretable=True)
        model.eval()
        x = torch.randn(2, 48)
        with torch.no_grad():
            out = model(x)
        assert out.shape == (2, 24)

    def test_predictor_interface(self):
        from forecasting.models.nbeats.model import NBeatsPredictor
        from shared.config.settings import settings
        predictor = NBeatsPredictor(settings)
        x = np.random.randn(168).astype(np.float32)
        out = predictor.predict(x, 120)
        assert len(out) == 120


# ─────────────────────────────────────────────────────────────────────────────
# TimesNet
# ─────────────────────────────────────────────────────────────────────────────

class TestTimesNet:
    def test_forward_shape(self):
        from forecasting.models.timesnet.model import TimesNetModel
        model = TimesNetModel(seq_len=48, pred_len=24, d_model=32, e_layers=1)
        model.eval()
        x = torch.randn(2, 48, 1)
        with torch.no_grad():
            out = model(x)
        assert out.shape == (2, 24)

    def test_predictor_interface(self):
        from forecasting.models.timesnet.model import TimesNetPredictor
        from shared.config.settings import settings
        predictor = TimesNetPredictor(settings)
        x = np.random.randn(168).astype(np.float32)
        out = predictor.predict(x, 120)
        assert len(out) == 120


# ─────────────────────────────────────────────────────────────────────────────
# LSTM Autoencoder
# ─────────────────────────────────────────────────────────────────────────────

class TestLSTMAutoencoder:
    def test_reconstruction_shape(self):
        from anomaly.autoencoder.detector import LSTMAutoencoder
        model = LSTMAutoencoder(seq_len=48, hidden_size=32, num_layers=1)
        model.eval()
        x = torch.randn(2, 48, 1)
        with torch.no_grad():
            recon = model(x)
        assert recon.shape == (2, 48, 1)

    def test_reconstruction_scorer(self):
        from anomaly.autoencoder.detector import ReconstructionScorer
        scorer = ReconstructionScorer(seq_len=48, use_transformer=False)
        series = np.random.randn(100).tolist()
        scores = scorer.score(series)
        assert len(scores) == 100
        assert all(isinstance(s, float) for s in scores)
