"""
Enterprise Temporal AI Platform — Thread Pool Manager

Provides:
- A global GPU inference executor (1 thread — serialises CUDA calls safely)
- A global CPU worker pool (N threads for preprocessing / scoring / IO)
- A global IO executor (for disk reads, Redis, HTTP without blocking event loop)
- Context-manager helpers for clean shutdown

Why separate pools?
  GPU executor  → torch inference must NOT run concurrently on the same device;
                  1-thread pool queues requests safely without deadlocking CUDA.
  CPU pool      → sklearn, numpy, scipy — all release the GIL; real parallelism.
  IO pool       → file reads, serialisation, light CPU work — high thread count ok.
"""

from __future__ import annotations

import atexit
import multiprocessing
import os
from concurrent.futures import ThreadPoolExecutor
from typing import Optional

from shared.logging.logger import get_logger

log = get_logger("shared.thread_pool")

# ─────────────────────────────────────────────────────────────────────────────
# Pool sizing
# ─────────────────────────────────────────────────────────────────────────────

_cpu_count = multiprocessing.cpu_count()

# GPU pool: always 1 thread — CUDA context is per-process, not thread-safe
_GPU_WORKERS = 1

# CPU pool: half the logical cores (leaves headroom for the main async loop)
_CPU_WORKERS = max(2, _cpu_count // 2)

# IO pool: more threads since they spend most time waiting
_IO_WORKERS = min(32, _cpu_count * 4)

# Allow env-variable overrides
_GPU_WORKERS = int(os.getenv("TEMPORAL_GPU_WORKERS", _GPU_WORKERS))
_CPU_WORKERS = int(os.getenv("TEMPORAL_CPU_WORKERS", _CPU_WORKERS))
_IO_WORKERS  = int(os.getenv("TEMPORAL_IO_WORKERS", _IO_WORKERS))


# ─────────────────────────────────────────────────────────────────────────────
# Singleton executors — created lazily on first access
# ─────────────────────────────────────────────────────────────────────────────

_gpu_executor:  Optional[ThreadPoolExecutor] = None
_cpu_executor:  Optional[ThreadPoolExecutor] = None
_io_executor:   Optional[ThreadPoolExecutor] = None


def gpu_executor() -> ThreadPoolExecutor:
    """
    Single-thread pool for all PyTorch GPU inference calls.
    Serialises CUDA operations safely across async coroutines.
    """
    global _gpu_executor
    if _gpu_executor is None:
        _gpu_executor = ThreadPoolExecutor(
            max_workers=_GPU_WORKERS,
            thread_name_prefix="temporal-gpu",
        )
        log.info("thread_pool.gpu_created", workers=_GPU_WORKERS)
    return _gpu_executor


def cpu_executor() -> ThreadPoolExecutor:
    """
    Multi-thread pool for CPU-bound work: sklearn, scipy, numpy scoring.
    These operations release the GIL so true parallelism is achieved.
    """
    global _cpu_executor
    if _cpu_executor is None:
        _cpu_executor = ThreadPoolExecutor(
            max_workers=_CPU_WORKERS,
            thread_name_prefix="temporal-cpu",
        )
        log.info("thread_pool.cpu_created", workers=_CPU_WORKERS)
    return _cpu_executor


def io_executor() -> ThreadPoolExecutor:
    """
    High-concurrency pool for IO-bound work: Redis, HTTP, file reads.
    """
    global _io_executor
    if _io_executor is None:
        _io_executor = ThreadPoolExecutor(
            max_workers=_IO_WORKERS,
            thread_name_prefix="temporal-io",
        )
        log.info("thread_pool.io_created", workers=_IO_WORKERS)
    return _io_executor


# ─────────────────────────────────────────────────────────────────────────────
# Graceful shutdown
# ─────────────────────────────────────────────────────────────────────────────

def shutdown_all(wait: bool = True) -> None:
    """Gracefully shut down all executor pools. Called automatically at exit."""
    for name, pool in [("gpu", _gpu_executor), ("cpu", _cpu_executor), ("io", _io_executor)]:
        if pool is not None:
            log.info(f"thread_pool.shutdown", pool=name)
            pool.shutdown(wait=wait)


atexit.register(shutdown_all)


# ─────────────────────────────────────────────────────────────────────────────
# Stats helper
# ─────────────────────────────────────────────────────────────────────────────

def pool_stats() -> dict:
    return {
        "gpu":  {"max_workers": _GPU_WORKERS, "active": _gpu_executor is not None},
        "cpu":  {"max_workers": _CPU_WORKERS, "active": _cpu_executor is not None},
        "io":   {"max_workers": _IO_WORKERS,  "active": _io_executor  is not None},
        "cpu_count": _cpu_count,
    }
