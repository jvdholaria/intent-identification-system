# Running the Platform Locally with a CSV File

Two modes:
- **Pure Python** (no Docker) — fastest, ideal for experimentation
- **Docker + Python** (Redis + MLflow + Grafana) — full observability

---

## Mode A — Pure Python (No Docker)

### 1. Install dependencies

```bash
cd enterprise-temporal-ai

# Auto-detect GPU and install everything:
python setup_local.py

# CPU-only machines:
python setup_local.py --cpu

# Minimal install (fastest):
python setup_local.py --cpu --minimal

# Verify what's installed:
python setup_local.py --check
```

### 2. Prepare your CSV

Your CSV can look like **any** of these formats — the loader auto-detects columns:

```
# Format A — timestamp + value
timestamp,value
2023-01-01 00:00:00,12.5
2023-01-01 01:00:00,13.1

# Format B — date column + target column with a different name
date,sales,region
2023-01-01,450.0,North
2023-01-02,512.3,North

# Format C — no timestamp (synthetic index will be generated)
kwh
14.2
15.1
13.8

# Format D — multi-variate
timestamp,cpu,memory,latency
2024-01-01 00:00,23.1,55.2,48.0
2024-01-01 00:10,24.5,55.8,51.2
```

### 3. Preview your CSV (optional but recommended)

```python
from shared.data.csv_loader import preview_csv
info = preview_csv("your_data.csv")
print(info["columns"])              # → ['timestamp', 'value', ...]
print(info["timestamp_candidates"]) # → ['timestamp']
print(info["numeric_candidates"])   # → ['value', 'temperature']
```

### 4. Run the full pipeline

```bash
# Minimal — auto-detect columns:
python run_local.py --csv data/your_file.csv --target value

# Specify timestamp + target explicitly:
python run_local.py \
  --csv data/energy.csv \
  --timestamp timestamp \
  --target kwh

# Full options:
python run_local.py \
  --csv data/energy.csv \
  --timestamp timestamp \
  --target kwh \
  --freq 1H \
  --window 168 \
  --horizon 120 \
  --model patchtst \
  --epochs 50 \
  --norm zscore \
  --out ./results
```

#### Quick mode (instant results, no training):
```bash
python run_local.py --csv data/energy.csv --target kwh --quick
```

#### Run only specific steps:
```bash
# Only preprocess + forecast (skip training):
python run_local.py --csv data.csv --target value --steps prepare forecast

# Only anomaly + drift check:
python run_local.py --csv data.csv --target value --steps prepare anomaly drift
```

### 5. Understand the output

After the run, `./local_results/` contains:

```
local_results/
├── forecast_output.csv      ← per-step forecast with bounds + quantiles
├── anomaly_output.csv       ← per-point anomaly scores + flags
├── report.json              ← full pipeline summary
├── checkpoints/
│   └── gru-best.ckpt        ← best model checkpoint
└── processed/
    ├── train.npy            ← normalised training split
    ├── val.npy              ← validation split
    ├── test.npy             ← test split
    ├── full.npy             ← full normalised series
    ├── timestamps.csv       ← aligned timestamps
    └── metadata.json        ← config + stats used
```

**forecast_output.csv** columns:

| Column | Description |
|---|---|
| `step` | Forecast step (1 = next period) |
| `forecast` | Point forecast (P50, original scale) |
| `lower_bound` | 95% confidence lower bound |
| `upper_bound` | 95% confidence upper bound |
| `p10` | 10th percentile (pessimistic) |
| `p90` | 90th percentile (optimistic) |
| `uncertainty` | Per-step uncertainty estimate |

**anomaly_output.csv** columns:

| Column | Description |
|---|---|
| `index` | Time step index |
| `actual` | Observed value (original scale) |
| `predicted` | Model-predicted value |
| `residual` | actual − predicted |
| `anomaly_score` | Hybrid score (0 = normal, higher = anomalous) |
| `is_anomaly` | True/False flag |

---

## Mode B — Docker + Python (Recommended)

This starts Redis (for caching), MLflow (for tracking), and Grafana (for dashboards) locally — then you run the Python pipeline against them.

### 1. Start infrastructure services

```bash
# Start Redis + MLflow + Grafana (no GCP needed):
docker-compose -f docker-compose.local.yml up -d

# Verify all services are healthy:
docker-compose -f docker-compose.local.yml ps
```

Services started:

| Service | URL | Credentials |
|---|---|---|
| MLflow | http://localhost:5000 | — |
| Grafana | http://localhost:3000 | admin / temporal |
| Redis | localhost:6379 | — |

### 2. Copy and configure environment

```bash
cp .env.example .env
# .env already has localhost URLs by default — no changes needed for local use
```

### 3. Install Python dependencies

```bash
python setup_local.py --cpu   # or without --cpu if you have a GPU
```

### 4. Run the pipeline (same as Mode A)

```bash
python run_local.py \
  --csv data/your_file.csv \
  --target value \
  --model gru \
  --epochs 30
```

With Docker running, training runs are now tracked in MLflow at http://localhost:5000.

### 5. View experiments in MLflow

```
http://localhost:5000
→ Experiments → local/<target>/<model>
→ See: val_loss, training_time_s, hyperparameters
```

### 6. Stop services

```bash
docker-compose -f docker-compose.local.yml down
```

---

## Generate Test Data (No Real CSV Yet)

```bash
# Energy consumption (hourly, 1 year):
python generate_sample_data.py --type energy --out ./data
python run_local.py --csv data/energy.csv --target kwh

# Retail sales (daily, 2 years):
python generate_sample_data.py --type sales --out ./data
python run_local.py --csv data/sales.csv --target sales --freq 1D --window 30 --horizon 14

# Server CPU metrics (10-min intervals):
python generate_sample_data.py --type server --out ./data
python run_local.py --csv data/server.csv --target cpu_percent --freq 10T --window 144 --horizon 48

# IoT sensor (1-min, 1 week):
python generate_sample_data.py --type sensor --out ./data
python run_local.py --csv data/sensor.csv --target temperature_c --freq 1T --window 1440 --horizon 60

# Multi-variate power (wind + solar + power):
python generate_sample_data.py --type multivar --out ./data
python run_local.py --csv data/multivar.csv --target power_kw --features wind_speed_ms,temperature_c
```

---

## Common CSV Column Configurations

| CSV type | `--timestamp` | `--target` | `--freq` | `--window` | `--horizon` |
|---|---|---|---|---|---|
| Hourly energy | `timestamp` | `kwh` | `1H` | `168` | `120` |
| Daily sales | `date` | `sales` | `1D` | `30` | `14` |
| 15-min IoT | `ts` | `sensor_val` | `15T` | `192` | `96` |
| Monthly finance | `month` | `revenue` | `1M` | `24` | `12` |
| 1-min server | `datetime` | `cpu` | `1T` | `1440` | `60` |
| Weekly demand | `week_start` | `demand` | `1W` | `52` | `8` |

---

## Choosing a Model

| Model | Speed | Accuracy | Best For |
|---|---|---|---|
| `gru` | ⚡⚡⚡ Fastest | Good | Quick experiments, small datasets |
| `nbeats` | ⚡⚡ Fast | Very good | Interpretable decomposition |
| `patchtst` | ⚡ Medium | Excellent | Long series, complex patterns |
| `tft` | ⚡ Medium | Excellent | Multi-variate, interpretable |
| `timesnet` | ⚡ Medium | Very good | Multi-period patterns |

**Recommended workflow:**
```bash
# Start with GRU to validate your data + pipeline quickly:
python run_local.py --csv data.csv --target val --model gru --epochs 10 --quick

# Once data looks right, train a better model:
python run_local.py --csv data.csv --target val --model patchtst --epochs 50
```

---

## Use the Forecast Results Programmatically

```python
import pandas as pd
import numpy as np

# Load results
forecast = pd.read_csv("local_results/forecast_output.csv")
anomalies = pd.read_csv("local_results/anomaly_output.csv")

# Plot forecast with confidence intervals
import matplotlib.pyplot as plt
plt.figure(figsize=(14, 5))
plt.plot(forecast["forecast"], label="Forecast (P50)", color="blue")
plt.fill_between(forecast.index, forecast["lower_bound"], forecast["upper_bound"],
                 alpha=0.2, label="95% CI")
plt.fill_between(forecast.index, forecast["p10"], forecast["p90"],
                 alpha=0.3, color="orange", label="P10-P90")
plt.legend()
plt.title("Temporal AI — Probabilistic Forecast")
plt.tight_layout()
plt.savefig("forecast_plot.png")

# Show detected anomalies
anom_mask = anomalies["is_anomaly"]
print(f"Anomalies detected: {anom_mask.sum()} / {len(anomalies)}")
print(anomalies[anom_mask][["index", "actual", "predicted", "anomaly_score"]].head(10))

# Direct Python API usage (no HTTP):
from shared.data.csv_loader import CSVLoaderConfig, CSVTemporalLoader
from forecasting.inference.engine import ForecastEngine
from shared.config.settings import settings
import asyncio

loader = CSVTemporalLoader(CSVLoaderConfig(target_column="kwh"))
ds = loader.load("data/energy.csv")

engine = ForecastEngine(settings=settings)
result = asyncio.run(engine.run(
    series=ds.test[:168].tolist(),
    horizon=24,
    model="gru",
    quantiles=[0.1, 0.5, 0.9],
    tenant_id="local",
))
print(f"Next 24h forecast: {result['forecast'][:5]}")
print(f"Uncertainty:       {result['uncertainty'][:5]}")
```

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `Target column 'value' not found` | Check column names with `python -c "from shared.data.csv_loader import preview_csv; print(preview_csv('your.csv')['columns'])"` |
| `Series too short for window_size=168` | Add `--window 24` or `--window 48` for shorter datasets |
| `CUDA out of memory` | Add `--batch-size 16` or use `--cpu` flag in setup |
| `MLflow unreachable` | Run `docker-compose -f docker-compose.local.yml up mlflow` or ignore (results still saved locally) |
| Slow training | Use `--model gru --epochs 10` for a quick first run; GRU is 5-10x faster than PatchTST |
| NaN in forecast | Your CSV has missing values — try `--norm robust` or ensure gap filling works |
| `ModuleNotFoundError` | Run `python setup_local.py` first |
