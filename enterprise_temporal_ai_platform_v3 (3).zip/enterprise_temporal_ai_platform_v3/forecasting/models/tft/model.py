"""
Enterprise Temporal AI Platform — TFT (Temporal Fusion Transformer) Predictor

Based on: "Temporal Fusion Transformers for Interpretable Multi-horizon Time Series Forecasting"
(Lim et al., 2021). Supports multi-horizon prediction with variable selection,
gated residual networks, and interpretable attention.
"""

from __future__ import annotations

from typing import Optional

import numpy as np
import torch
import torch.nn as nn

from shared.config.settings import Settings
from shared.logging.logger import get_logger

log = get_logger("models.tft")


class GatedResidualNetwork(nn.Module):
    """Core GRN building block of TFT."""

    def __init__(self, input_dim: int, hidden_dim: int, output_dim: int, dropout: float = 0.1):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, output_dim)
        self.gate = nn.Linear(hidden_dim, output_dim)
        self.skip = nn.Linear(input_dim, output_dim) if input_dim != output_dim else nn.Identity()
        self.norm = nn.LayerNorm(output_dim)
        self.dropout = nn.Dropout(dropout)
        self.elu = nn.ELU()
        self.sigmoid = nn.Sigmoid()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.elu(self.fc1(x))
        eta = self.fc2(self.dropout(h))
        gate = self.sigmoid(self.gate(h))
        out = self.norm(gate * eta + self.skip(x))
        return out


class VariableSelectionNetwork(nn.Module):
    """Selects most relevant input variables via softmax-weighted GRNs."""

    def __init__(self, num_vars: int, d_model: int, dropout: float = 0.1):
        super().__init__()
        self.grns = nn.ModuleList([
            GatedResidualNetwork(d_model, d_model, d_model, dropout)
            for _ in range(num_vars)
        ])
        self.softmax_grn = GatedResidualNetwork(num_vars * d_model, d_model, num_vars, dropout)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, seq, num_vars, d_model)
        processed = torch.stack(
            [self.grns[i](x[..., i, :]) for i in range(len(self.grns))],
            dim=-2,
        )  # (batch, seq, num_vars, d_model)

        flat = x.reshape(x.size(0), x.size(1), -1)
        weights = self.softmax(self.softmax_grn(flat))  # (batch, seq, num_vars)
        out = (weights.unsqueeze(-1) * processed).sum(dim=-2)  # (batch, seq, d_model)
        return out


class InterpretableMultiHeadAttention(nn.Module):
    """Simplified interpretable attention head for TFT."""

    def __init__(self, d_model: int, n_heads: int, dropout: float = 0.1):
        super().__init__()
        self.attn = nn.MultiheadAttention(d_model, n_heads, dropout=dropout, batch_first=True)
        self.norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, q, k, v):
        out, weights = self.attn(q, k, v)
        return self.norm(q + self.dropout(out)), weights


class TFTModel(nn.Module):
    """
    Simplified Temporal Fusion Transformer for multi-step forecasting.
    """

    def __init__(
        self,
        seq_len: int = 168,
        pred_len: int = 120,
        d_model: int = 128,
        n_heads: int = 4,
        num_layers: int = 2,
        dropout: float = 0.1,
        num_static_vars: int = 0,
        num_dynamic_vars: int = 1,
    ):
        super().__init__()
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.d_model = d_model

        # Input projection
        self.input_proj = nn.Linear(num_dynamic_vars, d_model)

        # LSTM encoder (local processing)
        self.lstm_encoder = nn.LSTM(d_model, d_model, num_layers=num_layers,
                                     batch_first=True, dropout=dropout)
        self.lstm_decoder = nn.LSTM(d_model, d_model, num_layers=num_layers,
                                     batch_first=True, dropout=dropout)

        # Gated residual networks
        self.grn_encoder = GatedResidualNetwork(d_model, d_model * 2, d_model, dropout)
        self.grn_decoder = GatedResidualNetwork(d_model, d_model * 2, d_model, dropout)

        # Interpretable attention
        self.attention = InterpretableMultiHeadAttention(d_model, n_heads, dropout)

        # Output
        self.output_proj = nn.Linear(d_model, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, seq_len, 1)
        enc_in = self.input_proj(x)                          # (batch, seq_len, d_model)
        enc_out, (h, c) = self.lstm_encoder(enc_in)
        enc_out = self.grn_encoder(enc_out)

        # Decoder uses encoder hidden state; target is future zeros (inference)
        dec_in = torch.zeros(x.size(0), self.pred_len, self.d_model, device=x.device)
        dec_out, _ = self.lstm_decoder(dec_in, (h, c))
        dec_out = self.grn_decoder(dec_out)

        # Self-attention over decoder output conditioned on encoder
        attended, _ = self.attention(dec_out, enc_out, enc_out)

        out = self.output_proj(attended).squeeze(-1)        # (batch, pred_len)
        return out


class TFTPredictor:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._model: Optional[TFTModel] = None

    def _load(self):
        if self._model is not None:
            return
        self._model = TFTModel(
            seq_len=self.settings.FORECAST_WINDOW_SIZE,
            pred_len=self.settings.FORECAST_HORIZON,
        ).to(self.device)
        self._model.eval()
        log.info("tft.loaded", device=str(self.device))

    def predict(self, x: np.ndarray, horizon: int) -> np.ndarray:
        self._load()
        with torch.no_grad():
            arr = np.asarray(x, dtype=np.float32).flatten()
            tensor = torch.tensor(arr).unsqueeze(0).unsqueeze(-1).to(self.device)  # (1, seq_len, 1)
            out = self._model(tensor)   # (1, pred_len)
            result = out.squeeze(0).cpu().numpy()
            if len(result) >= horizon:
                return result[:horizon]
            return np.pad(result, (0, horizon - len(result)), mode="edge")
