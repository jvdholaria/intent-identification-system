"""
Enterprise Temporal AI Platform — Structured Logging
"""

from __future__ import annotations

import logging
import sys
import time
import uuid
from contextvars import ContextVar
from functools import wraps
from typing import Any, Callable, Optional

import structlog
from structlog.types import EventDict, WrappedLogger

# Context variables for request tracing
_request_id_var: ContextVar[Optional[str]] = ContextVar("request_id", default=None)
_tenant_id_var: ContextVar[Optional[str]] = ContextVar("tenant_id", default=None)
_user_id_var: ContextVar[Optional[str]] = ContextVar("user_id", default=None)


def set_request_context(
    request_id: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_id: Optional[str] = None,
) -> None:
    _request_id_var.set(request_id or str(uuid.uuid4()))
    _tenant_id_var.set(tenant_id)
    _user_id_var.set(user_id)


def add_temporal_context(
    logger: WrappedLogger,
    method_name: str,
    event_dict: EventDict,
) -> EventDict:
    """Inject tracing context into every log record."""
    request_id = _request_id_var.get()
    tenant_id = _tenant_id_var.get()
    user_id = _user_id_var.get()

    if request_id:
        event_dict["request_id"] = request_id
    if tenant_id:
        event_dict["tenant_id"] = tenant_id
    if user_id:
        event_dict["user_id"] = user_id

    return event_dict


def configure_logging(
    service_name: str,
    log_level: str = "INFO",
    json_output: bool = True,
) -> None:
    """
    Configure structlog for the given service.
    Call once at startup from each microservice main.py.
    """
    processors = [
        structlog.contextvars.merge_contextvars,
        add_temporal_context,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]

    if json_output:
        processors.append(structlog.processors.JSONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer(colors=True))

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(
            logging.getLevelName(log_level.upper())
        ),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=True,
    )

    # Also configure stdlib logging so third-party libs emit clean logs
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=logging.getLevelName(log_level.upper()),
    )


def get_logger(name: str) -> structlog.BoundLogger:
    """Return a bound logger for the given module."""
    return structlog.get_logger(name)


# ──────────────────────────────────────────────────────────────────────────────
# Decorator helpers
# ──────────────────────────────────────────────────────────────────────────────

def log_execution(
    logger: Optional[structlog.BoundLogger] = None,
    log_args: bool = False,
) -> Callable:
    """
    Decorator that logs function entry, exit and elapsed time.

    Usage::

        @log_execution(logger=log)
        async def my_endpoint(req: ForecastRequest):
            ...
    """
    def decorator(fn: Callable) -> Callable:
        _log = logger or get_logger(fn.__module__)

        @wraps(fn)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            start = time.perf_counter()
            _log.info("fn.start", fn=fn.__name__)
            try:
                result = await fn(*args, **kwargs)
                elapsed = (time.perf_counter() - start) * 1000
                _log.info("fn.ok", fn=fn.__name__, elapsed_ms=round(elapsed, 2))
                return result
            except Exception as exc:
                elapsed = (time.perf_counter() - start) * 1000
                _log.error(
                    "fn.error",
                    fn=fn.__name__,
                    elapsed_ms=round(elapsed, 2),
                    exc=str(exc),
                )
                raise

        @wraps(fn)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            start = time.perf_counter()
            _log.info("fn.start", fn=fn.__name__)
            try:
                result = fn(*args, **kwargs)
                elapsed = (time.perf_counter() - start) * 1000
                _log.info("fn.ok", fn=fn.__name__, elapsed_ms=round(elapsed, 2))
                return result
            except Exception as exc:
                elapsed = (time.perf_counter() - start) * 1000
                _log.error(
                    "fn.error",
                    fn=fn.__name__,
                    elapsed_ms=round(elapsed, 2),
                    exc=str(exc),
                )
                raise

        import asyncio
        if asyncio.iscoroutinefunction(fn):
            return async_wrapper
        return sync_wrapper

    return decorator
