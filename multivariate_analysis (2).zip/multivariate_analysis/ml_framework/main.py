"""
main.py — Demonstration of the ML framework on synthetic multi-source data.

This script shows the complete end-to-end workflow:

  1. Simulate three asynchronous data sources (sensors, control signals, weather).
  2. Intentionally inject noise, missing values, and irregular cadences.
  3. Configure and run the full MLPipeline.
  4. Inspect evaluation metrics and SHAP explanations.
  5. Demonstrate real-time and batch inference.

Run:
    python main.py

The framework adapts to real data by replacing the `generate_*` functions
with actual data loading and adjusting DataSourceConfig entries accordingly.
"""

from __future__ import annotations

import logging
import os
import warnings
from typing import Dict

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)-8s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("main")


# ---------------------------------------------------------------------------
# Synthetic data generators
# ---------------------------------------------------------------------------

def generate_sensor_data(n_days: int = 90, seed: int = 42) -> pd.DataFrame:
    """
    Simulate 20 sensor readings sampled at 5-minute intervals.

    Features are correlated via a shared latent process (temperature trend)
    and contain realistic noise, occasional dropouts, and a few spikes.
    """
    rng = np.random.default_rng(seed)
    freq = "5min"
    idx  = pd.date_range("2024-01-01", periods=n_days * 24 * 12, freq=freq, tz="UTC")
    N    = len(idx)

    # Shared latent trend
    t           = np.linspace(0, 4 * np.pi, N)
    trend       = 20 + 5 * np.sin(t) + rng.normal(0, 0.5, N)
    hour_effect = 3 * np.sin(2 * np.pi * np.arange(N) / (24 * 12))

    data: Dict[str, np.ndarray] = {}
    for i in range(20):
        weight = rng.uniform(0.3, 1.0)
        noise  = rng.normal(0, rng.uniform(0.5, 2.0), N)
        signal = weight * trend + hour_effect + noise + rng.uniform(-5, 15)
        # Inject 3 % missing values and 0.5 % spikes
        missing_mask = rng.random(N) < 0.03
        spike_mask   = rng.random(N) < 0.005
        signal[missing_mask] = np.nan
        signal[spike_mask]  += rng.uniform(20, 50) * rng.choice([-1, 1])
        data[f"sensor_{i:02d}"] = signal

    # Categorical operational mode — changes every 8 hours
    n_blocks     = N // (8 * 12) + 1
    mode_seq     = rng.choice(["normal", "maintenance", "high_load"], n_blocks)
    mode_repeated = np.repeat(mode_seq, 8 * 12)[:N]
    data["op_mode"] = mode_repeated

    df = pd.DataFrame(data, index=idx)
    df.index.name = "timestamp"
    return df.reset_index()


def generate_control_signals(n_days: int = 90, seed: int = 7) -> pd.DataFrame:
    """
    Simulate 5 control setpoints sampled at 1-minute intervals.

    Setpoints are piecewise constant (step changes every 30–90 minutes).
    """
    rng  = np.random.default_rng(seed)
    freq = "1min"
    idx  = pd.date_range("2024-01-01", periods=n_days * 24 * 60, freq=freq, tz="UTC")
    N    = len(idx)

    data: Dict[str, np.ndarray] = {}
    for i in range(5):
        # Piecewise constant with random step sizes
        signal = np.zeros(N)
        val    = rng.uniform(0, 100)
        pos    = 0
        while pos < N:
            step      = rng.integers(30, 90)
            end       = min(pos + step, N)
            val      += rng.normal(0, 5)
            val       = np.clip(val, 0, 100)
            signal[pos:end] = val
            pos = end
        data[f"setpoint_{i}"] = signal

    df = pd.DataFrame(data, index=idx)
    df.index.name = "timestamp"
    return df.reset_index()


def generate_weather_data(n_days: int = 90, seed: int = 99) -> pd.DataFrame:
    """
    Simulate 3 weather variables sampled hourly (irregular weather API cadence).
    """
    rng  = np.random.default_rng(seed)
    freq = "1H"
    idx  = pd.date_range("2024-01-01", periods=n_days * 24, freq=freq, tz="UTC")
    N    = len(idx)

    t            = np.linspace(0, 4 * np.pi, N)
    temperature  = 15 + 8 * np.sin(t) + rng.normal(0, 1, N)
    humidity     = np.clip(60 + 10 * np.cos(t) + rng.normal(0, 5, N), 10, 100)
    wind_speed   = np.abs(rng.normal(5, 3, N))

    df = pd.DataFrame({
        "temperature":  temperature,
        "humidity":     humidity,
        "wind_speed":   wind_speed,
        "timestamp":    idx,
    })
    return df


def generate_targets(merged_df: pd.DataFrame, seed: int = 0) -> pd.DataFrame:
    """
    Create two synthetic regression targets that depend non-linearly on
    the merged feature set. In a real system these would be observed labels
    (e.g., energy consumption, production yield, failure probability).
    """
    rng = np.random.default_rng(seed)
    N   = len(merged_df)

    # Find sensor columns (prefix added by ingestion: "sensors__sensor_XX")
    sensor_cols = [c for c in merged_df.columns if "sensor" in c.lower()]
    ctrl_cols   = [c for c in merged_df.columns if "setpoint" in c.lower()]

    sensor_vals = merged_df[sensor_cols].fillna(method="ffill").fillna(0).values
    ctrl_vals   = merged_df[ctrl_cols].fillna(method="ffill").fillna(0).values

    # Target 1: energy consumption (non-linear combination of sensors + controls)
    y1 = (
        0.4 * sensor_vals[:, :5].mean(axis=1)
        + 0.2 * (ctrl_vals[:, 0] * ctrl_vals[:, 1]) / 1000
        + 0.1 * np.sin(sensor_vals[:, 0] / 10)
        + rng.normal(0, 2, N)
    )

    # Target 2: production yield (depends on operational mode + weather)
    weather_cols = [c for c in merged_df.columns if "temperature" in c.lower()]
    temp_vals    = merged_df[weather_cols].fillna(method="ffill").fillna(15).values[:, 0] if weather_cols else np.zeros(N)
    y2 = (
        80
        - 0.3 * np.abs(temp_vals - 18)    # yield drops when temp deviates from 18 °C
        + 0.05 * sensor_vals[:, -1]
        + rng.normal(0, 1.5, N)
    )

    merged_df = merged_df.copy()
    merged_df["energy_kw"]    = np.clip(y1, 0, None)
    merged_df["yield_percent"] = np.clip(y2, 0, 100)
    return merged_df


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    logger.info("Generating synthetic multi-source data ...")
    n_days = 60

    df_sensors = generate_sensor_data(n_days)
    df_control = generate_control_signals(n_days)
    df_weather = generate_weather_data(n_days)

    # ── Configure the pipeline ──────────────────────────────────────────────
    from ml_framework.core.config import (
        DataSourceConfig,
        DeepModelConfig,
        EnsembleConfig,
        ExplainabilityConfig,
        FrameworkConfig,
        PreprocessingConfig,
        TemporalConfig,
        TrainingConfig,
        TreeModelConfig,
    )

    cfg = FrameworkConfig(
        project_name="synthetic_system",
        output_dir="./outputs",
        targets=["energy_kw", "yield_percent"],
        mode="tree",               # "tree" | "deep" | "both" | "ensemble"
        prediction_type="static",  # "static" | "temporal"

        data_sources=[
            DataSourceConfig(
                name="sensors",
                numerical_cols=[f"sensor_{i:02d}" for i in range(20)],
                categorical_cols=["op_mode"],
                subsystem="sensors",
            ),
            DataSourceConfig(
                name="control",
                numerical_cols=[f"setpoint_{i}" for i in range(5)],
                subsystem="control",
            ),
            DataSourceConfig(
                name="weather",
                numerical_cols=["temperature", "humidity", "wind_speed"],
                subsystem="weather",
            ),
        ],

        temporal=TemporalConfig(
            resample_freq="15min",
            aggregation_method="mean",
            interpolation_method="linear",
            max_gap_fill_periods=8,
            window_size=16,
            horizon=1,
        ),

        preprocessing=PreprocessingConfig(
            scaler="robust",
            encoder="ordinal",
            imputer="median",
            dim_reduction="none",
            auto_feature_engineering=True,
            lag_periods=[1, 2, 4, 8],
            rolling_windows=[4, 8],
            add_time_features=True,
        ),

        tree_model=TreeModelConfig(
            model_type="lgbm",
            n_estimators=300,
            learning_rate=0.05,
            early_stopping_rounds=30,
            multi_output_strategy="direct",
        ),

        deep_model=DeepModelConfig(
            architecture="transformer",
            hidden_size=64,
            num_layers=2,
            num_heads=4,
            dropout=0.1,
            batch_size=128,
            max_epochs=20,
            patience=5,
            device="auto",
        ),

        ensemble=EnsembleConfig(
            use_ensemble=False,
            weights={"tree": 0.55, "deep": 0.45},
        ),

        training=TrainingConfig(
            test_fraction=0.15,
            val_fraction=0.15,
            n_cv_folds=3,
            metrics=["mae", "rmse", "r2", "mape"],
            seed=42,
        ),

        explainability=ExplainabilityConfig(
            enabled=True,
            backend="shap",
            n_background_samples=100,
            n_explain_samples=20,
            plot_top_k_features=15,
        ),
    )

    # ── Run ingestion manually so we can inject targets ──────────────────────
    from ml_framework.core.data_ingestion import DataIngestionPipeline

    logger.info("Running data ingestion ...")
    ingestion = DataIngestionPipeline(cfg)
    merged_df = ingestion.run({
        "sensors": df_sensors,
        "control": df_control,
        "weather": df_weather,
    })

    logger.info("Injecting synthetic targets ...")
    merged_df = generate_targets(merged_df)
    logger.info("Merged DataFrame shape: %s", merged_df.shape)
    logger.info("Columns: %s", merged_df.columns.tolist()[:10])

    # ── Fit the pipeline ─────────────────────────────────────────────────────
    from ml_framework.pipeline import MLPipeline

    logger.info("Fitting MLPipeline ...")
    pipeline = MLPipeline(cfg)
    pipeline.fit(merged_df=merged_df)

    # ── Batch inference on a held-out slice ─────────────────────────────────
    logger.info("Running batch inference ...")
    inference_df = merged_df.iloc[-200:].drop(
        columns=["energy_kw", "yield_percent"], errors="ignore"
    )
    result = pipeline.predict(inference_df)
    print("\nSample predictions:")
    print(result.to_dataframe().head(5).to_string())

    # ── Real-time inference (single row) ────────────────────────────────────
    row = {col: merged_df[col].dropna().iloc[-1]
           for col in merged_df.columns
           if col not in ("energy_kw", "yield_percent")}
    rt_result = pipeline.predict_realtime(row)
    print(f"\nReal-time prediction: {dict(zip(rt_result.target_names, rt_result.predictions[0]))}")
    print(f"Inference latency: {rt_result.latency_ms:.2f} ms")

    # ── Save checkpoint ──────────────────────────────────────────────────────
    logger.info("Saving pipeline checkpoint ...")
    os.makedirs("./outputs", exist_ok=True)
    pipeline.save("./outputs/checkpoint")

    logger.info("Done. Artefacts written to ./outputs/")


if __name__ == "__main__":
    main()
