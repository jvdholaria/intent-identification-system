#!/usr/bin/env python3
"""
Enterprise Temporal AI Platform — Threading Benchmark
======================================================
Measures the actual speedup from multi-threading on your hardware.

Usage:
    python benchmark_threading.py               # run all benchmarks
    python benchmark_threading.py --only engine # just forecast engine
    python benchmark_threading.py --only anomaly
    python benchmark_threading.py --only drift
    python benchmark_threading.py --only csv
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
import tempfile
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

os.environ.setdefault("ENV", "development")
os.environ.setdefault("REDIS_URL", "redis://localhost:6379")
os.environ.setdefault("MLFLOW_TRACKING_URI", "http://localhost:5000")

from shared.config.settings import settings
from shared.utilities.thread_pool import pool_stats

SERIES_LEN = 500
HORIZON = 24
N_RUNS = 3   # average over N runs


def _make_series(n=SERIES_LEN):
    return (np.sin(np.linspace(0, 4 * np.pi, n)) + 0.1 * np.random.randn(n)).astype(np.float32)


def _time(fn, n=N_RUNS):
    """Run fn() n times and return mean elapsed seconds."""
    times = []
    for _ in range(n):
        t0 = time.perf_counter()
        fn()
        times.append(time.perf_counter() - t0)
    return float(np.mean(times))


def _time_async(coro_fn, n=N_RUNS):
    """Run async coro_fn() n times and return mean elapsed seconds."""
    times = []
    for _ in range(n):
        t0 = time.perf_counter()
        asyncio.run(coro_fn())
        times.append(time.perf_counter() - t0)
    return float(np.mean(times))


def _speedup(seq: float, par: float) -> str:
    s = seq / par if par > 0 else 0
    bar = "█" * min(int(s * 4), 32)
    return f"{s:.2f}×  {bar}"


# ─────────────────────────────────────────────────────────────────────────────
# 1. Forecast Engine — Sequential vs Parallel Ensemble
# ─────────────────────────────────────────────────────────────────────────────

def bench_forecast_engine():
    print("\n" + "═" * 60)
    print("  BENCHMARK 1 — Forecast Engine  (Sequential vs Parallel Ensemble)")
    print("═" * 60)
    series = _make_series()

    # Sequential: call each model one after another (old behaviour)
    from forecasting.models.gru.model import GRUPredictor
    gru = GRUPredictor(settings)

    def sequential():
        results = []
        for _ in range(5):   # simulate 5 ensemble models
            results.append(gru.predict(series.copy(), HORIZON))
        return np.mean(results, axis=0)

    # Parallel: submit all via executor (new behaviour)
    from forecasting.inference.engine import ForecastEngine
    from shared.schemas.schemas import ModelType

    engine = ForecastEngine(settings)

    async def parallel():
        return await engine.run(
            series=series.tolist(),
            horizon=HORIZON,
            model=ModelType.gru,
            quantiles=[0.1, 0.5, 0.9],
            tenant_id="bench",
        )

    print(f"\n  Warming up models...", end="", flush=True)
    sequential(); asyncio.run(parallel())
    print(" done")

    t_seq = _time(sequential)
    t_par = _time_async(parallel)

    print(f"\n  Sequential  : {t_seq*1000:>8.1f} ms / call")
    print(f"  Parallel    : {t_par*1000:>8.1f} ms / call")
    print(f"  Speedup     : {_speedup(t_seq, t_par)}")
    return t_seq, t_par


# ─────────────────────────────────────────────────────────────────────────────
# 2. Anomaly Detection — Sequential vs Parallel
# ─────────────────────────────────────────────────────────────────────────────

def bench_anomaly():
    print("\n" + "═" * 60)
    print("  BENCHMARK 2 — Anomaly Detection  (Sequential vs Parallel)")
    print("═" * 60)

    n = 2000
    actual    = _make_series(n).tolist()
    predicted = _make_series(n).tolist()

    # Sequential (old EnsembleAnomalyPipeline)
    from anomaly.hybrid.scorer import EnsembleAnomalyPipeline
    seq_pipeline = EnsembleAnomalyPipeline()

    def sequential():
        return seq_pipeline.run(actual=actual, predicted=predicted)

    # Parallel
    from anomaly.hybrid.parallel_pipeline import ParallelAnomalyPipeline
    par_pipeline = ParallelAnomalyPipeline()

    def parallel():
        return par_pipeline.run(actual=actual, predicted=predicted)

    print(f"  Series length: {n:,} points  ({N_RUNS} runs each)")
    t_seq = _time(sequential)
    t_par = _time(parallel)

    print(f"\n  Sequential  : {t_seq*1000:>8.1f} ms")
    print(f"  Parallel    : {t_par*1000:>8.1f} ms")
    print(f"  Speedup     : {_speedup(t_seq, t_par)}")
    return t_seq, t_par


# ─────────────────────────────────────────────────────────────────────────────
# 3. Drift Detection — Sequential vs Parallel
# ─────────────────────────────────────────────────────────────────────────────

def bench_drift():
    print("\n" + "═" * 60)
    print("  BENCHMARK 3 — Drift Detection  (Sequential vs Parallel)")
    print("═" * 60)

    n = 5000
    baseline = np.random.normal(0.0, 1.0, n).tolist()
    current  = np.random.normal(0.5, 1.2, n).tolist()

    from anomaly.drift.drift_detector import DriftDetector
    from anomaly.drift.parallel_drift  import ParallelDriftDetector

    seq_det = DriftDetector()
    par_det = ParallelDriftDetector()

    def sequential():
        return seq_det.detect(baseline, current)

    def parallel():
        return par_det.detect(baseline, current)

    print(f"  Distribution size: {n:,} points  ({N_RUNS} runs each)")
    t_seq = _time(sequential)
    t_par = _time(parallel)

    print(f"\n  Sequential  : {t_seq*1000:>8.1f} ms")
    print(f"  Parallel    : {t_par*1000:>8.1f} ms")
    print(f"  Speedup     : {_speedup(t_seq, t_par)}")
    return t_seq, t_par


# ─────────────────────────────────────────────────────────────────────────────
# 4. CSV Loading — Sequential vs Parallel chunks
# ─────────────────────────────────────────────────────────────────────────────

def bench_csv():
    print("\n" + "═" * 60)
    print("  BENCHMARK 4 — CSV Loading  (Sequential vs Parallel Chunks)")
    print("═" * 60)

    # Generate a temp CSV with 100k rows
    n = 100_000
    import pandas as pd
    ts = pd.date_range("2020-01-01", periods=n, freq="1min")
    df = pd.DataFrame({
        "timestamp": ts,
        "value": np.sin(np.linspace(0, 100 * np.pi, n)) + 0.1 * np.random.randn(n),
    })
    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False, mode="w") as f:
        df.to_csv(f, index=False)
        csv_path = f.name

    from shared.data.csv_loader import CSVLoaderConfig, CSVTemporalLoader
    from shared.data.parallel_csv_loader import ParallelCSVLoader

    config = CSVLoaderConfig(
        timestamp_column="timestamp",
        target_column="value",
        resample_freq="1h",
        window_size=168,
        horizon=24,
    )

    def sequential():
        return CSVTemporalLoader(config).load(csv_path)

    def parallel():
        return ParallelCSVLoader(config).load(csv_path)

    print(f"  CSV rows: {n:,}  ({N_RUNS} runs each)")
    print(f"  Warming up...", end="", flush=True)
    sequential(); parallel()
    print(" done")

    t_seq = _time(sequential, n=2)
    t_par = _time(parallel,   n=2)

    os.unlink(csv_path)

    print(f"\n  Sequential  : {t_seq*1000:>8.1f} ms")
    print(f"  Parallel    : {t_par*1000:>8.1f} ms")
    print(f"  Speedup     : {_speedup(t_seq, t_par)}")
    return t_seq, t_par


# ─────────────────────────────────────────────────────────────────────────────
# Summary
# ─────────────────────────────────────────────────────────────────────────────

def print_summary(results: dict):
    print("\n" + "═" * 60)
    print("  SUMMARY — Multi-Threading Speedup")
    print("═" * 60)
    stats = pool_stats()
    print(f"\n  CPU cores    : {stats['cpu_count']}")
    print(f"  GPU pool     : {stats['gpu']['max_workers']} thread(s)")
    print(f"  CPU pool     : {stats['cpu']['max_workers']} threads")
    print(f"  IO pool      : {stats['io']['max_workers']} threads")
    print()
    print(f"  {'Benchmark':<30}  {'Sequential':>12}  {'Parallel':>10}  {'Speedup':>8}")
    print("  " + "─" * 66)
    total_seq = total_par = 0.0
    for name, (t_seq, t_par) in results.items():
        print(f"  {name:<30}  {t_seq*1000:>10.1f}ms  {t_par*1000:>8.1f}ms  {t_seq/max(t_par,1e-9):>6.2f}×")
        total_seq += t_seq
        total_par += t_par
    print("  " + "─" * 66)
    print(f"  {'TOTAL':<30}  {total_seq*1000:>10.1f}ms  {total_par*1000:>8.1f}ms  {total_seq/max(total_par,1e-9):>6.2f}×")
    print()


def main():
    parser = argparse.ArgumentParser(description="Temporal AI — Threading Benchmark")
    parser.add_argument("--only", choices=["engine", "anomaly", "drift", "csv"])
    parser.add_argument("--runs", type=int, default=3)
    args = parser.parse_args()

    global N_RUNS
    N_RUNS = args.runs

    results = {}
    try:
        if not args.only or args.only == "engine":
            results["Forecast Engine (ensemble)"] = bench_forecast_engine()
        if not args.only or args.only == "anomaly":
            results["Anomaly Detection"] = bench_anomaly()
        if not args.only or args.only == "drift":
            results["Drift Detection"] = bench_drift()
        if not args.only or args.only == "csv":
            results["CSV Loading (100k rows)"] = bench_csv()
    except KeyboardInterrupt:
        print("\n  Interrupted.")

    if len(results) > 1:
        print_summary(results)


if __name__ == "__main__":
    main()
