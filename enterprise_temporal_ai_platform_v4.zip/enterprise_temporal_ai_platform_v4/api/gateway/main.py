"""
Enterprise Temporal AI Platform — API Gateway

Central entry point. Proxies traffic to:
  - Forecast Service  (:8001)
  - Anomaly Service   (:8002)
  - Drift Service     (:8003)
  - LLM Service       (:8004)

Adds:
  - Request ID generation
  - Tenant header injection
  - Rate limiting (Redis token-bucket)
  - Metrics instrumentation
"""

from __future__ import annotations

import time
import uuid
from contextlib import asynccontextmanager
from typing import AsyncGenerator

import httpx
import redis.asyncio as aioredis
import uvicorn
from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from prometheus_client import Counter, Histogram, make_asgi_app

from shared.config.settings import settings
from shared.logging.logger import configure_logging, get_logger, set_request_context

configure_logging("api-gateway", settings.LOG_LEVEL, settings.is_production)
log = get_logger("api_gateway")

GATEWAY_REQUESTS = Counter(
    "gateway_requests_total",
    "Total requests through gateway",
    ["service", "method", "status"],
)
GATEWAY_LATENCY = Histogram(
    "gateway_request_latency_seconds",
    "Gateway proxy latency",
    ["service"],
)

# ── Service routing table ─────────────────────────────────────────────────────
SERVICE_MAP = {
    "/forecast": settings.FORECAST_SERVICE_URL,
    "/anomaly": settings.ANOMALY_SERVICE_URL,
    "/drift": settings.DRIFT_SERVICE_URL,
    "/llm": settings.LLM_SERVICE_URL,
}


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator:
    log.info("api_gateway.startup")
    app.state.redis = aioredis.from_url(settings.REDIS_URL, decode_responses=True)
    app.state.http_client = httpx.AsyncClient(timeout=30.0, limits=httpx.Limits(max_connections=200))
    yield
    await app.state.redis.aclose()
    await app.state.http_client.aclose()
    log.info("api_gateway.shutdown")


def create_app() -> FastAPI:
    app = FastAPI(
        title="Temporal AI — API Gateway",
        description="Central gateway routing to all Temporal AI microservices.",
        version="1.0.0",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.middleware("http")
    async def gateway_middleware(request: Request, call_next):
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
        tenant_id = request.headers.get("X-Tenant-ID", "default")
        user_id = request.headers.get("X-User-ID", "anonymous")
        set_request_context(request_id, tenant_id, user_id)

        # ── Rate limiting (token bucket per tenant) ───────────────────────────
        rate_ok = await _check_rate_limit(request.app.state.redis, tenant_id)
        if not rate_ok:
            return JSONResponse(
                status_code=429,
                content={"status": "error", "message": "Rate limit exceeded"},
                headers={"X-Request-ID": request_id},
            )

        start = time.perf_counter()
        response = await call_next(request)
        elapsed = (time.perf_counter() - start) * 1000

        response.headers["X-Request-ID"] = request_id
        response.headers["X-Response-Time-Ms"] = str(round(elapsed, 2))

        log.info(
            "gateway.request",
            path=request.url.path,
            method=request.method,
            status=response.status_code,
            tenant=tenant_id,
            elapsed_ms=round(elapsed, 2),
        )
        return response

    # ── Health ────────────────────────────────────────────────────────────────
    @app.get("/health")
    async def health():
        return {"status": "ok", "service": "api-gateway", "version": "1.0.0"}

    # ── Gateway routes — proxy to downstream services ─────────────────────────
    @app.api_route(
        "/forecast/{path:path}",
        methods=["GET", "POST", "PUT", "DELETE"],
        tags=["Gateway"],
        summary="Proxy to Forecast Service",
    )
    async def proxy_forecast(path: str, request: Request):
        return await _proxy(request, settings.FORECAST_SERVICE_URL, f"/v1/{path}", "forecast")

    @app.api_route(
        "/anomaly/{path:path}",
        methods=["GET", "POST", "PUT", "DELETE"],
        tags=["Gateway"],
        summary="Proxy to Anomaly Service",
    )
    async def proxy_anomaly(path: str, request: Request):
        return await _proxy(request, settings.ANOMALY_SERVICE_URL, f"/v1/{path}", "anomaly")

    @app.api_route(
        "/drift/{path:path}",
        methods=["GET", "POST"],
        tags=["Gateway"],
        summary="Proxy to Drift Service",
    )
    async def proxy_drift(path: str, request: Request):
        return await _proxy(request, settings.DRIFT_SERVICE_URL, f"/v1/{path}", "drift")

    # ── Prometheus ────────────────────────────────────────────────────────────
    app.mount("/metrics", make_asgi_app())

    return app


async def _proxy(
    request: Request,
    base_url: str,
    path: str,
    service_name: str,
) -> Response:
    client: httpx.AsyncClient = request.app.state.http_client
    url = f"{base_url}{path}"
    body = await request.body()

    try:
        t0 = time.perf_counter()
        upstream = await client.request(
            method=request.method,
            url=url,
            headers={k: v for k, v in request.headers.items() if k.lower() != "host"},
            content=body,
            params=dict(request.query_params),
        )
        elapsed = time.perf_counter() - t0

        GATEWAY_REQUESTS.labels(
            service=service_name,
            method=request.method,
            status=upstream.status_code,
        ).inc()
        GATEWAY_LATENCY.labels(service=service_name).observe(elapsed)

        return Response(
            content=upstream.content,
            status_code=upstream.status_code,
            headers=dict(upstream.headers),
            media_type=upstream.headers.get("content-type"),
        )
    except httpx.ConnectError:
        log.error("gateway.upstream_unreachable", service=service_name, url=url)
        raise HTTPException(status_code=503, detail=f"Service '{service_name}' unreachable")
    except Exception as exc:
        log.error("gateway.proxy_error", service=service_name, exc=str(exc))
        raise HTTPException(status_code=502, detail=str(exc))


async def _check_rate_limit(redis, tenant_id: str, limit: int = 100, window: int = 60) -> bool:
    """Simple sliding-window rate limiter using Redis INCR + EXPIRE."""
    key = f"temporal:ratelimit:{tenant_id}:{int(time.time()) // window}"
    count = await redis.incr(key)
    if count == 1:
        await redis.expire(key, window)
    return count <= limit


app = create_app()

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=settings.GATEWAY_PORT, reload=False)
