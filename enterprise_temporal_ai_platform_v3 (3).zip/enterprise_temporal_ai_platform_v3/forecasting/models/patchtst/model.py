"""
Enterprise Temporal AI Platform — PatchTST Predictor

PatchTST:
A Time Series is Worth 64 Words
(Long-term Forecasting with Transformers)
"""

from __future__ import annotations

from typing import Optional

import numpy as np
import torch
import torch.nn as nn

from shared.config.settings import Settings
from shared.logging.logger import get_logger

log = get_logger("models.patchtst")


# -----------------------------------------------------------------------------
# PATCH EMBEDDING
# -----------------------------------------------------------------------------

class PatchEmbedding(nn.Module):
    """
    Segment sequence into patches and project into transformer dimension.
    """

    def __init__(
        self,
        patch_len: int,
        stride: int,
        d_model: int,
        dropout: float = 0.1,
    ):
        super().__init__()

        self.patch_len = patch_len
        self.stride = stride

        self.projection = nn.Linear(patch_len, d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x:
            (B, C, L)

        Returns:
            (B, num_patches, d_model)
        """

        # ---------------------------------------------------------------------
        # SINGLE CHANNEL FORECASTING
        # ---------------------------------------------------------------------

        x = x[:, 0, :]  # (B, L)

        patches = x.unfold(
            dimension=-1,
            size=self.patch_len,
            step=self.stride,
        )

        # (B, num_patches, patch_len)

        out = self.projection(patches)
        out = self.dropout(out)

        return out


# -----------------------------------------------------------------------------
# TRANSFORMER BLOCK
# -----------------------------------------------------------------------------

class PatchTSTBlock(nn.Module):

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        d_ff: int,
        dropout: float = 0.1,
    ):
        super().__init__()

        self.attn = nn.MultiheadAttention(
            embed_dim=d_model,
            num_heads=n_heads,
            dropout=dropout,
            batch_first=True,
        )

        self.ff = nn.Sequential(
            nn.Linear(d_model, d_ff),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_ff, d_model),
        )

        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)

        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:

        attn_out, _ = self.attn(x, x, x)

        x = self.norm1(x + self.dropout(attn_out))
        x = self.norm2(x + self.dropout(self.ff(x)))

        return x


# -----------------------------------------------------------------------------
# PATCHTST MODEL
# -----------------------------------------------------------------------------

class PatchTSTModel(nn.Module):
    """
    Patch-based Transformer for time-series forecasting.
    """

    def __init__(
        self,
        seq_len: int = 168,
        pred_len: int = 120,
        patch_len: int = 16,
        stride: int = 8,
        d_model: int = 64,
        n_heads: int = 4,
        n_layers: int = 2,
        d_ff: int = 128,
        dropout: float = 0.1,
    ):
        super().__init__()

        self.seq_len = seq_len
        self.pred_len = pred_len

        self.patch_len = patch_len
        self.stride = stride

        num_patches = (seq_len - patch_len) // stride + 1

        self.patch_embed = PatchEmbedding(
            patch_len,
            stride,
            d_model,
            dropout,
        )

        self.pos_enc = nn.Parameter(
            torch.randn(1, num_patches, d_model) * 0.02
        )

        self.encoder = nn.Sequential(
            *[
                PatchTSTBlock(
                    d_model,
                    n_heads,
                    d_ff,
                    dropout,
                )
                for _ in range(n_layers)
            ]
        )

        self.head = nn.Linear(
            num_patches * d_model,
            pred_len,
        )

        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x:
            (B, C, L)

        Returns:
            (B, pred_len)
        """

        if x.dim() != 3:
            raise ValueError(
                f"PatchTST expected 3D input (B,C,L), got {x.shape}"
            )

        x = x.float()

        patches = self.patch_embed(x)

        patches = patches + self.pos_enc

        encoded = self.encoder(patches)

        flat = encoded.reshape(encoded.size(0), -1)

        out = self.head(self.dropout(flat))

        return out


# -----------------------------------------------------------------------------
# PREDICTOR WRAPPER
# -----------------------------------------------------------------------------

class PatchTSTPredictor:

    def __init__(self, settings: Settings):

        self.settings = settings

        self.device = torch.device(
            "cuda" if torch.cuda.is_available() else "cpu"
        )

        self._model: Optional[PatchTSTModel] = None

    def _load(self):

        if self._model is not None:
            return

        self._model = PatchTSTModel(
            seq_len=self.settings.FORECAST_WINDOW_SIZE,
            pred_len=self.settings.FORECAST_HORIZON,
        ).to(self.device)

        self._model.eval()

        try:
            import mlflow

            mlflow.set_tracking_uri(
                self.settings.MLFLOW_TRACKING_URI
            )

            log.info(
                "patchtst.loaded",
                device=str(self.device),
            )

        except Exception as exc:

            log.warning(
                "patchtst.mlflow_unavailable",
                exc=str(exc),
            )

    def predict(self, x: np.ndarray, horizon: int) -> np.ndarray:

        self._load()

        with torch.no_grad():

            arr = np.asarray(x, dtype=np.float32).flatten()

            tensor = torch.tensor(arr)
            tensor = tensor.unsqueeze(0).unsqueeze(0)
            tensor = tensor.to(self.device)

            out = self._model(tensor)

            result = out.squeeze(0).cpu().numpy()

            if len(result) >= horizon:
                return result[:horizon]

            return np.pad(
                result,
                (0, horizon - len(result)),
                mode="edge",
            )
