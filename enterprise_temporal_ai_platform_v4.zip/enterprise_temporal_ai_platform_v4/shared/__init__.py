"""Shared package init files — generated automatically."""
