"""
Enterprise Temporal AI Platform V4 — Inference Engine

V4 API contract:
    Request:  { "asset_id": "A001", "telemetry": { "temp": [...], "pressure": [...] } }
    Response: { "asset_id": "A001", "forecast": { "temp": [...], "pressure": [...] } }

Handles:
  - Batch inference
  - Unknown asset handling (zero-embedding fallback)
  - Feature validation against model registry
  - Multi-target output unpacking
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Optional, Any

import numpy as np
import torch

from shared.config.settings import Settings
from shared.logging.logger import get_logger

log = get_logger("forecast.inference")


# ─────────────────────────────────────────────────────────────────────────────
# Request / Response schemas
# ─────────────────────────────────────────────────────────────────────────────

class ForecastRequest:
    def __init__(self, asset_id: str, telemetry: Dict[str, List[float]]):
        self.asset_id  = asset_id
        self.telemetry = telemetry   # {"feature1": [v1,v2,...], "feature2": [...]}

    @classmethod
    def from_dict(cls, d: Dict) -> "ForecastRequest":
        return cls(d["asset_id"], d["telemetry"])


class ForecastResponse:
    def __init__(self, asset_id: str, forecast: Dict[str, List[float]], metadata: Dict = None):
        self.asset_id = asset_id
        self.forecast = forecast    # {"target1": [v1,...], "target2": [...]}
        self.metadata = metadata or {}

    def to_dict(self) -> Dict:
        return {"asset_id": self.asset_id, "forecast": self.forecast, "metadata": self.metadata}


# ─────────────────────────────────────────────────────────────────────────────
# Inference Engine
# ─────────────────────────────────────────────────────────────────────────────

class InferenceEngine:
    """
    Multi-asset multivariate inference engine.

    Loads model + asset encoder from a processed data directory.
    Validates incoming feature set against trained feature names.
    Returns per-target forecasts keyed by target column name.
    """

    def __init__(self, settings: Settings):
        self.settings = settings
        self.device   = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self._model       = None
        self._metadata    = None
        self._asset_map   = {}    # asset_name → int id
        self._feature_names: List[str] = []
        self._target_names:  List[str] = []

    # ─────────────────────────────────────────────────────────────────────────
    # Load artefacts
    # ─────────────────────────────────────────────────────────────────────────

    def load_from_directory(self, data_dir: str, model_path: Optional[str] = None):
        """
        Load metadata, asset encoder, and optionally a saved model.

        data_dir: path to the processed data directory (output of CSVTemporalLoader.export_npy)
        model_path: path to a saved .pt model file (optional)
        """
        base = Path(data_dir)

        # Load metadata
        meta_path = base / "metadata.json"
        if meta_path.exists():
            self._metadata = json.loads(meta_path.read_text())
            self._feature_names = self._metadata.get("target_columns", []) + \
                                  self._metadata.get("feature_columns", [])
            self._target_names  = self._metadata.get("target_columns", [])
            log.info("inference.metadata_loaded", features=self._feature_names, targets=self._target_names)

        # Load asset encoder
        enc_path = base / "asset_encoder.json"
        if enc_path.exists():
            enc = json.loads(enc_path.read_text())
            self._asset_map = enc.get("mapping", {})
            log.info("inference.asset_encoder_loaded", num_assets=len(self._asset_map))

        # Load model weights
        if model_path and Path(model_path).exists():
            self._model = torch.load(model_path, map_location=self.device)
            self._model.eval()
            log.info("inference.model_loaded", path=model_path)

        return self

    def load_model(self, model: torch.nn.Module):
        """Inject a pre-built model (used after training)."""
        self._model = model.to(self.device)
        self._model.eval()
        return self

    def set_schema(self, feature_names: List[str], target_names: List[str], asset_map: Dict[str, int]):
        self._feature_names = feature_names
        self._target_names  = target_names
        self._asset_map     = asset_map
        return self

    # ─────────────────────────────────────────────────────────────────────────
    # Single request inference
    # ─────────────────────────────────────────────────────────────────────────

    def predict(self, request: ForecastRequest) -> ForecastResponse:
        if self._model is None:
            raise RuntimeError("No model loaded. Call load_from_directory() or load_model() first.")

        # ── Validate features ─────────────────────────────────────────────────
        missing = [f for f in self._feature_names if f not in request.telemetry]
        if missing:
            log.warning("inference.missing_features", missing=missing, asset=request.asset_id)

        # ── Build input tensor [1, L, F] ──────────────────────────────────────
        L = self.settings.FORECAST_WINDOW_SIZE
        channels = []
        for feat in self._feature_names:
            vals = request.telemetry.get(feat, [])
            arr  = np.array(vals, dtype=np.float32)
            if len(arr) >= L:
                arr = arr[-L:]
            else:
                # Pad with last known value or zeros
                pad = np.full(L - len(arr), arr[-1] if len(arr) > 0 else 0.0, dtype=np.float32)
                arr = np.concatenate([pad, arr])
            channels.append(arr)

        if not channels:
            raise ValueError(f"No valid feature channels for asset {request.asset_id}")

        x = np.stack(channels, axis=-1)       # [L, F]
        x_t = torch.tensor(x).unsqueeze(0).to(self.device)  # [1, L, F]

        # ── Resolve asset id ──────────────────────────────────────────────────
        asset_int = self._asset_map.get(str(request.asset_id))
        if asset_int is None:
            log.warning("inference.unknown_asset", asset=request.asset_id, fallback=0)
            asset_int = 0   # zero-embedding fallback for unseen assets

        aid_t = torch.tensor([asset_int], dtype=torch.long, device=self.device)

        # ── Run model ─────────────────────────────────────────────────────────
        with torch.no_grad():
            out = self._model(x_t, aid_t)    # [1, H, T]

        forecast_arr = out.squeeze(0).cpu().numpy()   # [H, T]

        # ── Unpack per-target forecasts ───────────────────────────────────────
        forecast_dict = {}
        for t_idx, t_name in enumerate(self._target_names):
            if t_idx < forecast_arr.shape[-1]:
                forecast_dict[t_name] = forecast_arr[:, t_idx].tolist()

        return ForecastResponse(
            asset_id=request.asset_id,
            forecast=forecast_dict,
            metadata={
                "model": self._model.__class__.__name__,
                "asset_int": asset_int,
                "horizon": forecast_arr.shape[0],
                "num_targets": len(self._target_names),
            },
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Batch inference
    # ─────────────────────────────────────────────────────────────────────────

    def predict_batch(self, requests: List[ForecastRequest]) -> List[ForecastResponse]:
        """
        Batch inference: stacks all requests into a single forward pass.
        """
        if self._model is None:
            raise RuntimeError("No model loaded.")

        L = self.settings.FORECAST_WINDOW_SIZE
        X_batch    = []
        asset_ints = []

        for req in requests:
            channels = []
            for feat in self._feature_names:
                vals = req.telemetry.get(feat, [])
                arr  = np.array(vals, dtype=np.float32)
                if len(arr) >= L:
                    arr = arr[-L:]
                else:
                    pad = np.full(L - len(arr), arr[-1] if len(arr) > 0 else 0.0)
                    arr = np.concatenate([pad, arr]).astype(np.float32)
                channels.append(arr)

            X_batch.append(np.stack(channels, axis=-1))   # [L, F]

            asset_int = self._asset_map.get(str(req.asset_id), 0)
            asset_ints.append(asset_int)

        X_t   = torch.tensor(np.array(X_batch), dtype=torch.float32).to(self.device)   # [B, L, F]
        aid_t = torch.tensor(asset_ints, dtype=torch.long).to(self.device)             # [B]

        with torch.no_grad():
            out = self._model(X_t, aid_t)   # [B, H, T]

        forecasts_arr = out.cpu().numpy()   # [B, H, T]

        responses = []
        for i, req in enumerate(requests):
            forecast_dict = {
                t_name: forecasts_arr[i, :, t_idx].tolist()
                for t_idx, t_name in enumerate(self._target_names)
                if t_idx < forecasts_arr.shape[-1]
            }
            responses.append(ForecastResponse(
                asset_id=req.asset_id,
                forecast=forecast_dict,
                metadata={"asset_int": asset_ints[i]},
            ))

        return responses
