"""
Enterprise Temporal AI Platform — Residual-Based Anomaly Detector

Detects anomalies by comparing actual vs predicted values.
Uses dynamic sigma thresholding with rolling statistics.
"""

from __future__ import annotations

from typing import List, Tuple

import numpy as np

from shared.logging.logger import get_logger

log = get_logger("anomaly.residual")


class ResidualDetector:
    """
    Residual-based anomaly detection.

    Score = |actual - predicted| normalised by rolling std.
    """

    def __init__(
        self,
        threshold_sigma: float = 3.0,
        rolling_window: int = 24,
        min_periods: int = 6,
    ):
        self.threshold_sigma = threshold_sigma
        self.rolling_window = rolling_window
        self.min_periods = min_periods

    def score(
        self,
        actual: List[float],
        predicted: List[float],
    ) -> List[float]:
        """
        Compute per-point normalised residual scores.

        Returns scores in [0, inf) where values > 1 indicate anomalies.
        """
        actual_arr = np.array(actual, dtype=np.float64)
        predicted_arr = np.array(predicted, dtype=np.float64)
        residuals = actual_arr - predicted_arr
        abs_residuals = np.abs(residuals)

        # Rolling mean + std for dynamic normalisation
        scores = np.zeros_like(abs_residuals)
        for i in range(len(abs_residuals)):
            start = max(0, i - self.rolling_window)
            window = abs_residuals[start : i + 1]
            if len(window) < self.min_periods:
                mu, sigma = 0.0, 1.0
            else:
                mu = float(np.mean(window))
                sigma = float(np.std(window)) or 1.0
            scores[i] = (abs_residuals[i] - mu) / sigma

        return [round(float(s), 4) for s in scores]

    def dynamic_threshold(
        self,
        actual: List[float],
        predicted: List[float],
    ) -> float:
        """
        Compute a dynamic detection threshold based on the
        distribution of residuals in the input series.
        """
        residuals = np.abs(np.array(actual) - np.array(predicted))
        mu = float(np.mean(residuals))
        sigma = float(np.std(residuals)) or 1.0
        return mu + self.threshold_sigma * sigma

    def detect(
        self,
        actual: List[float],
        predicted: List[float],
    ) -> Tuple[List[bool], List[float]]:
        """
        Return (anomaly_flags, scores).
        """
        scores = self.score(actual, predicted)
        threshold = self.dynamic_threshold(actual, predicted)
        flags = [s > threshold for s in scores]
        return flags, scores

    def seasonal_residual_score(
        self,
        actual: List[float],
        predicted: List[float],
        period: int = 24,
    ) -> List[float]:
        """
        Augmented score that also penalises deviation from weekly/daily seasonality.
        Subtracts the same-period-lagged residual to remove seasonal component.
        """
        actual_arr = np.array(actual, dtype=np.float64)
        predicted_arr = np.array(predicted, dtype=np.float64)
        base_residuals = actual_arr - predicted_arr

        adjusted = np.zeros_like(base_residuals)
        for i in range(len(base_residuals)):
            if i >= period:
                seasonal_component = base_residuals[i - period]
                adjusted[i] = base_residuals[i] - seasonal_component
            else:
                adjusted[i] = base_residuals[i]

        abs_adj = np.abs(adjusted)
        sigma = float(np.std(abs_adj)) or 1.0
        mu = float(np.mean(abs_adj))
        scores = [(float(v) - mu) / sigma for v in abs_adj]
        return [round(s, 4) for s in scores]
