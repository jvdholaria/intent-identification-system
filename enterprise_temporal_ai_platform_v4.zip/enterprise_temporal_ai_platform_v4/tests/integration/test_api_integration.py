"""
Integration tests — Forecast + Anomaly API (uses httpx AsyncClient against live app)
"""

from __future__ import annotations

import pytest
import numpy as np
from httpx import AsyncClient, ASGITransport

# We test against the FastAPI apps directly (no real Redis required with fakeredis)


@pytest.fixture(scope="module")
def forecast_app():
    """Create the forecast FastAPI app with a fake Redis in test mode."""
    import os
    os.environ.setdefault("ENV", "development")
    os.environ.setdefault("REDIS_URL", "redis://localhost:6379")
    os.environ.setdefault("MLFLOW_TRACKING_URI", "http://localhost:5000")
    os.environ.setdefault("DATABASE_URL", "sqlite:///./test.db")

    from api.forecasting_api.main import create_app
    return create_app()


@pytest.fixture(scope="module")
def anomaly_app():
    import os
    os.environ.setdefault("ENV", "development")
    from api.anomaly_api.main import create_app
    return create_app()


# ─────────────────────────────────────────────────────────────────────────────
# Forecast API Tests
# ─────────────────────────────────────────────────────────────────────────────

class TestForecastModelsEndpoint:
    @pytest.mark.asyncio
    async def test_list_models_returns_200(self, forecast_app):
        async with AsyncClient(
            transport=ASGITransport(app=forecast_app), base_url="http://test"
        ) as client:
            resp = await client.get("/v1/forecast/models")
        assert resp.status_code == 200
        data = resp.json()
        assert "models" in data
        assert "ensemble" in data["models"]
        assert "primary" in data
        assert "ensemble_weights" in data

    @pytest.mark.asyncio
    async def test_forecast_config_returns_correct_fields(self, forecast_app):
        async with AsyncClient(
            transport=ASGITransport(app=forecast_app), base_url="http://test"
        ) as client:
            resp = await client.get("/v1/forecast/config")
        assert resp.status_code == 200
        data = resp.json()
        assert data["window_size"] == 168
        assert data["horizon"] == 120
        assert data["multi_step"] is True
        assert data["strategy"] == "seq2seq"


class TestForecastEndpoint:
    def make_series(self, n=200):
        t = np.linspace(0, 4 * np.pi, n)
        return (np.sin(t) + 0.1 * np.random.randn(n)).tolist()

    @pytest.mark.asyncio
    async def test_forecast_request_schema_validated(self, forecast_app):
        """Missing required field 'series' should return 422."""
        async with AsyncClient(
            transport=ASGITransport(app=forecast_app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/v1/forecast",
                json={"tenant_id": "t1", "user_id": "u1"},   # missing series
            )
        assert resp.status_code == 422

    @pytest.mark.asyncio
    async def test_forecast_short_series_returns_422(self, forecast_app):
        async with AsyncClient(
            transport=ASGITransport(app=forecast_app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/v1/forecast",
                json={"tenant_id": "t1", "user_id": "u1", "series": [1.0]},
            )
        assert resp.status_code == 422


# ─────────────────────────────────────────────────────────────────────────────
# Anomaly API Tests
# ─────────────────────────────────────────────────────────────────────────────

class TestAnomalyEndpoint:
    def make_series(self, n=50, spike_idx=None):
        actual = np.sin(np.linspace(0, 2 * np.pi, n)).tolist()
        predicted = np.sin(np.linspace(0, 2 * np.pi, n)).tolist()
        if spike_idx:
            actual[spike_idx] += 10.0
        return actual, predicted

    @pytest.mark.asyncio
    async def test_mismatched_lengths_422(self, anomaly_app):
        async with AsyncClient(
            transport=ASGITransport(app=anomaly_app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/v1/detect",
                json={
                    "tenant_id": "t1",
                    "user_id": "u1",
                    "actual": [1.0, 2.0, 3.0],
                    "predicted": [1.0, 2.0],    # wrong length
                },
            )
        assert resp.status_code == 422

    @pytest.mark.asyncio
    async def test_empty_series_returns_422(self, anomaly_app):
        async with AsyncClient(
            transport=ASGITransport(app=anomaly_app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/v1/detect",
                json={
                    "tenant_id": "t1",
                    "user_id": "u1",
                    "actual": [],
                    "predicted": [],
                },
            )
        # Empty series allowed by schema but downstream should handle gracefully
        assert resp.status_code in (200, 422, 500)


# ─────────────────────────────────────────────────────────────────────────────
# Drift Detection Tests
# ─────────────────────────────────────────────────────────────────────────────

class TestDriftDetector:
    @pytest.mark.asyncio
    async def test_detect_no_drift(self):
        from anomaly.drift.drift_detector import DriftDetector
        import numpy as np
        np.random.seed(0)
        detector = DriftDetector()
        a = np.random.normal(0, 1, 300).tolist()
        b = np.random.normal(0, 1, 300).tolist()
        results = detector.detect(a, b)
        score = detector.overall_score(results)
        assert score < 0.5

    @pytest.mark.asyncio
    async def test_detect_strong_drift(self):
        from anomaly.drift.drift_detector import DriftDetector
        import numpy as np
        np.random.seed(0)
        detector = DriftDetector()
        a = np.random.normal(0.0, 1.0, 300).tolist()
        b = np.random.normal(20.0, 1.0, 300).tolist()
        results = detector.detect(a, b)
        score = detector.overall_score(results)
        assert score > 0.3
        assert any(r.detected for r in results)


# ─────────────────────────────────────────────────────────────────────────────
# Feature Store Tests
# ─────────────────────────────────────────────────────────────────────────────

class TestFeatureEngineering:
    def test_lag_features(self):
        from feature_store.feast.client import TemporalFeatureClient
        import numpy as np
        series = np.arange(200, dtype=float)
        features = TemporalFeatureClient.build_lag_features(series)
        assert "lag_1h" in features
        assert "lag_168h" in features
        assert features["lag_1h"] == 198.0

    def test_rolling_stats(self):
        from feature_store.feast.client import TemporalFeatureClient
        import numpy as np
        series = np.random.randn(100)
        features = TemporalFeatureClient.build_rolling_stats(series)
        assert "rolling_mean_24h" in features
        assert "rolling_std_24h" in features
        assert "rolling_p10_24h" in features

    def test_seasonality_features(self):
        from feature_store.feast.client import TemporalFeatureClient
        from datetime import datetime
        dt = datetime(2024, 3, 15, 9, 0, 0)   # Friday 9am
        features = TemporalFeatureClient.build_seasonality_features(dt)
        assert features["hour_of_day"] == 9.0
        assert features["is_business_hour"] == 1.0
        assert features["is_weekend"] == 0.0
        assert "sin_hour" in features
        assert "cos_day" in features
