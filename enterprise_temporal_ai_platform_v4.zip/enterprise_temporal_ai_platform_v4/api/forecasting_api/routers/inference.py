"""
Enterprise Temporal AI Platform — Inference Router
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request

from shared.config.settings import settings
from shared.logging.logger import get_logger

log = get_logger("forecast.inference_router")
router = APIRouter()


async def get_redis(request: Request):
    return request.app.state.redis


@router.get(
    "/inference/{tenant_id}/{series_id}/latest",
    summary="Get latest cached inference result",
)
async def get_latest_inference(
    tenant_id: str,
    series_id: str,
    redis=Depends(get_redis),
):
    """
    Return the most recent forecast result for a given series,
    retrieved from the Redis buffer populated by the streaming consumer.
    """
    key = f"{settings.TENANT_NAMESPACE_PREFIX}:{tenant_id}:latest:{series_id}"
    raw = await redis.get(key)
    if not raw:
        raise HTTPException(
            status_code=404,
            detail=f"No cached inference found for series '{series_id}' under tenant '{tenant_id}'",
        )
    import json
    return json.loads(raw)


@router.get(
    "/inference/{tenant_id}/queue/stats",
    summary="Return inference queue statistics",
)
async def queue_stats(tenant_id: str, redis=Depends(get_redis)):
    """Return depth and throughput stats for the tenant's inference queue."""
    queue_key = f"{settings.REDIS_QUEUE_KEY}:{tenant_id}"
    queue_len = await redis.llen(queue_key)
    return {
        "tenant_id": tenant_id,
        "queue_depth": queue_len,
        "queue_key": queue_key,
    }
