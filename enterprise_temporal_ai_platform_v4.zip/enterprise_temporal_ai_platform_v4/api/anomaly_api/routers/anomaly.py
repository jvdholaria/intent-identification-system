"""
Enterprise Temporal AI Platform — Anomaly Detection Router
"""

from __future__ import annotations

import uuid
from typing import List

from fastapi import APIRouter, Depends, HTTPException, Request

from shared.config.settings import settings
from shared.logging.logger import get_logger
from shared.schemas.schemas import AnomalyRequest, AnomalyResponse, AnomalyDetail

log = get_logger("anomaly.router")
router = APIRouter()


async def get_redis(request: Request):
    return request.app.state.redis


@router.post("/detect", response_model=AnomalyResponse, summary="Hybrid anomaly detection")
async def detect(
    req: AnomalyRequest,
    redis=Depends(get_redis),
) -> AnomalyResponse:
    """
    Run hybrid anomaly detection combining:

    - **Residual-based** (actual − predicted, weighted 0.5)
    - **Autoencoder reconstruction** (LSTM / Transformer, weighted 0.3)
    - **Drift-aware** scoring (weighted 0.2)

    Returns per-point anomaly scores, detected anomaly details, and
    an optional LLM-generated natural-language explanation.
    """
    from anomaly.hybrid.scorer import HybridAnomalyScorer
    from anomaly.residual.detector import ResidualDetector
    from llm.explainability.explainer import LLMAnomalyExplainer

    request_id = req.request_id or str(uuid.uuid4())

    # ── Step 1: Residual scores ───────────────────────────────────────────────
    residual_detector = ResidualDetector(
        threshold_sigma=req.threshold_sigma,
    )
    residual_scores = residual_detector.score(req.actual, req.predicted)

    # ── Step 2: Reconstruction scores (placeholder — loaded from model registry) ─
    reconstruction_scores = [0.0] * len(req.actual)

    # ── Step 3: Drift scores (fetched from drift service via Redis cache) ─────
    drift_cache_key = (
        f"{settings.TENANT_NAMESPACE_PREFIX}:{req.tenant_id}:drift:latest"
    )
    raw_drift = await redis.get(drift_cache_key)
    drift_score_global = float(raw_drift) if raw_drift else 0.0
    drift_scores = [drift_score_global] * len(req.actual)

    # ── Step 4: Hybrid scoring ────────────────────────────────────────────────
    scorer = HybridAnomalyScorer(
        residual_weight=settings.ANOMALY_RESIDUAL_WEIGHT,
        reconstruction_weight=settings.ANOMALY_RECONSTRUCTION_WEIGHT,
        drift_weight=settings.ANOMALY_DRIFT_WEIGHT,
    )
    final_scores = scorer.score_batch(residual_scores, reconstruction_scores, drift_scores)

    # ── Step 5: Threshold & classify ─────────────────────────────────────────
    threshold = residual_detector.dynamic_threshold(req.actual, req.predicted)
    anomaly_details: List[AnomalyDetail] = []
    for i, (actual_v, pred_v, score) in enumerate(
        zip(req.actual, req.predicted, final_scores)
    ):
        residual = actual_v - pred_v
        is_anomaly = score > threshold
        severity = _classify_severity(score, threshold)
        anomaly_details.append(
            AnomalyDetail(
                index=i,
                timestamp=req.timestamps[i] if req.timestamps else None,
                actual_value=actual_v,
                predicted_value=pred_v,
                residual=residual,
                score=round(score, 4),
                is_anomaly=is_anomaly,
                severity=severity,
            )
        )

    detected = [a for a in anomaly_details if a.is_anomaly]
    anomaly_rate = len(detected) / max(len(anomaly_details), 1)

    # ── Step 6: LLM explanation (async, non-blocking) ────────────────────────
    llm_summary = None
    if req.return_explanations and detected:
        try:
            explainer = LLMAnomalyExplainer(settings=settings)
            llm_summary = await explainer.explain({
                "anomaly_count": len(detected),
                "anomaly_rate": round(anomaly_rate, 4),
                "max_score": max(final_scores),
                "residual_mean": sum(abs(a - p) for a, p in zip(req.actual, req.predicted)) / len(req.actual),
                "feature_context": req.feature_context,
            })
        except Exception as exc:
            log.warning("llm.explanation_failed", exc=str(exc))

    # ── Cache anomaly rate for drift service ──────────────────────────────────
    anomaly_rate_key = (
        f"{settings.TENANT_NAMESPACE_PREFIX}:{req.tenant_id}:anomaly_rate"
    )
    await redis.setex(anomaly_rate_key, 3600, str(round(anomaly_rate, 4)))

    log.info(
        "anomaly.detected",
        tenant=req.tenant_id,
        total=len(anomaly_details),
        anomalies=len(detected),
        rate=round(anomaly_rate, 4),
    )

    return AnomalyResponse(
        request_id=request_id,
        tenant_id=req.tenant_id,
        anomalies=detected,
        scores=final_scores,
        residual_scores=residual_scores,
        reconstruction_scores=reconstruction_scores,
        drift_scores=drift_scores,
        anomaly_count=len(detected),
        anomaly_rate=round(anomaly_rate, 4),
        llm_summary=llm_summary,
    )


def _classify_severity(score: float, threshold: float) -> str:
    ratio = score / max(threshold, 1e-9)
    if ratio < 1.0:
        return "normal"
    if ratio < 1.5:
        return "low"
    if ratio < 2.5:
        return "medium"
    if ratio < 4.0:
        return "high"
    return "critical"
