"""
Enterprise Temporal AI Platform — Drift Detection Service
"""

from __future__ import annotations

import uuid
from contextlib import asynccontextmanager

import redis.asyncio as aioredis
import uvicorn
from fastapi import FastAPI, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from prometheus_client import Counter, Gauge, make_asgi_app

from shared.config.settings import settings
from shared.logging.logger import configure_logging, get_logger, set_request_context
from shared.schemas.schemas import DriftRequest, DriftResponse

configure_logging("drift-service", settings.LOG_LEVEL, settings.is_production)
log = get_logger("drift_service")

DRIFT_DETECTED = Counter(
    "drift_detections_total",
    "Drift detection events",
    ["tenant_id", "drift_type"],
)
DRIFT_SCORE_GAUGE = Gauge(
    "drift_overall_score",
    "Current drift score per tenant",
    ["tenant_id"],
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.redis = aioredis.from_url(settings.REDIS_URL, decode_responses=True)
    await app.state.redis.ping()
    log.info("drift_service.startup")
    yield
    await app.state.redis.aclose()


def create_app() -> FastAPI:
    app = FastAPI(
        title="Temporal AI — Drift Detection Service",
        description="Detects data, feature, concept, embedding, and distribution drift.",
        version="1.0.0",
        lifespan=lifespan,
    )
    app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

    @app.middleware("http")
    async def ctx_middleware(request: Request, call_next):
        set_request_context(
            request.headers.get("X-Request-ID"),
            request.headers.get("X-Tenant-ID"),
            request.headers.get("X-User-ID"),
        )
        return await call_next(request)

    @app.exception_handler(Exception)
    async def exc_handler(request: Request, exc: Exception):
        log.error("unhandled", exc=str(exc))
        return JSONResponse(status_code=500, content={"status": "error", "message": str(exc)})

    @app.get("/health")
    async def health():
        return {"status": "healthy", "service": "drift-service", "version": "1.0.0"}

    @app.post("/v1/detect", response_model=DriftResponse, summary="Run drift detection")
    async def detect_drift(req: DriftRequest, request: Request) -> DriftResponse:
        """
        Run multi-technique drift detection on baseline vs current distributions.
        Stores overall drift score in Redis for the anomaly service.
        """
        from anomaly.drift.drift_detector import DriftDetector

        detector = DriftDetector()
        results = detector.detect(req.baseline, req.current, req.drift_types)
        overall = detector.overall_score(results)
        recommendation = detector.recommendation(overall, results)

        # Track metrics
        DRIFT_SCORE_GAUGE.labels(tenant_id=req.tenant_id).set(overall)
        for r in results:
            if r.detected:
                DRIFT_DETECTED.labels(
                    tenant_id=req.tenant_id,
                    drift_type=r.drift_type.value,
                ).inc()

        # Publish score to Redis for anomaly service to consume
        redis = request.app.state.redis
        await redis.setex(
            f"{settings.TENANT_NAMESPACE_PREFIX}:{req.tenant_id}:drift:latest",
            3600,
            str(overall),
        )

        drift_detected = any(r.detected for r in results)
        log.info(
            "drift.assessed",
            tenant=req.tenant_id,
            detected=drift_detected,
            score=overall,
        )

        return DriftResponse(
            request_id=req.request_id or str(uuid.uuid4()),
            tenant_id=req.tenant_id,
            drift_detected=drift_detected,
            results=results,
            overall_drift_score=overall,
            recommendation=recommendation,
        )

    @app.get("/v1/drift/{tenant_id}/history", summary="Get drift score history")
    async def drift_history(tenant_id: str, request: Request):
        """Return recent drift score history from Redis."""
        redis = request.app.state.redis
        history_key = f"{settings.TENANT_NAMESPACE_PREFIX}:{tenant_id}:drift:history"
        raw = await redis.lrange(history_key, 0, 99)
        import json
        history = [json.loads(r) for r in raw if r]
        return {"tenant_id": tenant_id, "history": history, "count": len(history)}

    app.mount("/metrics", make_asgi_app())
    return app


app = create_app()

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=settings.DRIFT_SERVICE_PORT, reload=False)
