"""
Enterprise Temporal AI Platform V4 — Multi-Asset CSV Loader

Handles:
- Multi-asset datasets: ts, asset_id, telemetry1..N
- Per-asset grouped resampling and interpolation
- Asset encoder (label encoding → nn.Embedding ready)
- Multivariate normalisation (per-column z-score)
- Per-asset train/val/test splits (no leakage across assets)
- .npy export: X[N,L,F], Y[N,H,T], asset_ids[N]
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler

from shared.logging.logger import get_logger

log = get_logger("data.csv_loader")


# ─────────────────────────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class CSVLoaderConfig:
    """
    Configuration for the multi-asset temporal loader.
    """

    # ── Column mapping ────────────────────────────────────────────────────────
    timestamp_column: Optional[str] = None         # auto-detected if None
    asset_column: str = "asset_id"                 # NEW: asset identifier column
    target_columns: List[str] = field(default_factory=list)   # NEW: multi-target
    feature_columns: List[str] = field(default_factory=list)  # extra covariates

    # ── Legacy single-target compat ───────────────────────────────────────────
    # If target_columns is empty and target_column is set, use it
    target_column: Optional[str] = None

    # ── Temporal resampling ───────────────────────────────────────────────────
    resample_freq: Optional[str] = None
    aggregation_method: str = "mean"

    # ── Gap filling ───────────────────────────────────────────────────────────
    interpolation_method: str = "linear"
    max_gap_fill_periods: int = 8

    # ── Normalisation ─────────────────────────────────────────────────────────
    normalisation: str = "zscore"   # zscore | minmax | robust | none

    # ── Splits ────────────────────────────────────────────────────────────────
    train_ratio: float = 0.7
    val_ratio: float = 0.15

    # ── Sliding window ────────────────────────────────────────────────────────
    window_size: int = 168
    horizon: int = 24

    # ── Output ────────────────────────────────────────────────────────────────
    output_dir: str = "./data/processed"


# ─────────────────────────────────────────────────────────────────────────────
# Dataset Container  (V4 — Multi-Asset Multivariate)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class LoadedDataset:
    """
    V4 multi-asset multivariate dataset container.

    Tensor contracts:
        X:         [N, L, F]   — lookback windows
        Y:         [N, H, T]   — forecast targets
        asset_ids: [N]         — integer-encoded asset ids (for nn.Embedding)

    Splits are per-asset to avoid temporal leakage.
    """

    # Full arrays
    X: np.ndarray              # [N, L, F]
    Y: np.ndarray              # [N, H, T]
    asset_ids: np.ndarray      # [N]   int32

    # Per-split arrays
    X_train: np.ndarray        # [N_train, L, F]
    Y_train: np.ndarray
    asset_ids_train: np.ndarray

    X_val: np.ndarray
    Y_val: np.ndarray
    asset_ids_val: np.ndarray

    X_test: np.ndarray
    Y_test: np.ndarray
    asset_ids_test: np.ndarray

    # Scalers
    feature_scaler: object     # fitted on train; use to inverse_transform
    target_scaler: object

    # Asset encoder
    asset_encoder: LabelEncoder  # .classes_ → asset names; encode → int ids

    # Metadata
    metadata: Dict
    stats: Dict


# ─────────────────────────────────────────────────────────────────────────────
# Loader
# ─────────────────────────────────────────────────────────────────────────────

class CSVTemporalLoader:
    """
    Multi-asset multivariate temporal loader.

    Expected CSV schema:
        ts, asset_id, telemetry1, telemetry2, ..., telemetryN

    Rules:
        - Sort by (asset_id, ts) before any processing
        - Resample per asset group
        - Interpolate per asset group
        - Windows NEVER cross asset boundaries
        - Train/val/test splits performed independently per asset
    """

    def __init__(self, config: CSVLoaderConfig):
        self.cfg = config
        self._feature_scaler: Optional[StandardScaler] = None
        self._target_scaler: Optional[StandardScaler] = None
        self._asset_encoder: Optional[LabelEncoder] = None

    # ─────────────────────────────────────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────────────────────────────────────

    def load(self, csv_path: str) -> LoadedDataset:
        path = Path(csv_path)
        if not path.exists():
            raise FileNotFoundError(f"CSV not found: {csv_path}")

        log.info("csv_loader.start", path=str(path))

        # ── 1. Read ──────────────────────────────────────────────────────────
        df = self._read(path)

        log.info("csv_loader.read", rows=len(df), cols=list(df.columns))

        # ── 2. Resolve column config ─────────────────────────────────────────
        self._resolve_columns(df)

        # ── 3. Parse timestamps ──────────────────────────────────────────────
        df = self._parse_timestamps(df)

        # ── 4. Encode asset ids ──────────────────────────────────────────────
        df = self._encode_assets(df)

        # ── 5. Sort: (asset_id, timestamp) ──────────────────────────────────
        df = df.sort_values(["_asset_int", df.index.name or "index"])

        # ── 6. Per-asset resample & interpolate ──────────────────────────────
        df = self._per_asset_resample(df)
        df = self._per_asset_interpolate(df)

        # ── 7. Stats before normalisation ────────────────────────────────────
        stats = self._compute_stats(df)

        # ── 8. Fit scalers on all data (train split only via windowing) ──────
        #       We fit scalers here globally; in windowing we use train rows
        df, self._feature_scaler, self._target_scaler = self._normalise(df)

        # ── 9. Build windows per asset ───────────────────────────────────────
        (X_tr, Y_tr, aids_tr,
         X_va, Y_va, aids_va,
         X_te, Y_te, aids_te) = self._build_windows_per_asset(df)

        # ── 10. Concatenate splits ───────────────────────────────────────────
        X    = np.concatenate([X_tr, X_va, X_te], axis=0)
        Y    = np.concatenate([Y_tr, Y_va, Y_te], axis=0)
        aids = np.concatenate([aids_tr, aids_va, aids_te], axis=0)

        ds = LoadedDataset(
            X=X, Y=Y, asset_ids=aids,
            X_train=X_tr, Y_train=Y_tr, asset_ids_train=aids_tr,
            X_val=X_va,   Y_val=Y_va,   asset_ids_val=aids_va,
            X_test=X_te,  Y_test=Y_te,  asset_ids_test=aids_te,
            feature_scaler=self._feature_scaler,
            target_scaler=self._target_scaler,
            asset_encoder=self._asset_encoder,
            metadata={
                "source": str(path),
                "asset_column": self.cfg.asset_column,
                "target_columns": self.cfg.target_columns,
                "feature_columns": self.cfg.feature_columns,
                "num_assets": int(len(self._asset_encoder.classes_)),
                "num_targets": len(self.cfg.target_columns),
                "num_features": len(self.cfg.feature_columns) + len(self.cfg.target_columns),
                "window_size": self.cfg.window_size,
                "horizon": self.cfg.horizon,
                "normalisation": self.cfg.normalisation,
                "asset_names": list(self._asset_encoder.classes_),
            },
            stats=stats,
        )

        log.info(
            "csv_loader.done",
            total_windows=len(X),
            train=len(X_tr),
            val=len(X_va),
            test=len(X_te),
            shape_X=X.shape,
            shape_Y=Y.shape,
            num_assets=len(self._asset_encoder.classes_),
        )

        return ds

    # ─────────────────────────────────────────────────────────────────────────
    # Export
    # ─────────────────────────────────────────────────────────────────────────

    def export_npy(self, ds: LoadedDataset, output_dir: Optional[str] = None) -> Dict[str, str]:
        out = Path(output_dir or self.cfg.output_dir)
        out.mkdir(parents=True, exist_ok=True)
        paths = {}

        arrays = {
            "X_train": ds.X_train, "Y_train": ds.Y_train, "asset_ids_train": ds.asset_ids_train,
            "X_val":   ds.X_val,   "Y_val":   ds.Y_val,   "asset_ids_val":   ds.asset_ids_val,
            "X_test":  ds.X_test,  "Y_test":  ds.Y_test,  "asset_ids_test":  ds.asset_ids_test,
            "X":       ds.X,       "Y":       ds.Y,        "asset_ids":       ds.asset_ids,
        }

        for name, arr in arrays.items():
            p = out / f"{name}.npy"
            np.save(p, arr)
            paths[name] = str(p)
            log.info("csv_loader.saved", name=name, shape=arr.shape, path=str(p))

        meta_path = out / "metadata.json"
        meta_path.write_text(json.dumps({**ds.metadata, "stats": ds.stats}, indent=2))
        paths["metadata"] = str(meta_path)

        # Save asset encoder mapping
        enc_path = out / "asset_encoder.json"
        enc_path.write_text(json.dumps({
            "classes": list(ds.asset_encoder.classes_),
            "mapping": {str(c): int(i) for i, c in enumerate(ds.asset_encoder.classes_)},
        }, indent=2))
        paths["asset_encoder"] = str(enc_path)

        return paths

    # ─────────────────────────────────────────────────────────────────────────
    # Inverse transform
    # ─────────────────────────────────────────────────────────────────────────

    def inverse_transform_targets(self, Y: np.ndarray) -> np.ndarray:
        """
        Y: [B, H, T]  → inverse normalise → [B, H, T]
        """
        if self._target_scaler is None or self.cfg.normalisation == "none":
            return Y

        B, H, T = Y.shape
        flat = Y.reshape(-1, T)
        out = self._target_scaler.inverse_transform(flat)
        return out.reshape(B, H, T)

    # ─────────────────────────────────────────────────────────────────────────
    # Column resolution
    # ─────────────────────────────────────────────────────────────────────────

    def _resolve_columns(self, df: pd.DataFrame):
        """
        Resolve target_columns from config, with fallback to legacy target_column.
        Auto-detect telemetry columns if neither is specified.
        """
        df.columns = [str(c).strip() for c in df.columns]

        if not self.cfg.target_columns:
            if self.cfg.target_column and self.cfg.target_column in df.columns:
                self.cfg.target_columns = [self.cfg.target_column]
            else:
                # Auto-detect: all numeric columns except ts and asset_id
                skip = {self.cfg.asset_column}
                if self.cfg.timestamp_column:
                    skip.add(self.cfg.timestamp_column)
                numeric = df.select_dtypes(include=[np.number]).columns.tolist()
                self.cfg.target_columns = [c for c in numeric if c not in skip]

        if not self.cfg.target_columns:
            raise ValueError(
                "No target columns found. Set target_columns in CSVLoaderConfig "
                "or ensure numeric telemetry columns are present."
            )

        log.info(
            "csv_loader.columns_resolved",
            asset_column=self.cfg.asset_column,
            target_columns=self.cfg.target_columns,
            feature_columns=self.cfg.feature_columns,
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Read CSV
    # ─────────────────────────────────────────────────────────────────────────

    def _read(self, path: Path) -> pd.DataFrame:
        for sep in [",", ";", "\t", "|"]:
            try:
                df = pd.read_csv(path, sep=sep, encoding="utf-8", low_memory=False)
                if len(df.columns) > 1:
                    return df
            except Exception:
                continue
        return pd.read_csv(path, encoding="latin-1")

    # ─────────────────────────────────────────────────────────────────────────
    # Timestamp parsing
    # ─────────────────────────────────────────────────────────────────────────

    def _parse_timestamps(self, df: pd.DataFrame) -> pd.DataFrame:
        df.columns = [str(c).strip() for c in df.columns]

        ts_col = self.cfg.timestamp_column
        if ts_col is None:
            candidates = [
                c for c in df.columns
                if any(k in c.lower() for k in ["time", "timestamp", "date", "datetime", "ts"])
            ]
            ts_col = candidates[0] if candidates else df.columns[0]

        if ts_col not in df.columns:
            raise ValueError(f"Timestamp column '{ts_col}' not found. Columns: {list(df.columns)}")

        df[ts_col] = pd.to_datetime(df[ts_col], errors="coerce", dayfirst=True)

        invalid = df[ts_col].isna().sum()
        if invalid:
            log.warning("csv_loader.invalid_timestamps", count=invalid)
            df = df.dropna(subset=[ts_col])

        # Drop duplicates within each asset group
        df = df.drop_duplicates(subset=[ts_col, self.cfg.asset_column])
        df = df.set_index(ts_col)
        df.index.name = "ts"

        return df

    # ─────────────────────────────────────────────────────────────────────────
    # Asset encoding
    # ─────────────────────────────────────────────────────────────────────────

    def _encode_assets(self, df: pd.DataFrame) -> pd.DataFrame:
        if self.cfg.asset_column not in df.columns:
            log.warning(
                "csv_loader.asset_column_missing",
                column=self.cfg.asset_column,
                msg="Treating as single-asset dataset"
            )
            df[self.cfg.asset_column] = "ASSET_DEFAULT"

        le = LabelEncoder()
        df["_asset_int"] = le.fit_transform(df[self.cfg.asset_column].astype(str))
        self._asset_encoder = le

        log.info(
            "csv_loader.assets_encoded",
            num_assets=len(le.classes_),
            assets=list(le.classes_[:10]),  # log first 10
        )
        return df

    # ─────────────────────────────────────────────────────────────────────────
    # Per-asset resampling
    # ─────────────────────────────────────────────────────────────────────────

    def _per_asset_resample(self, df: pd.DataFrame) -> pd.DataFrame:
        if self.cfg.resample_freq is None:
            return df

        freq = (
            self.cfg.resample_freq
            .replace("H", "h")
            .replace("T", "min")
            .replace("M", "ME")
        )

        all_cols = self.cfg.target_columns + self.cfg.feature_columns
        numeric_cols = [c for c in all_cols if c in df.columns]

        groups = []
        for asset_int, grp in df.groupby("_asset_int"):
            resampled = grp[numeric_cols].resample(freq).mean()
            resampled["_asset_int"] = asset_int
            # Restore asset_id string
            asset_name = self._asset_encoder.classes_[asset_int]
            resampled[self.cfg.asset_column] = asset_name
            groups.append(resampled)

        result = pd.concat(groups).sort_values(["_asset_int"])
        log.info("csv_loader.resampled_per_asset", rows_before=len(df), rows_after=len(result))
        return result

    # ─────────────────────────────────────────────────────────────────────────
    # Per-asset interpolation
    # ─────────────────────────────────────────────────────────────────────────

    def _per_asset_interpolate(self, df: pd.DataFrame) -> pd.DataFrame:
        method = self.cfg.interpolation_method
        limit = self.cfg.max_gap_fill_periods

        all_cols = self.cfg.target_columns + self.cfg.feature_columns
        numeric_cols = [c for c in all_cols if c in df.columns]

        groups = []
        for _, grp in df.groupby("_asset_int"):
            grp = grp.copy()
            if method in ("ffill", "bfill"):
                grp[numeric_cols] = grp[numeric_cols].ffill(limit=limit) if method == "ffill" \
                    else grp[numeric_cols].bfill(limit=limit)
            else:
                grp[numeric_cols] = grp[numeric_cols].interpolate(
                    method=method, limit=limit, limit_direction="both"
                )
            grp[numeric_cols] = grp[numeric_cols].bfill().ffill()
            groups.append(grp)

        return pd.concat(groups)

    # ─────────────────────────────────────────────────────────────────────────
    # Stats
    # ─────────────────────────────────────────────────────────────────────────

    def _compute_stats(self, df: pd.DataFrame) -> Dict:
        stats = {}
        for col in self.cfg.target_columns:
            if col in df.columns:
                vals = pd.to_numeric(df[col], errors="coerce").dropna().values
                stats[col] = {
                    "mean": float(np.mean(vals)),
                    "std":  float(np.std(vals)),
                    "min":  float(np.min(vals)),
                    "max":  float(np.max(vals)),
                    "count": int(len(vals)),
                }
        return stats

    # ─────────────────────────────────────────────────────────────────────────
    # Normalisation
    # ─────────────────────────────────────────────────────────────────────────

    def _normalise(self, df: pd.DataFrame):
        from sklearn.preprocessing import MinMaxScaler, RobustScaler, StandardScaler

        target_cols = [c for c in self.cfg.target_columns if c in df.columns]
        feature_cols = [c for c in self.cfg.feature_columns if c in df.columns]

        if self.cfg.normalisation == "none":
            return df, None, None

        def _make_scaler():
            if self.cfg.normalisation == "minmax":
                return MinMaxScaler(feature_range=(-1, 1))
            elif self.cfg.normalisation == "robust":
                return RobustScaler()
            return StandardScaler()

        # Fit & transform target columns
        target_scaler = None
        if target_cols:
            target_scaler = _make_scaler()
            df[target_cols] = target_scaler.fit_transform(
                df[target_cols].apply(pd.to_numeric, errors="coerce").fillna(0)
            )

        # Fit & transform feature columns
        feature_scaler = None
        if feature_cols:
            feature_scaler = _make_scaler()
            df[feature_cols] = feature_scaler.fit_transform(
                df[feature_cols].apply(pd.to_numeric, errors="coerce").fillna(0)
            )

        return df, feature_scaler, target_scaler

    # ─────────────────────────────────────────────────────────────────────────
    # Window builder — per asset, no boundary crossing
    # ─────────────────────────────────────────────────────────────────────────

    def _build_windows_per_asset(self, df: pd.DataFrame):
        """
        Build sliding windows independently per asset.
        Windows NEVER cross asset boundaries.
        Splits (train/val/test) performed independently per asset.

        Returns:
            X_train, Y_train, aids_train,
            X_val,   Y_val,   aids_val,
            X_test,  Y_test,  aids_test
        """
        W = self.cfg.window_size
        H = self.cfg.horizon

        all_cols = self.cfg.target_columns + [
            c for c in self.cfg.feature_columns if c in df.columns
        ]
        # F = number of features
        # T = number of targets

        target_cols = [c for c in self.cfg.target_columns if c in df.columns]
        feature_cols_present = [c for c in self.cfg.feature_columns if c in df.columns]
        input_cols = target_cols + feature_cols_present   # F columns

        splits = {"train": ([], [], []), "val": ([], [], []), "test": ([], [], [])}

        for asset_int, grp in df.groupby("_asset_int"):
            grp = grp.sort_index()

            # Extract numeric arrays
            feat_arr = grp[input_cols].apply(pd.to_numeric, errors="coerce").fillna(0).values.astype(np.float32)  # [N_rows, F]
            targ_arr = grp[target_cols].apply(pd.to_numeric, errors="coerce").fillna(0).values.astype(np.float32) # [N_rows, T]

            n = len(feat_arr)
            if n < W + H:
                log.warning(
                    "csv_loader.asset_too_short",
                    asset=self._asset_encoder.classes_[asset_int],
                    rows=n,
                    required=W + H,
                )
                continue

            # Build windows
            Xs, Ys = [], []
            for i in range(n - W - H + 1):
                Xs.append(feat_arr[i: i + W])          # [L, F]
                Ys.append(targ_arr[i + W: i + W + H])  # [H, T]

            Xs = np.array(Xs, dtype=np.float32)   # [n_windows, L, F]
            Ys = np.array(Ys, dtype=np.float32)   # [n_windows, H, T]
            n_win = len(Xs)

            # Per-asset split
            train_end = int(n_win * self.cfg.train_ratio)
            val_end   = train_end + int(n_win * self.cfg.val_ratio)

            for split_name, sl in [
                ("train", slice(0, train_end)),
                ("val",   slice(train_end, val_end)),
                ("test",  slice(val_end, None)),
            ]:
                x_split = Xs[sl]
                y_split = Ys[sl]
                ids     = np.full(len(x_split), asset_int, dtype=np.int32)
                splits[split_name][0].append(x_split)
                splits[split_name][1].append(y_split)
                splits[split_name][2].append(ids)

        def _concat(lst):
            return np.concatenate(lst, axis=0) if lst else np.array([])

        X_tr  = _concat(splits["train"][0])
        Y_tr  = _concat(splits["train"][1])
        ids_tr = _concat(splits["train"][2])

        X_va  = _concat(splits["val"][0])
        Y_va  = _concat(splits["val"][1])
        ids_va = _concat(splits["val"][2])

        X_te  = _concat(splits["test"][0])
        Y_te  = _concat(splits["test"][1])
        ids_te = _concat(splits["test"][2])

        log.info(
            "csv_loader.windows_built",
            train=len(X_tr), val=len(X_va), test=len(X_te),
            X_shape=X_tr.shape if len(X_tr) else "empty",
            Y_shape=Y_tr.shape if len(Y_tr) else "empty",
        )

        return X_tr, Y_tr, ids_tr, X_va, Y_va, ids_va, X_te, Y_te, ids_te


# ─────────────────────────────────────────────────────────────────────────────
# Preview helper
# ─────────────────────────────────────────────────────────────────────────────

def preview_csv(csv_path: str, n_rows: int = 5) -> Dict:
    df = pd.read_csv(csv_path, nrows=n_rows * 4)
    timestamp_candidates = [
        c for c in df.columns if any(k in c.lower() for k in ["time", "date", "ts", "dt"])
    ]
    numeric_candidates = df.select_dtypes(include=[np.number]).columns.tolist()
    asset_candidates = [
        c for c in df.columns if any(k in c.lower() for k in ["asset", "id", "machine", "unit", "device"])
    ]
    return {
        "columns": list(df.columns),
        "dtypes": df.dtypes.astype(str).to_dict(),
        "shape": df.shape,
        "sample": df.head(n_rows).to_dict(orient="records"),
        "timestamp_candidates": timestamp_candidates,
        "asset_candidates": asset_candidates,
        "numeric_candidates": numeric_candidates,
        "null_counts": df.isnull().sum().to_dict(),
    }
