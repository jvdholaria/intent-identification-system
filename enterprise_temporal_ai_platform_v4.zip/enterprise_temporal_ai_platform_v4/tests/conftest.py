"""
Enterprise Temporal AI Platform — pytest configuration and shared fixtures
"""

from __future__ import annotations

import os
import sys

import numpy as np
import pytest

# Add project root to sys.path so imports work without installation
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

# ── Environment overrides for tests ──────────────────────────────────────────
os.environ.setdefault("ENV", "development")
os.environ.setdefault("REDIS_URL", "redis://localhost:6379")
os.environ.setdefault("DATABASE_URL", "sqlite:///./test.db")
os.environ.setdefault("MLFLOW_TRACKING_URI", "http://localhost:5000")
os.environ.setdefault("FEAST_REPO_PATH", "./feature_store/feast")
os.environ.setdefault("GOOGLE_CLOUD_PROJECT", "test-project")
os.environ.setdefault("LLM_BASE_URL", "http://localhost:11434")


# ── Shared fixtures ────────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def sinusoidal_series():
    """168-point sinusoidal time series with weekly pattern."""
    t = np.linspace(0, 2 * np.pi, 168)
    return (np.sin(t) + np.sin(2 * t / 7) + 0.05 * np.random.randn(168)).astype(np.float32)


@pytest.fixture(scope="session")
def spike_series():
    """Series with a clear anomaly spike at index 120."""
    t = np.linspace(0, 2 * np.pi, 200)
    series = np.sin(t) + 0.05 * np.random.randn(200)
    series[120] += 15.0
    return series.astype(np.float32)


@pytest.fixture(scope="session")
def normal_dist_baseline():
    """N(0,1) reference distribution."""
    np.random.seed(42)
    return np.random.normal(0.0, 1.0, 500).tolist()


@pytest.fixture(scope="session")
def shifted_dist():
    """N(5,1) shifted distribution (strong drift)."""
    np.random.seed(42)
    return np.random.normal(5.0, 1.0, 500).tolist()


@pytest.fixture
def sample_forecast_payload():
    np.random.seed(0)
    series = np.sin(np.linspace(0, 4 * np.pi, 200)).tolist()
    return {
        "tenant_id": "test_tenant",
        "user_id": "test_user",
        "series": series,
        "horizon": 24,
        "model": "gru",
        "return_uncertainty": True,
        "return_quantiles": True,
    }


@pytest.fixture
def sample_anomaly_payload():
    np.random.seed(1)
    actual = np.sin(np.linspace(0, 2 * np.pi, 50)).tolist()
    predicted = np.sin(np.linspace(0, 2 * np.pi, 50)).tolist()
    actual[30] += 10.0  # inject spike
    return {
        "tenant_id": "test_tenant",
        "user_id": "test_user",
        "actual": actual,
        "predicted": predicted,
        "return_explanations": False,
    }


# ── pytest-asyncio configuration ──────────────────────────────────────────────

def pytest_configure(config):
    config.addinivalue_line("markers", "asyncio: mark test as async")
