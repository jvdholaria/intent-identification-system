"""
Enterprise Temporal AI Platform V4 — N-BEATS (Multivariate + Asset-Aware)

Changes from V3:
  - Input:  [B, L, F]  → flatten to [B, L*F] for block stack
  - Asset embedding concatenated to input
  - Per-target output heads
  - Output: [B, H, T]
"""

from __future__ import annotations
from typing import List, Optional, Tuple

import math
import numpy as np
import torch
import torch.nn as nn

from shared.logging.logger import get_logger

log = get_logger("models.nbeats")


class NBEATSBlock(nn.Module):
    def __init__(self, input_size: int, theta_size: int, horizon: int,
                 hidden_units: int = 256, num_layers: int = 4):
        super().__init__()
        self.input_size  = input_size
        self.theta_size  = theta_size
        self.horizon     = horizon
        layers = [nn.Linear(input_size, hidden_units), nn.ReLU()]
        for _ in range(num_layers - 1):
            layers += [nn.Linear(hidden_units, hidden_units), nn.ReLU()]
        self.fc_stack        = nn.Sequential(*layers)
        self.backcast_head   = nn.Linear(hidden_units, theta_size)
        self.forecast_head   = nn.Linear(hidden_units, theta_size)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        h       = self.fc_stack(x)
        theta_b = self.backcast_head(h)
        theta_f = self.forecast_head(h)
        return theta_b, theta_f


class GenericBlock(NBEATSBlock):
    def __init__(self, input_size: int, horizon: int, hidden_units: int = 256):
        super().__init__(input_size, max(input_size, horizon), horizon, hidden_units)
        self.backcast_proj = nn.Linear(self.theta_size, input_size)
        self.forecast_proj = nn.Linear(self.theta_size, horizon)

    def forward(self, x):
        theta_b, theta_f = super().forward(x)
        return self.backcast_proj(theta_b), self.forecast_proj(theta_f)


class NBEATSModel(nn.Module):
    """
    V4 N-BEATS: multivariate + asset-aware.

    Input:
        x:        [B, L, F]
        asset_id: [B]

    Output:
        forecast: [B, H, T]

    Architecture:
        1. Flatten x → [B, L*F]
        2. Concat asset embedding → [B, L*F + emb_dim]
        3. Stack of GenericBlocks with residual connections
        4. Per-target linear heads → T × [B, H]
        5. Stack → [B, H, T]
    """

    def __init__(
        self,
        seq_len:       int   = 168,
        pred_len:      int   = 24,
        num_features:  int   = 1,    # F
        num_targets:   int   = 1,    # T
        num_assets:    int   = 1,
        embedding_dim: int   = 16,
        hidden_units:  int   = 256,
        num_blocks:    int   = 3,
        num_layers:    int   = 4,
    ):
        super().__init__()
        self.pred_len    = pred_len
        self.num_targets = num_targets

        self.asset_embedding = nn.Embedding(num_assets, embedding_dim)

        flat_input = seq_len * num_features + embedding_dim

        self.blocks = nn.ModuleList([
            GenericBlock(flat_input, pred_len, hidden_units)
            for _ in range(num_blocks)
        ])

        # Per-target forecast heads (aggregate block outputs)
        self.target_heads = nn.ModuleList([
            nn.Linear(pred_len * num_blocks, pred_len)
            for _ in range(num_targets)
        ])

        log.info("nbeats.init", seq_len=seq_len, pred_len=pred_len,
                 num_features=num_features, num_targets=num_targets)

    def forward(self, x: torch.Tensor, asset_id: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        x:        [B, L, F]
        asset_id: [B]
        Returns:  [B, H, T]
        """
        x = x.float()
        B = x.size(0)

        if asset_id is None:
            asset_id = torch.zeros(B, dtype=torch.long, device=x.device)

        a_emb = self.asset_embedding(asset_id)       # [B, emb_dim]
        flat  = x.reshape(B, -1)                     # [B, L*F]
        inp   = torch.cat([flat, a_emb], dim=-1)     # [B, L*F + emb_dim]

        # Residual stack
        block_forecasts = []
        residual = inp
        for block in self.blocks:
            backcast, forecast = block(residual)
            residual = residual - backcast            # subtract backcast
            block_forecasts.append(forecast)          # [B, H]

        # Concatenate all block forecasts
        all_forecasts = torch.stack(block_forecasts, dim=-1)   # [B, H, num_blocks]
        all_flat      = all_forecasts.reshape(B, -1)           # [B, H * num_blocks]

        # Per-target projection
        targets = [head(all_flat) for head in self.target_heads]   # T × [B, H]
        out     = torch.stack(targets, dim=-1)                     # [B, H, T]
        return out
