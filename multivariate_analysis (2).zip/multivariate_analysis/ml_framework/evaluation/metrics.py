"""
evaluation.py — Multi-output evaluation metrics and temporal cross-validation.

Design notes
------------
* All metrics are computed per-target and then aggregated (mean ± std).
* Temporal CV enforces strict chronological ordering — no shuffling.
* Results are returned as structured DataFrames for easy reporting.
* A leakage audit method verifies that no future information entered training.
"""

from __future__ import annotations

import logging
import warnings
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from pandas import DataFrame

logger = logging.getLogger(__name__)

EPS = 1e-8   # prevent zero-division in percentage metrics


# ---------------------------------------------------------------------------
# Metric functions (all accept 1-D arrays)
# ---------------------------------------------------------------------------

def _mae(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.mean(np.abs(y_true - y_pred)))

def _rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))

def _mape(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    mask = np.abs(y_true) > EPS
    return float(np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100)

def _smape(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    denom = (np.abs(y_true) + np.abs(y_pred)) / 2 + EPS
    return float(np.mean(np.abs(y_true - y_pred) / denom) * 100)

def _r2(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2) + EPS
    return float(1 - ss_res / ss_tot)

def _medae(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.median(np.abs(y_true - y_pred)))

def _max_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.max(np.abs(y_true - y_pred)))


METRIC_REGISTRY: Dict[str, Callable] = {
    "mae":       _mae,
    "rmse":      _rmse,
    "mape":      _mape,
    "smape":     _smape,
    "r2":        _r2,
    "medae":     _medae,
    "max_error": _max_error,
}


# ---------------------------------------------------------------------------
# Core evaluation
# ---------------------------------------------------------------------------

class ModelEvaluator:
    """
    Compute multi-output metrics and produce structured evaluation reports.

    Parameters
    ----------
    metrics : list[str]
        Metric names from METRIC_REGISTRY. Default: ["mae", "rmse", "r2"].
    target_names : list[str]
        Human-readable names for each output dimension.

    Usage
    -----
    >>> ev = ModelEvaluator(["mae", "rmse", "r2"], ["temp", "pressure"])
    >>> report = ev.evaluate(y_true, y_pred)
    >>> print(report)
    """

    def __init__(
        self,
        metrics: List[str],
        target_names: Optional[List[str]] = None,
    ) -> None:
        unknown = set(metrics) - set(METRIC_REGISTRY)
        if unknown:
            raise ValueError(f"Unknown metrics: {unknown}. Available: {list(METRIC_REGISTRY)}")
        self.metrics      = metrics
        self.target_names = target_names or []

    def evaluate(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        prefix: str = "",
    ) -> DataFrame:
        """
        Compute per-target and averaged metrics.

        Parameters
        ----------
        y_true : (N, T) or (N,) array
        y_pred : (N, T) or (N,) array
        prefix : str
            Optional string prefix added to row labels (e.g. "val_", "test_").

        Returns
        -------
        DataFrame with shape (T+1, len(metrics))
            Last row is the macro average across targets.
        """
        y_true = np.atleast_2d(y_true.T).T   # ensure (N, T)
        y_pred = np.atleast_2d(y_pred.T).T

        if y_true.shape != y_pred.shape:
            raise ValueError(
                f"Shape mismatch: y_true={y_true.shape}  y_pred={y_pred.shape}"
            )

        n_targets = y_true.shape[1]
        target_names = self.target_names or [f"target_{i}" for i in range(n_targets)]

        rows = []
        for i, name in enumerate(target_names):
            row = {m: METRIC_REGISTRY[m](y_true[:, i], y_pred[:, i]) for m in self.metrics}
            row["target"] = f"{prefix}{name}"
            rows.append(row)

        df = DataFrame(rows).set_index("target")

        # Macro average
        avg_row = df.mean().rename("macro_avg")
        df = pd.concat([df, avg_row.to_frame().T])

        logger.info(
            "Evaluation (%s) | macro MAE=%.4f  RMSE=%.4f  R²=%.4f",
            prefix or "default",
            df.loc["macro_avg", "mae"]  if "mae"  in df.columns else float("nan"),
            df.loc["macro_avg", "rmse"] if "rmse" in df.columns else float("nan"),
            df.loc["macro_avg", "r2"]   if "r2"   in df.columns else float("nan"),
        )
        return df

    def compare(
        self,
        results: Dict[str, Tuple[np.ndarray, np.ndarray]],
    ) -> DataFrame:
        """
        Compare multiple models side-by-side.

        Parameters
        ----------
        results : dict[model_name → (y_true, y_pred)]

        Returns
        -------
        DataFrame indexed by model name, columns: metric × target
        """
        frames = {}
        for name, (yt, yp) in results.items():
            df = self.evaluate(yt, yp, prefix="")
            # Keep only macro average row
            frames[name] = df.loc["macro_avg"]
        return DataFrame(frames).T


# ---------------------------------------------------------------------------
# Temporal cross-validation runner
# ---------------------------------------------------------------------------

class TemporalCrossValidator:
    """
    Run a full temporal CV loop and aggregate results across folds.

    Parameters
    ----------
    splitter : TemporalSplitter
    evaluator : ModelEvaluator

    Usage
    -----
    >>> cv = TemporalCrossValidator(splitter, evaluator)
    >>> results = cv.run(X, y, model_factory=lambda: MyModel())
    """

    def __init__(self, splitter, evaluator: ModelEvaluator) -> None:
        self.splitter  = splitter
        self.evaluator = evaluator

    def run(
        self,
        X: np.ndarray,
        y: np.ndarray,
        model_factory: Callable,
        fit_kwargs: Optional[Dict] = None,
    ) -> DataFrame:
        """
        Train and evaluate model_factory() on each temporal CV fold.

        Parameters
        ----------
        X : (N, F) feature array (already preprocessed, chronological order)
        y : (N, T) target array
        model_factory : callable → model with .fit(X, y) and .predict(X)
        fit_kwargs : extra keyword arguments passed to .fit()

        Returns
        -------
        DataFrame with per-fold and aggregated metrics.
        """
        folds = self.splitter.cv_folds(
            pd.DataFrame(X)
        )
        fold_results = []

        for fold_idx, (train_idx, val_idx) in enumerate(folds, 1):
            X_tr, y_tr = X[train_idx], y[train_idx]
            X_vl, y_vl = X[val_idx],   y[val_idx]

            model = model_factory()
            model.fit(X_tr, y_tr, **(fit_kwargs or {}))
            preds = model.predict(X_vl)

            fold_df = self.evaluator.evaluate(y_vl, preds, prefix=f"fold{fold_idx}_")
            fold_results.append(fold_df.loc["macro_avg"])
            logger.info("CV fold %d/%d complete.", fold_idx, len(folds))

        summary = DataFrame(fold_results)
        agg = summary.agg(["mean", "std"]).rename(index={"mean": "cv_mean", "std": "cv_std"})
        return pd.concat([summary, agg])


# ---------------------------------------------------------------------------
# Data leakage audit
# ---------------------------------------------------------------------------

def audit_temporal_leakage(
    train_timestamps: np.ndarray,
    val_timestamps:   np.ndarray,
    test_timestamps:  np.ndarray,
) -> bool:
    """
    Assert that timestamps are strictly non-overlapping and chronological.

    Returns True if the split is clean; raises AssertionError otherwise.
    """
    train_max = np.max(train_timestamps)
    val_min   = np.min(val_timestamps)
    val_max   = np.max(val_timestamps)
    test_min  = np.min(test_timestamps)

    ok_1 = train_max < val_min
    ok_2 = val_max   < test_min

    if not ok_1:
        raise AssertionError(
            f"Data leakage! Train max ({train_max}) ≥ Val min ({val_min})"
        )
    if not ok_2:
        raise AssertionError(
            f"Data leakage! Val max ({val_max}) ≥ Test min ({test_min})"
        )

    logger.info(
        "Leakage audit passed ✓ | train≤%s < val≤%s < test≤%s",
        train_max, val_max, np.max(test_timestamps),
    )
    return True
