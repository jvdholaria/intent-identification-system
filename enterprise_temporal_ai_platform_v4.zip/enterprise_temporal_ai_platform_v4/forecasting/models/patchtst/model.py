"""
Enterprise Temporal AI Platform V4 — PatchTST (Multivariate + Asset-Aware)

Changes from V3:
  - Input:  [B, L, F]  (multivariate, channel-last)
  - Output: [B, H, T]  (multi-target)
  - Asset embedding injected at patch level
  - Independent patch tokenisation per channel (channel-independent strategy)
  - Positional encoding per channel
"""

from __future__ import annotations
from typing import Optional

import torch
import torch.nn as nn

from shared.logging.logger import get_logger

log = get_logger("models.patchtst")


# ─────────────────────────────────────────────────────────────────────────────
# Patch Embedding  (per channel, channel-independent)
# ─────────────────────────────────────────────────────────────────────────────

class PatchEmbedding(nn.Module):
    """
    Tokenise a single channel into patches and project to d_model.

    Input:  [B, L]
    Output: [B, num_patches, d_model]
    """

    def __init__(self, patch_len: int, stride: int, d_model: int, dropout: float = 0.1):
        super().__init__()
        self.patch_len = patch_len
        self.stride    = stride
        self.projection = nn.Linear(patch_len, d_model)
        self.dropout    = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, L]
        patches = x.unfold(dimension=-1, size=self.patch_len, step=self.stride)
        # patches: [B, num_patches, patch_len]
        out = self.projection(patches)  # [B, num_patches, d_model]
        return self.dropout(out)


# ─────────────────────────────────────────────────────────────────────────────
# Transformer Block
# ─────────────────────────────────────────────────────────────────────────────

class PatchTSTBlock(nn.Module):

    def __init__(self, d_model: int, n_heads: int, d_ff: int, dropout: float = 0.1):
        super().__init__()
        self.attn  = nn.MultiheadAttention(d_model, n_heads, dropout=dropout, batch_first=True)
        self.ff    = nn.Sequential(
            nn.Linear(d_model, d_ff), nn.GELU(), nn.Dropout(dropout), nn.Linear(d_ff, d_model)
        )
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.drop  = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        attn_out, _ = self.attn(x, x, x)
        x = self.norm1(x + self.drop(attn_out))
        x = self.norm2(x + self.drop(self.ff(x)))
        return x


# ─────────────────────────────────────────────────────────────────────────────
# PatchTST Model  — V4 Multivariate + Asset-Aware
# ─────────────────────────────────────────────────────────────────────────────

class PatchTSTModel(nn.Module):
    """
    V4 PatchTST: channel-independent patch transformer.

    Tensor contracts:
        Input:
            x:        [B, L, F]   — lookback window, F features
            asset_id: [B]         — integer asset ids (optional)

        Output:
            forecast: [B, H, T]   — H-step forecast for T targets

    Architecture:
        For each channel c in F:
            1. Extract patches from x[:, :, c]  →  [B, P, d_model]
            2. Add positional encoding
            3. Add asset embedding (broadcast over patches)
            4. Pass through Transformer encoder
            5. Flatten → Linear head → [B, H]  (one per target channel)
        Stack T target heads → [B, H, T]
    """

    def __init__(
        self,
        seq_len:       int   = 168,
        pred_len:      int   = 24,
        num_features:  int   = 1,    # F  — total input features
        num_targets:   int   = 1,    # T  — output targets (≤ num_features)
        num_assets:    int   = 1,    # for nn.Embedding
        embedding_dim: int   = 16,   # asset embedding dimension
        patch_len:     int   = 16,
        stride:        int   = 8,
        d_model:       int   = 64,
        n_heads:       int   = 4,
        n_layers:      int   = 2,
        d_ff:          int   = 128,
        dropout:       float = 0.1,
    ):
        super().__init__()

        self.seq_len      = seq_len
        self.pred_len     = pred_len
        self.num_features = num_features
        self.num_targets  = num_targets

        num_patches = (seq_len - patch_len) // stride + 1

        # ── Asset embedding ──────────────────────────────────────────────────
        self.asset_embedding = nn.Embedding(num_assets, embedding_dim)
        self.asset_proj      = nn.Linear(embedding_dim, d_model)

        # ── Per-channel patch embedding + transformer ────────────────────────
        self.patch_embeds = nn.ModuleList([
            PatchEmbedding(patch_len, stride, d_model, dropout)
            for _ in range(num_features)
        ])

        self.pos_enc = nn.Parameter(torch.randn(1, num_patches, d_model) * 0.02)

        self.encoders = nn.ModuleList([
            nn.Sequential(*[PatchTSTBlock(d_model, n_heads, d_ff, dropout) for _ in range(n_layers)])
            for _ in range(num_features)
        ])

        # ── Prediction heads: one Linear per target channel ──────────────────
        # Each head takes the flattened representation of ALL channels
        flat_dim = num_patches * d_model * num_features

        self.forecast_heads = nn.ModuleList([
            nn.Sequential(
                nn.Dropout(dropout),
                nn.Linear(flat_dim, pred_len),
            )
            for _ in range(num_targets)
        ])

        self.dropout = nn.Dropout(dropout)

        log.info(
            "patchtst.init",
            seq_len=seq_len, pred_len=pred_len,
            num_features=num_features, num_targets=num_targets,
            num_patches=num_patches, d_model=d_model,
        )

    def forward(
        self,
        x: torch.Tensor,
        asset_id: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        x:        [B, L, F]
        asset_id: [B]        (optional; zeros used if absent)

        Returns:  [B, H, T]
        """
        if x.dim() != 3:
            raise ValueError(f"PatchTST V4 expects [B, L, F], got {x.shape}")

        x = x.float()
        B, L, F = x.shape

        # ── Asset embedding → broadcast over patches ─────────────────────────
        if asset_id is None:
            asset_id = torch.zeros(B, dtype=torch.long, device=x.device)

        a_emb = self.asset_proj(self.asset_embedding(asset_id))  # [B, d_model]
        a_emb = a_emb.unsqueeze(1)                                # [B, 1, d_model]

        # ── Per-channel encoding ─────────────────────────────────────────────
        channel_reps = []
        for c in range(F):
            ch = x[:, :, c]                             # [B, L]
            patches = self.patch_embeds[c](ch)          # [B, P, d_model]
            patches = patches + self.pos_enc + a_emb    # broadcast asset emb
            encoded = self.encoders[c](patches)         # [B, P, d_model]
            channel_reps.append(encoded)

        # ── Concatenate all channels ─────────────────────────────────────────
        combined = torch.cat(channel_reps, dim=-1)      # [B, P, d_model * F]
        flat     = combined.reshape(B, -1)              # [B, P * d_model * F]

        # ── Per-target forecast heads ────────────────────────────────────────
        forecasts = []
        for head in self.forecast_heads:
            h = head(flat)                              # [B, H]
            forecasts.append(h)

        out = torch.stack(forecasts, dim=-1)            # [B, H, T]
        return out


# ─────────────────────────────────────────────────────────────────────────────
# Predictor Wrapper
# ─────────────────────────────────────────────────────────────────────────────

class PatchTSTPredictor:
    """
    Thin inference wrapper around PatchTSTModel.

    predict(x, asset_id, horizon) → np.ndarray [H, T]
    """

    def __init__(self, settings):
        self.settings = settings
        self.device   = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._model: Optional[PatchTSTModel] = None

    def _load(self, num_features: int = 1, num_targets: int = 1, num_assets: int = 1):
        if self._model is not None:
            return
        self._model = PatchTSTModel(
            seq_len=self.settings.FORECAST_WINDOW_SIZE,
            pred_len=self.settings.FORECAST_HORIZON,
            num_features=num_features,
            num_targets=num_targets,
            num_assets=num_assets,
        ).to(self.device)
        self._model.eval()

    def predict(
        self,
        x,          # np.ndarray [L, F]  or  [L]
        asset_id: int = 0,
        horizon: Optional[int] = None,
    ):
        import numpy as np
        self._load()

        arr = np.asarray(x, dtype=np.float32)
        if arr.ndim == 1:
            arr = arr[:, np.newaxis]   # [L, 1]

        tensor    = torch.tensor(arr).unsqueeze(0).to(self.device)   # [1, L, F]
        asset_t   = torch.tensor([asset_id], dtype=torch.long, device=self.device)

        with torch.no_grad():
            out = self._model(tensor, asset_t)   # [1, H, T]

        result = out.squeeze(0).cpu().numpy()    # [H, T]

        H = horizon or self.settings.FORECAST_HORIZON
        if result.shape[0] >= H:
            return result[:H]
        pad = H - result.shape[0]
        return np.pad(result, ((0, pad), (0, 0)), mode="edge")
